from flask import Flask,render_template,jsonify,request,abort
import csv
import os
import re
import enumeration
import time
import datetime
import pickle
import flask
import os.path
import requests

app=Flask(__name__)

c1=0
b={}
c4=0

if(os.path.isfile("rides.data")==False):


	f=open("rides.data","wb")

	f.close()
'''
	b["data"]={}

	b["file"]="rides.data"

	q=request.post("http://127.0.0.1:5000/api/v1/db/write",json=b)
'''
"""

f=open("users.data","wb")

f.close()



f=open("rides.data","wb")

f.close()
"""		
@app.errorhandler(405)
def count(e):
	if(request.url!="http://18.214.133.226/api/v1/db/clear" or request.url!="http://18.214.133.226:80/api/v1/_count"):
		global c4
		c4=c4+1
	
	return "",405

@app.route("/api/v1/db/clear",methods=["POST"])
def dele():
	if request.method!="POST":
		abort(405)
	else:
		if os.path.exists("rides.data")==False:
			abort(400,description="db doesnt exist")
		else:
			os.remove("rides.data")
			f=open("rides.data","wb")
			f.close()
			return "",200

@app.route("/api/v1/rides",methods=["POST"])
def create_ride():
	global c4
	c4=c4+1
	b={}
	c=0
	flag=0
	if request.method!="POST":

		abort(405)

	else:
		temp=dict(request.get_json())

		temp["users"]=[]

		users=[]

		rides=[]

		if os.stat("rides.data").st_size!=0:

			#f=open("rides.data","rb")

			#rides=pickle.load(f)

			#f.close()

			b["file"]="rides.data"

			rides1=requests.post("http://127.0.0.1:8000/api/v1/db/read",json=b)
			rides=rides1.json()
		#if os.stat("users.data").st_size!=0:

			#f=open("users.data","rb")

			#users=pickle.load(f)

			#f.close()

		#b["file"]="users.data"

		b["file"]="users.data"
		users1=requests.post("http://34.230.206.86:80/api/v1/db/read",json=b)
		users2=users1.json()
		users=users2.keys()

		#pattern = re.compile("((0[1-9]|[12][0-9]|3[01])-(0[13578]|1[02])-(18|19|20)[0-9]{2})|(0[1-9]|[12][0-9]|30)-(0[469]|11)-(18|19|20)[0-9]{2}|(0[1-9]|1[0-9]|2[0-8])-(02)-(18|19|20)[0-9]{2}|29-(02)-(((18|19|20)(04|08|[2468][048]|[13579][26]))|2000) [0-5][0-9]:[0-5][0-9]:(2[0-3]|[01][0-9])")

		#pattern = re.compile("^([1-9]|([012][0-9])|(3[01]))-([0]{0,1}[1-9]|1[012])-\d\d\d\d(20|21|22|23|[0-1]?\d):[0-5]?\d:[0-5]?\d$")

		pattern=re.search("((0[1-9]|[12][0-9]|3[01])-(0[13578]|1[02])-(18|19|20)[0-9]{2})|(0[1-9]|[12][0-9]|30)-(0[469]|11)-(18|19|20)[0-9]{2}|(0[1-9]|1[0-9]|2[0-8])-(02)-(18|19|20)[0-9]{2}|29-(02)-(((18|19|20)(04|08|[2468][048]|[13579][26]))|2000) [0-5][0-9]:[0-5][0-9]:(2[0-3]|[01][0-9])",temp["timestamp"])

		for area in enumeration.Area:

			if temp["source"] == str(area.value):

				c=c+1

		for area in enumeration.Area:

			if temp["destination"] == str(area.value):

				c=c+1

		if(len(rides)!=0):
			o=len(rides)-1
			w=rides[o]["rideId"]
			temp["rideId"]=w+1

		else:
			temp["rideId"]=1

		if temp["created_by"] in users:

			if pattern!=None:

				if temp["source"]!=temp["destination"]:

					if c==2:

						if(len(rides)!=0):

							for cur in rides:

								if(temp["rideId"]==cur["rideId"]):

									flag=1

								else:

									flag=0



							if(flag!=1):	

								rides.append(temp)

								#f=open("rides.data","wb")

								#pickle.dump(rides,f)

								#f.close()

								b["data"]=rides

								b["file"]="rides.data"

								q=requests.post("http://127.0.0.1:8000/api/v1/db/write",json=b)


								#status_code = flask.Response(status=201)

								#return status_code

								return "",201

							else:

								abort(400,description="cant have same rideId")



						else:

							rides.append(temp)

							#f=open("rides.data","wb")

							#pickle.dump(rides,f)

							#f.close()

							b["data"]=rides

							b["file"]="rides.data"

							q=requests.post("http://127.0.0.1:8000/api/v1/db/write",json=b)


							#status_code = flask.Response(status=201)

							#return status_code

							return "",201
					else:
						abort(400,description="invalid source or destination")
				else:
					abort(400,description="same source and destination")
			else:
				abort(400,description="invalid timestamp")
		else:
			abort(400,description="user doesnt exist")


@app.route("/api/v1/rides",methods=["GET"])

def upcoming_rides():
	global c4
	c4=c4+1
	b={}

	if request.method!="GET":
		abort(405)

	else:

		destination = request.args.get('destination')

		source = request.args.get('source')

		c=0

		for area in enumeration.Area:

			if source == str(area.value):

				c=c+1

		for area in enumeration.Area:

			if destination == str(area.value):

				c=c+1

		if c==2:

			temp1=[]

			temp=dict()

			rides=[]

			users=[]

			if os.stat("rides.data").st_size!=0:

				#f=open("rides.data","rb")

				#rides=pickle.load(f)

				#f.close()

				b["file"]="rides.data"

				rides1=requests.post("http://127.0.0.1:8000/api/v1/db/read",json=b)
				rides=rides1.json()

			#if os.stat("users.data").st_size!=0:

				#f=open("users.data","rb")

				#users=pickle.load(f)

				#f.close()

				#b["file"]="users.data"

			b["file"]="users.data"
			users1=requests.post("http://34.230.206.86:80/api/v1/db/read",json=b)
			users2=users1.json()
			users=users2.keys()

			for i in range(0,len(rides)):

				temp={}
				if rides[i]["source"]==source and rides[i]["destination"]==destination:

					if rides[i]["created_by"] in users:

						ts = time.time()

						st = datetime.datetime.fromtimestamp(ts).strftime('%d-%m-%Y:%S-%M-%H')

						datetime_object1 = datetime.datetime.strptime(st, '%d-%m-%Y:%S-%M-%H')

						st1=rides[i]["timestamp"]

						datetime_object = datetime.datetime.strptime(st1, '%d-%m-%Y:%S-%M-%H')

						if datetime_object>datetime_object1:

							temp["rideId"]=rides[i]["rideId"]

							temp["username"]=rides[i]["created_by"]

							temp["timestamp"]=rides[i]["timestamp"]

							temp1.append(temp)

			if len(temp1)==0:

				return '',204

			else:

				return jsonify(temp1),200

		else:

			abort(400,description="incorrect source or destination")



@app.route("/api/v1/rides/<rideId>",methods=["GET"])

def ride_details(rideId):
	global c4
	c4=c4+1
	b=dict()


	if request.method!="GET":

		abort(405)

	else:


		c=0
		l={}

		rides=[]

		if os.stat("rides.data").st_size!=0:

			#f=open("rides.data","rb")

			#rides=pickle.load(f)

			#f.close()

			b["file"]="rides.data"

			rides1=requests.post("http://127.0.0.1:8000/api/v1/db/read",json=b)
			rides=rides1.json()
			#return jsonify(str(rides[0]["rideId"])==str(rideId))
			for i in rides:

				if str(rideId)==str(i["rideId"]):
					c=c+1

					return jsonify(i),200


		if c==0:

			return "",204


@app.route("/api/v1/rides/<rideId>",methods=["POST"])

def join_existing_ride(rideId):
	global c4
	c4=c4+1
	b={}


	if request.method!="POST":

		abort(405)

	else:

		rides=[]

		users=[]

		temp=dict(request.get_json())

		#if os.stat("users.data").st_size!=0:

			#f=open("users.data","rb")

			#users=pickle.load(f)

			#f.close()

			#b["file"]="users.data"

		b["file"]="users.data"
		users1=requests.post("http://34.230.206.86:80/api/v1/db/read",json=b)
		users2=users1.json()
		users=users2.keys()

		if os.stat("rides.data").st_size!=0:

			#f=open("rides.data","rb")

			#rides=pickle.load(f)

			#f.close()

			b["file"]="rides.data"

			rides1=requests.post("http://127.0.0.1:8000/api/v1/db/read",json=b)
			rides=rides1.json()

		for i in rides:

			if str(rideId)==str(i["rideId"]):

				if temp["username"] in users:

					if temp["username"] not in i["users"]:

						i["users"].append(temp["username"])

						#f=open("rides.data","wb")

						#pickle.dump(rides,f)

						#f.close()

						b["data"]=rides

						b["file"]="rides.data"

						q=requests.post("http://127.0.0.1:8000/api/v1/db/write",json=b)



						#status_code = flask.Response(status=201)

						#return status_code

						return "",200

					else:

						abort(400,description="users already joined ride")
				else:
					abort(400, description="user doesnt exist")
			else:
				return "",204


	

@app.route("/api/v1/rides/<rideId>",methods=["DELETE"])

def delete_ride(rideId):
	global c4
	c4=c4+1
	b={}

	if request.method!="DELETE":

		abort(405)

	else:

		flag=0

		#if os.stat("users.data").st_size!=0:

			#f=open("users.data","rb")

			#users=pickle.load(f)

			#f.close()

			#b["file"]="users.data"

		b["file"]="users.data"
		users1=requests.post("http://34.230.206.86:80/api/v1/db/read",json=b)
		users2=users1.json()
		users=users2.keys()

		if os.stat("rides.data").st_size!=0:

			#f=open("rides.data","rb")

			#rides=pickle.load(f)

			#f.close()

			b["file"]="rides.data"

			rides1=requests.post("http://127.0.0.1:8000/api/v1/db/read",json=b)
			rides=rides1.json()

		for i in range(0,len(rides)):

			if str(rideId)==str(rides[i]["rideId"]):

				flag=1

				j=i

				break

			else:

				flag=0



		if(len(rides)==0):

			flag=0



		if(flag==1):

			del rides[j]

			#f=open("rides.data","wb")

			#pickle.dump(rides,f)

			#f.close()

			b["data"]=rides

			b["file"]="rides.data"

			q=requests.post("http://127.0.0.1:8000/api/v1/db/write",json=b)

			return "",200

		else:

			abort(400,description="ride doesnt exist")


@app.route("/api/v1/_count",methods=["GET"])

def counts():
	if request.method!="GET":
		abort(405)
	else:
		global c4
		l=[]
		l.append(c4)
		return jsonify(l),200



@app.route("/api/v1/_count",methods=["DELETE"])

def counts1():
	if request.method!="DELETE":
		abort(405)
	else:
		global c4
		c4=0
		return "",200

@app.route("/api/v1/rides/count",methods=["GET"])

def ride_count():
        global c4
        c4=c4+1
        b=dict()

        if request.method!="GET":

                abort(405)

        else:


                c=0
                l=[]

                rides=[]

                if os.stat("rides.data").st_size!=0:

                        #f=open("rides.data","rb")

                        #rides=pickle.load(f)

                        #f.close()

                        b["file"]="rides.data"

                        rides1=requests.post("http://127.0.0.1:8000/api/v1/db/read",json=b)
                        rides=rides1.json()
                        #return jsonify(str(rides[0]["rideId"])==str(rideId))
                        for i in rides:
                                c=c+1

                l.append(c)
                
                return jsonify(l),200


@app.route("/api/v1/db/write",methods=["POST"])

def write():
	b=dict(request.get_json())
	f=open(b["file"],"wb")
	pickle.dump(b["data"],f)
	f.close()
	return jsonify({})

@app.route("/api/v1/db/read",methods=["POST"])

def read():
	b=dict(request.get_json())
	f=open(b["file"],"rb")
	a=pickle.load(f)
	f.close()
	return jsonify(a)

if __name__ == '__main__':	

	app.debug=True
	app.run(host="0.0.0.0",port=8000)