const express = require("express");
const router = express.Router();

const app = express();
var cors = require('cors');

const Ride = require("../../../models/Ride");
const Count = require("../../../models/Count");
const rp = require("request-promise-native");
const joiSchemas = require("../../../utils/Joi_schemas");
const config = require("config");

// The 405 handler
const methodNotAllowed = (req, res, next) => res.status(405).send();

// The 400 handler
const badRequest = (message, req, res) =>
  res.status(400).json({ msg: message });

// generate a random number
const getRandomInt = max => {
  max = max || Number.MAX_SAFE_INTEGER;
  return Math.floor(Math.random() * Math.floor(max));
};

// Set orgin Header to Ride_Microservice Api - Ip address
var Origin_Header = {origin : '35.153.9.174',
                    optionsSuccessStatus: 200};
// Check if user exists
const userExists = async parameters => {
  // app.use(cors({
  //   origin: 'http://35.153.9.174:80'
  // }));
  const Origins = {
    headers: {
      Origin : '35.153.9.174'
    }
  };
  let users = await rp.get(config.get("USER_MICROSERVICE").LIST_USERS, Origins);
  // try {
  //   let counter = await Count.findOneAndUpdate({},{ $inc: {count:-1}},{
  //     new : true,
  //     upsert : true
  //   });
  //   console.log(counter.count);
  // }
  // catch(error)
  // {
  //   console.log(error.message);
  //   res.status(500).json({ msg: "Server error" });
  // }
  console.log();

  for (var i = 0; i < users.length; i++) {
    if (JSON.parse(users)[i] === parameters.username) {
      return true;
    }
  }
  return false;
};

// Check if ride exists
const rideExists = async parameters => {
  const rides = await rp.post(config.get("DB_API_URI").READ, {
    json: {
      model: "Ride",
      parameters: parameters
    }
  });
  try {
    let counter = await Count.findOneAndUpdate({},{ $inc: {count:-1}},{
      new : true,
      upsert : true
    });
    console.log(counter.count);
  }
  catch(error)
  {
    console.log(error.message);
    res.status(500).json({ msg: "Server error" });
  }
  if (rides.length != 0) return true;
  return false;
};

// Compare timestamp with time when request is made
const compareTime = (timestamp, d) => {
  const dateTime = timestamp.split(":");

  // console.log(dateTime);

  let date = dateTime[0].split("-");
  let time = dateTime[1].split("-");

  // console.log(date, time);
  date = date.map(num => {
    return parseInt(num, 10);
  });
  time = time.map(num => {
    return parseInt(num, 10);
  });

  const curr = new Date(
    date[2],
    date[1] - 1,
    date[0],
    time[2],
    time[1],
    time[0]
  );

  if (d.getTime() < curr.getTime()) {
    return 1;
  }
  return 0;
};

router.get("/all", async (req, res) => {
  console.log("yo");
  const val = await Ride.find();
  return res.send(val);
});

router.get("/count", async (req, res) => {
  const val = await Ride.countDocuments({});
  console.log("Count of number of rides:", val)
  return res.send([val]); 
});

router
  .route("/")
  .post(async (req, res) => {
    //create a ride
    if (
      !joiSchemas.joiValidate(joiSchemas.createRide, req.body) ||
      req.body.source == req.body.destination
    ) {
      return badRequest("Invalid params", req, res);
    }

    const created_by = req.body.created_by;
    const timestamp = req.body.timestamp;
    const source = req.body.source;
    const destination = req.body.destination;

    let isValidRideId = false;
    let rideId = 0;

    try {
      if (!(await userExists({ username: created_by }))) {
        return badRequest("Bad params", req, res);
      }
      do {
        rideId = getRandomInt();
        if (!(await rideExists({ rideId }))) {
          isValidRideId = true;
        }
      } while (!isValidRideId);

      let newRide = Object.assign(
        {},
        {
          created_by,
          timestamp,
          source,
          destination,
          rideId
        }
      );

      await rp.post(config.get("DB_API_URI").WRITE, {
        json: {
          model: "Ride",
          parameters: newRide,
          op: "in"
        }
      });
      try {
        let counter = await Count.findOneAndUpdate({},{ $inc: {count:-1}},{
          new : true,
          upsert : true
        });
        console.log(counter.count);
      }
      catch(error)
      {
        console.log(error.message);
        res.status(500).json({ msg: "Server error" });
      }
      return res.status(201).json({});
    } catch (error) {
      console.log(error.message);
      return res.status(500).json({ msg: "Server Error", error });
    }
  })
  .get(async (req, res) => {
    if (joiSchemas.joiValidate(joiSchemas.getRideSrcDst, req.query)) {
      const source = req.query.source;
      const destination = req.query.destination;
      // Get all rides with given source and dest
      try {
        let rides = await rp.post(config.get("DB_API_URI").READ, {
          json: {
            model: "Ride",
            parameters: {
              source: source,
              destination: destination
            }
          }
        });
        try {
          let counter = await Count.findOneAndUpdate({},{ $inc: {count:-1}},{
            new : true,
            upsert : true
          });
          console.log(counter.count);
        }
        catch(error)
        {
          console.log(error.message);
          res.status(500).json({ msg: "Server error" });
        }
        const d = new Date();

        const validRides = [];
        for (var i = 0; i < rides.length; i++) {
          if (compareTime(rides[i].timestamp, d)) {
            validRides.push({
              rideId: rides[i].rideId,
              username: rides[i].created_by,
              timestamp: rides[i].timestamp
            });
          }
        }

        if (validRides.length == 0) {
          return res.status(204).json({ msg: "Ride does not exist" });
        }

        return res.status(200).send(validRides);
      } catch (error) {
        console.log(error.message);
        return res.status(500).json({ msg: "Server error" });
      }
    } else {
      return res.status(400).json({});
    }
  })
  .all(methodNotAllowed);

router
  .route("/:rideId")
  .get(async (req, res) => {
    //list details of given ride
    const rideId = req.params.rideId;

    try {
      // Check if rideId exist
      let ride = await rp.post(config.get("DB_API_URI").READ, {
        json: {
          model: "Ride",
          parameters: {
            rideId: rideId
          }
        }
      });
      try {
      let counter = await Count.findOneAndUpdate({},{ $inc: {count:-1}},{
        new : true,
        upsert : true
      });
      console.log(counter.count);
      }
      catch(error)
      {
        console.log(error.message);
        res.status(500).json({ msg: "Server error" });
      }
      if (ride.length == 0) {
        return res.status(204).json({ msg: "Ride does not exist" });
      }

      const retRide = {
        rideId: ride[0].rideId,
        created_by: ride[0].created_by,
        users: ride[0].users,
        timestamp: ride[0].timestamp,
        source: ride[0].source,
        destination: ride[0].destination
      };

      return res.status(200).json(retRide);
    } catch (error) {
      console.log(error.message);
      res.status(500).json({ msg: "Server error" });
    }
  })
  .post(cors(Origin_Header),async (req, res) => {
    //join an existing ride
    if (!joiSchemas.joiValidate(joiSchemas.joinRide, req.body)) {
      return badRequest("Invalid params", req, res);
    }

    const rideId = req.params.rideId;
    const username = req.body.username;

    if (!((await rideExists({ rideId })) && (await userExists({ username }))))
      // Can this be 400 ?
      return res.status(204).json({ msg: "Not found" });

    try {
      const rides = await rp.post(config.get("DB_API_URI").READ, {
        json: {
          model: "Ride",
          parameters: { rideId }
        }
      });
      try {
        let counter = await Count.findOneAndUpdate({},{ $inc: {count:-1}},{
          new : true,
          upsert : true
        });
        console.log(counter.count);
      }
      catch(error)
      {
        console.log(error.message);
        res.status(500).json({ msg: "Server error" });
      }
      if (username === rides[0].created_by) {
        return badRequest("Invalid params", req, res);
      }

      let users = rides[0].users;
      let alreadyPresent = false;
      for (let i = 0; i < users.length; i++) {
        if (users[i] === username) {
          alreadyPresent = true;
          break;
        }
      }

      if (alreadyPresent) {
        return badRequest("Invalid params", req, res);
      }

      users.push(username);

      await rp.post(config.get("DB_API_URI").WRITE, {
        json: {
          model: "Ride",
          query: { rideId },
          update: { users },
          op: "update"
        }
      });
      try {
        let counter = await Count.findOneAndUpdate({},{ $inc: {count:-1}},{
          new : true,
          upsert : true
        });
        console.log(counter.count);
      }
      catch(error)
      {
        console.log(error.message);
        res.status(500).json({ msg: "Server error" });
      }
      return res.status(200).json({});
    } catch (error) {
      console.log(error.message);
      res.status(500).json({ msg: "Server error" });
    }
  })
  .delete(async (req, res) => {
    //delete a given ride
    // Check if the ride exist
    const rideId = req.params.rideId;

    try {
      let ride = await rp.post(config.get("DB_API_URI").READ, {
        json: {
          model: "Ride",
          parameters: {
            rideId: rideId
          }
        }
      });
      try {
        let counter = await Count.findOneAndUpdate({},{ $inc: {count:-1}},{
          new : true,
          upsert : true
        });
        console.log(counter.count);
      }
      catch(error)
      {
        console.log(error.message);
        res.status(500).json({ msg: "Server error" });
      }
      if (ride.length == 0) {
        return res.status(400).json({ msg: "Ride does not exist" });
      }

      await rp.post(config.get("DB_API_URI").WRITE, {
        json: {
          model: "Ride",
          parameters: { rideId },
          op: "del"
        }
      });
      try {
        let counter = await Count.findOneAndUpdate({},{ $inc: {count:-1}},{
          new : true,
          upsert : true
        });
        console.log(counter.count);
      }
      catch(error)
      {
        console.log(error.message);
        res.status(500).json({ msg: "Server error" });
      }
      res.status(200).json({});
    } catch (error) {
      console.log(error.message);
      res.status(500).json({ msg: "Server error" });
    }
  })
  .all(methodNotAllowed);

module.exports = router;
