from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_marshmallow import Marshmallow
from flask_restful import Resource, Api
import json
import os
import re
from constant import Area
from datetime import datetime
import requests
import ast
from sqlalchemy import Column, Integer, ForeignKey
from sqlalchemy.orm import relationship

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.ext.declarative import declarative_base
global create_all
count_all=0
################################################
#Flask App
app = Flask(__name__)
basedir=os.path.abspath(os.path.dirname(__file__))
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///"+os.path.join(basedir,'db.sqlite')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)
ma = Marshmallow(app)
api=Api(app)


class Rides(db.Model):
	rideId = db.Column(db.Integer, primary_key=True)
	created_by = db.Column(db.String, unique=False, nullable=False)
	timestamp = db.Column(db.String)
	source = db.Column(db.Integer, nullable=False)
	destination = db.Column(db.Integer, nullable=False)

	def __init__(self,created_by,timestamp,source,destination):
			self.created_by=created_by
			self.timestamp=timestamp
			#self.users=[users]

			self.source=source
			self.destination=destination

class RideSchema(ma.Schema):
	class Meta:
		fields=('rideId','created_by','timestamp','source','destination')

ride_schema = RideSchema()
rides_schema = RideSchema(many=True)

################################################

class Other_Users(db.Model):
	i = db.Column(db.Integer, primary_key=True)
	ID = db.Column(db.Integer, unique=False,nullable=False)
	user_names= db.Column(db.String, nullable=False)

	def __init__(self,ID,user_names):
		self.ID=ID
		self.user_names=user_names

class Other_UsersSchema(ma.Schema):
	class Meta:
		fields=('ID','user_names')

other_user_schema = Other_UsersSchema()
other_users_schema = Other_UsersSchema(many=True)

###############################################


#API 3
#ADD RIDE
@app.route("/api/v1/rides",methods=["POST"])
def addride():
	global count_all
	count_all=count_all+1	
	timeptrn=re.compile("((0[1-9]|[12][0-9]|3[01])-(0[13578]|1[02])-(18|19|20)[0-9]{2})|(0[1-9]|[12][0-9]|30)-(0[469]|11)-(18|19|20)[0-9]{2}|(0[1-9]|1[0-9]|2[0-8])-(02)-(18|19|20)[0-9]{2}|29-(02)-(((18|19|20)(04|08|[2468][048]|[13579][26]))|2000):[0-5][0-9]-[0-5][0-9]-(2[0-3]|[01][0-9])")

	created_by=request.get_json()["created_by"]
	timestamp=request.get_json()["timestamp"]
	source=request.get_json()["source"]
	destination=request.get_json()["destination"]
	

	try:
		datetime.strptime(timestamp, '%d-%m-%Y:%S-%M-%H')
	except:
		return jsonify({}), 400
	
	s=int(source) in Area._value2member_map_
	desti=int(destination) in Area._value2member_map_

	if(not(timeptrn.match(timestamp)) or not(s) or not(desti)):
		return 'timstamp2', 400 #if time is not valid
	
	d = dict()
	d['created_by'] = created_by
	d['timestamp'] = timestamp
	d['source'] = source
	d['destination'] = destination
	d['flag'] = 2

	w=requests.post("http://127.0.0.1:5000/api/v1/db/read", json=d)
	print(w.text)
	e =ast.literal_eval(w.text)

	if(e):
		d['flag'] = 3
		#return jsonify(d)
		r=requests.post("http://127.0.0.1:5000/api/v1/db/write", json=d)
		#return str(r.text)
		return jsonify({}), 201
	else :
		return jsonify({}), 400

#API 7
#DELETE RIDE
@app.route("/api/v1/rides/<ride_id>",methods=["DELETE"])
def deleterride(ride_id):
	global count_all
	count_all=count_all+1
	d=dict()
	d['flag']=3
	d['rideId']=ride_id

	w=requests.post("http://127.0.0.1:5000/api/v1/db/read", json=d)
	e=ast.literal_eval(w.text)

	if(e):
		d['flag']=4
		r=requests.post("http://127.0.0.1:5000/api/v1/db/write", json=d)
		return jsonify({}), 200
	else :
		return jsonify({}), 400

#SHOW ALL RIDES {FOR REFERENCE}
@app.route("/api/v1/db/showall")
def showall():
	all_rides=Rides.query.all()
	res=rides_schema.dump(all_rides)
	return jsonify(res)

########################################################

#API 4 : Remaining : printing format
#View ride details using source and destination
@app.route("/api/v1/rides",methods=["GET"])
def viewridesource():
	global count_all
	count_all=count_all+1
	source=request.args['source']
	dest =request.args['destination']

	d=dict()
	d['source']=source
	d['destination']=dest
	d['flag']= 7

	s=int(source) in Area._value2member_map_
	desti=int(dest) in Area._value2member_map_
	# print(s)
	#print(d)
	# print(type(source))
	# print(type(dest))
	if(s and desti ):
		rr1=requests.post("http://127.0.0.1:5000/api/v1/db/read", json=d)
		r =ast.literal_eval(rr1.text)
		if(r):
			return json.dumps(r), 200
		else:
			return jsonify({}), 204
	else:
		return 'invalid source/dest', 400


#########################################################
#API 5
#DISPLAY RIDE DETAILS
@app.route("/api/v1/rides/<ride_id>", methods=["GET"])
def viewridedetails(ride_id):
	global count_all
	count_all=count_all+1
	l=[]
	d = dict()
	d['flag'] = 3 #check if rideId exists in rides db
	d['rideId'] = ride_id
	exus1=requests.post("http://127.0.0.1:5000/api/v1/db/read", json=d)
	exus =ast.literal_eval(exus1.text)
	strss=exus

	di=dict()
	di['flag'] = 4  #to get ride details
	di['rideId'] = ride_id
	ride1=requests.post("http://127.0.0.1:5000/api/v1/db/read", json=di)
	ride =ast.literal_eval(ride1.text)
	
	
	dit = dict()
	dit['flag'] =  5 #check if rideId exists in other users db
	dit['rideId'] = ride_id
	ursr1=requests.post("http://127.0.0.1:5000/api/v1/db/read", json=dit)
	ursr =ast.literal_eval(ursr1.text)
	
	dito = dict()
	dito['flag'] = 6 #copy her 8 th one
	dito['rideId'] = ride_id
	r1=requests.post("http://127.0.0.1:5000/api/v1/db/read", json=dito)
	r =r1.json()
	r2=r['val']
	

	if(r2):
		ride_to=ride_schema.jsonify(ride)
		extract=db.session.query(Rides.rideId,Rides.created_by,Rides.timestamp,Rides.source,Rides.destination).filter_by(rideId = ride_id).one()
		ridiss=str(extract[0])
		cbss=str(extract[1])
		tsss=str(extract[2])
		sss=str(extract[3])
		dss=str(extract[4])
		dr={"rideId":''.join(ridiss),"created_by":''.join(cbss),"timestamp":''.join(tsss),"source":''.join(sss),"destination":''.join(dss)}
		ride_to=json.dumps(dr)
		usrss_to=other_user_schema.jsonify(ursr)
		usr = Other_Users.query.all()
		for urs in usr:
			if(urs.ID == int(ride_id)):
				l.append(urs.user_names)
		d={"usernames":l}
		usrss_to=json.dumps(d)
		dict1ss=eval(ride_to)
		dict2ss=eval(usrss_to)
		dict3ss={**dict1ss,**dict2ss}
		reslt=json.dumps(dict3ss)
		fnss={"rideId":dict3ss.get("rideId"),"created_by":dict3ss.get("created_by"),"users":dict3ss.get("usernames"),"timestamp":dict3ss.get("timestamp"),"source":dict3ss.get("source"),"destination":dict3ss.get("destination")}
		reslt=json.dumps(fnss)
		return reslt, 200
	else:
		if(request.method!="GET"):
			return jsonify({}), 405
		else:
			return jsonify({}), 400


#SHOW ALL USERS {FOR REFERENCE}
@app.route("/api/v1/users",methods=["GET"])
def show():
	all_users=User.query.all()
	re=users_schema.dump(all_users)
	#print(re)
	#re=[]
	if(not re):
		return (jsonify({}),204)
	if(request.method!="GET"):
		return (jsonify({}), 405)
	l=[]
	for i in re:
		for k in i.keys():
			if(k=="username"):
				l.append(i[k])
	#print("\n\n\n\n\n",l)

	return (jsonify(l),200)


#########################################################

#API 6
#Add other users
@app.route("/api/v1/rides/<rideId>", methods=["POST"])
def add_otheruser(rideId):
	global count_all
	count_all=count_all+1
	user_name=request.get_json()["username"]
	d = dict()
	d['rideId']= rideId
	d['username']=user_name
	

	d['flag'] = 1 #check if user exists
	u=requests.post("http://127.0.0.1:5000/api/v1/db/read", json=d)
	e1=ast.literal_eval(u.text)

	d['flag'] = 3 #check if ride exists
	u=requests.post("http://127.0.0.1:5000/api/v1/db/read", json=d)
	e2=ast.literal_eval(u.text)

	d['flag'] = 8 #check if the user to be added is the used who created the ride
	u=requests.post("http://127.0.0.1:5000/api/v1/db/read", json=d)
	e3=ast.literal_eval(u.text)

	d['flag'] = 9 #check if the user to be added is talready in users
	u=requests.post("http://127.0.0.1:5000/api/v1/db/read", json=d)
	e4=ast.literal_eval(u.text)

	# d['flag'] = 10 
	# u=requests.post("http://127.0.0.1:8000/api/v1/db/read", json=d)
	# e5=ast.literal_eval(u.text)

	#and e5
	if(e1 and e2 and e3 and e4):
		d['flag']=5
		r=requests.post("http://127.0.0.1:5000/api/v1/db/write", json=d)
		return jsonify({}), 200
	else :
		return jsonify({}), 400

#########################################################

#write API

@app.route("/api/v1/db/write",methods=["POST","DELETE"])
def writeToDB():
	flag = request.get_json()["flag"]
	if flag == 1:  #User add
		username = request.get_json()["username"]
		password = request.get_json()["password"]
		newUser=User(username,password)
		db.session.add(newUser)
		db.session.commit()
		return jsonify({})
	elif flag == 2 : #user delete
		username = request.get_json()["username"]
		User.query.filter_by(username=username).delete()
		Other_Users.query.filter_by(user_names=username).delete()
		Rides.query.filter_by(created_by=username).delete()
		db.session.commit()
		return jsonify({})
	elif flag == 3: #add ride
		hey=request.get_json()["created_by"]
		timestamp=request.get_json()["timestamp"]
		source=request.get_json()["source"]
		destination=request.get_json()["destination"]
		newRide=Rides(hey,timestamp,source,destination)
		db.session.add(newRide)
		db.session.commit()
		#return "hi"
		return jsonify({})
	elif flag == 4 : #delete ride
		rideId = request.get_json()["rideId"]
		Rides.query.filter_by(rideId=rideId).delete()
		Other_Users.query.filter_by(ID=rideId).delete()
		db.session.commit()
		print("Ride Deleted")
		return jsonify({})
	elif flag == 5 : #Add other user
		ID = request.get_json()["rideId"]
		username = request.get_json()["username"]
		new=Other_Users(ID,username)
		db.session.add(new)
		db.session.commit()
		return jsonify({})


###########################################################

#read API

@app.route("/api/v1/db/read",methods=["GET","PUT","POST","DELETE"])
def readFromDB():
	flag = request.get_json()["flag"]
	if flag == 1:  #check if username is present
		username = request.get_json()["username"]
		u=bool(User.query.filter_by(username = username).first())
		l=requests.get("http://blah-1407759756.us-east-1.elb.amazonaws.com/api/v1/users")
		print("\n\n\n\n\n",type(l),"\n\n\n\n\n")
		l=l.json()
		if(username in l):
		#if(u):
			return "1"
		else:
			return "0"
	elif flag == 2: #check if createby is present in users db
		username = request.get_json()["created_by"]
		u=bool(User.query.filter_by(username = username).first())
		l=requests.get("http://blah-1407759756.us-east-1.elb.amazonaws.com/api/v1/users")
		print("\n\n\n\n\n",type(l),"\n\n\n\n\n")
		l=l.json()
		if(username in l):
		#if(u):
			return "1"
		else:
			return "0"
	elif flag == 3: #check if ride is present
		rideId = request.get_json()["rideId"]
		u=bool(Rides.query.filter_by(rideId = rideId).first())
		if(u):
			return "1"
		else:
			return "0"
	elif flag == 4:
		rideId = request.get_json()["rideId"]
		ride = db.session.query(Rides.rideId, Rides.created_by, Rides.timestamp,Rides.source, Rides.destination).filter_by(rideId = rideId).all()
		return jsonify(ride)
	elif flag == 5:
		rideId = request.get_json()["rideId"]
		ursr= db.session.query(Other_Users.user_names).filter_by(ID = rideId).all()
		return jsonify(ursr)
	elif flag == 6:
		rideId = request.get_json()["rideId"]
		r=bool(Rides.query.filter_by(rideId = rideId).first())
		return jsonify({'val':r})	
	elif flag == 7: #source/destination - display ride details
		sourceok=request.get_json()['source']
		dest =request.get_json()['destination']
		now=datetime.utcnow()
		s1=now.strftime("%d-%m-%Y:%S-%M-%H")
		d1=datetime.strptime(s1, "%d-%m-%Y:%S-%M-%H")

		srcc = db.session.query(Rides).filter_by(source = sourceok, destination=dest).with_entities(Rides.rideId,Rides.created_by,Rides.timestamp).all()
		print("\n\n\n\n",srcc,"\n\n\n\n")
		temp = srcc.copy()
		for use in temp:
			s2=use.timestamp
			d2=datetime.strptime(s2,"%d-%m-%Y:%S-%M-%H")
			k=str(d2-d1)
			print("\n\n\n\n",k,"\n\n\n\n")
			user_data={}
			if(k[0]=="-"):
				srcc.remove(use)
		r_schema = RideSchema(many=True)
		print("\n\n\n\n",srcc,"\n\n\n\n")
		ress= r_schema.dump(srcc)
		dnew=dict()
		l=[]
		for i in ress:
			print()
			dnew=dict()
			for k in i.keys():
				dnew["username"]=i["created_by"]
				dnew["timestamp"]=i["timestamp"]
				dnew["rideId"]=i["rideId"]
			l.append(dnew)
		print("\n\n\n THE NEW LIST",l)
		return jsonify(l)

	elif flag == 8:
		rideId=request.get_json()['rideId']
		username=request.get_json()['username']
		r=bool(Rides.query.filter_by(rideId = rideId, created_by=username).first())
		if(r):
			return "0"
		else:
			return "1"
	elif flag ==9 :
		rideId=request.get_json()['rideId']
		username=request.get_json()['username']
		r=bool(Other_Users.query.filter_by(ID = rideId, user_names=username).first())
		if(r):
			return "0"
		else:
			return "1"

#CLEAR DB
@app.route("/api/v1/db/clear",methods=["POST"])
def clear_data():
	global count_all
	count_all=count_all+1
	meta = db.metadata
	for table in reversed(meta.sorted_tables):
		db.session.execute(table.delete())
	db.session.commit()
	return jsonify(),200

#Show the count of number of of rides
@app.route("/api/v1/rides/count")
def countrides():
	all_rides=Rides.query.all()
	print("\n\n\n\n",all_rides)
	ll=[]
	llv=len(all_rides)
	ll.append(llv)
	return jsonify(ll), 200

@app.route("/api/v1/_count",methods=["GET"])
def returncount():
	l=[]
	l.append(count_all)
	return jsonify(l),200

@app.route("/api/v1/_count",methods=["DELETE"])
def resetcount():
	global count_all
	count_all=0
	return jsonify({}),200


if __name__ == '__main__':
	app.debug=True
	app.run(host="0.0.0.0")
		

