import re
import os
import ast
import requests
import json
import csv
import collections
from flask_api import status
from datetime import datetime
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.exc import IntegrityError, OperationalError, SQLAlchemyError
from flask import Flask, jsonify, request, abort,redirect, url_for, session, Response, _request_ctx_stack

app = Flask(__name__)
app.config['SECRET_KEY'] = "Ride Share api"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///rides.db'

location = collections.defaultdict(str)
with open('AreaNameEnum.csv', 'r') as fin:
    dictr = csv.DictReader(fin)
    for line in dictr:
        location[int(line['Area No'])] = line['Area Name']

session_options = {'autocommit':False, 'autoflush':False}
db = SQLAlchemy(app)

# DNS Application Loadbalancer
dns_ALB = 'path-based-alb-973289095.us-east-1.elb.amazonaws.com'

SHA1 = re.compile(r'\b[a-fA-F0-9]{40}\b')
ddformat = re.compile(r'\d{2}-\d{2}-\d{4}:\d{2}-\d{2}-\d{2}')
headers = {'Content-Type': 'application/json', 'Accept':'application/json'}
writeURL = 'http://rides:5000/api/v1/db/write'
readURL = 'http://rides:5000/api/v1/db/read'
METHODS = ['GET', 'PUT', 'POST', 'DELETE', 'PATCH', 'COPY', 'HEAD', 'OPTIONS', 'LINK'
                , 'UNLINK', 'PURGE', 'LOCK', 'UNLOCK', 'PROPFIND', 'VIEW']

class Rides(db.Model):
    __tablename__ = "rides"
    ride_id = db.Column('ride_id', db.Integer, primary_key=True)
    created_by = db.Column('created_by', db.String(100), nullable=False)
    timestamp = db.Column('timestamp', db.String(100), nullable=False)
    source = db.Column('source', db.Integer, nullable=False)
    destination = db.Column('destination', db.Integer, nullable=False)
    joined_users = db.Column('joined_users',db.String(1000),nullable=False)

    def __init__(self, created_by, timestamp, source, destination,joined_users):
        self.created_by = created_by
        self.timestamp = timestamp
        self.source = source
        self.destination = destination
        self.joined_users=joined_users

class Count(db.Model):
    __tablename__ = 'count'
    base_count = db.Column('count_id', db.Integer, primary_key=True)
    rides_count = db.Column('rides_count', db.Integer, nullable=False)
    def __init__(self, rides_count):
        self.rides_count = rides_count

db.create_all()

quer_count = db.session.query(Count).filter_by(base_count=1)
if(quer_count.scalar() is None):
    baseC = Count(0)
    db.session.add(baseC)
    db.session.commit()

# 0. Healthcheck ALB
@app.route('/api/v1/healthcheck', methods = ['GET'])
def healthcheck():
    return Response(status=status.HTTP_200_OK)

# 1.Add Ride (Done)
@app.route('/api/v1/rides',methods = ['POST'])
def AddRide():
    if(request.method=='POST'):
        quer_res = db.session.query(Count).filter_by(base_count = 1).all()
        rideC = quer_res[0].rides_count
        db.session.query(Count).filter_by(base_count = 1).update(dict(rides_count=rideC+1))
        db.session.commit()

        req = request.get_json()
        uname = req['created_by']
        checkuser = {'table':'Users', 'method':'existence', 'where': uname}
        #ip = requests.get('https://checkip.amazonaws.com').text[:-1]
        #Exists = (requests.post('http://'+ip+':8080/api/v1/db/read', data = json.dumps(checkuser), headers = headers)).json()
        #Exists = requests.get('http://'+ip+':8080/api/v1/users', headers = headers)
        Exists = requests.get('http://'+dns_ALB+'/api/v1/users', headers = {'Content-Type': 'application/json', 'Accept':'application/json', 'origin':'34.194.83.184'})
        currtime = datetime.now().strftime('%d-%m-%Y:%S-%M-%H')
        #print(Exists['Exists'], 'jwoptjwoptjwtj')
        if(Exists.status_code == 204):
            return Response(status=400)
        elif(uname in ast.literal_eval(Exists.text) and (ddformat.match(req['timestamp']) is not None) and (currtime < req['timestamp'])):
            addride = {"table" : "Ride" , "insert": req}
            response = (requests.post(writeURL, data = json.dumps(addride), headers = headers)).json()
            return Response(status=response['status_code'])
        else:
            return Response(status=status.HTTP_400_BAD_REQUEST)
    return Response(status=status.HTTP_405_METHOD_NOT_ALLOWED)


# 2.Fetch Rides (Done)
@app.route('/api/v1/rides',methods = ['GET'])
def FetchRides():
    if(request.method=='GET'):
        quer_res = db.session.query(Count).filter_by(base_count = 1).all()
        rideC = quer_res[0].rides_count
        db.session.query(Count).filter_by(base_count = 1).update(dict(rides_count=rideC+1))
        db.session.commit()

        source = int(request.args.get('source'))
        destination = int(request.args.get('destination'))
        if(source == None or destination == None or not(source in location) or not(destination in location)):
            return Response(status=status.HTTP_204_NO_CONTENT)
        currtime = datetime.now().strftime('%d-%m-%Y:%S-%M-%H')
        queryride = {'table': 'Rides', 'method':'query', "columns" : ['timestamp', 'source', 'destination']
                       , "where" : [currtime, source, destination]}
        response = (requests.post(readURL, data = json.dumps(queryride), headers = headers)).json()
        if(len(response['Result'])>0):
            return jsonify(response['Result'])
        return Response(status=status.HTTP_204_NO_CONTENT)
    return Response(status=status.HTTP_405_METHOD_NOT_ALLOWED)


# 3.List Rides (Done)
@app.route('/api/v1/rides/<rideId>',methods=['GET'])
def listrides(rideId):
    if(request.method=='GET'):
        quer_res = db.session.query(Count).filter_by(base_count = 1).all()
        rideC = quer_res[0].rides_count
        db.session.query(Count).filter_by(base_count = 1).update(dict(rides_count=rideC+1))
        db.session.commit()

        checkride = {'table':'Rides', 'method':'existence', 'where': int(rideId)}
        Exists = (requests.post(readURL, data = json.dumps(checkride), headers = headers)).json()
        if(Exists['Exists']):
            getride={'table':'Rides', 'method': 'list_details','where': int(rideId)}
            response = (requests.post(readURL, data = json.dumps(getride), headers = headers)).json()
            return jsonify(response['Result'][0])
        else:
            return Response(status=status.HTTP_204_NO_CONTENT)
    return Response(status=status.HTTP_405_METHOD_NOT_ALLOWED)

# 4.Join an existing ride (Done)
@app.route('/api/v1/rides/<rideId>',methods=['POST'])
def joinride(rideId):
    if(request.method=='POST'):
        quer_res = db.session.query(Count).filter_by(base_count = 1).all()
        rideC = quer_res[0].rides_count
        db.session.query(Count).filter_by(base_count = 1).update(dict(rides_count=rideC+1))
        db.session.commit()

        req = request.get_json()
        #checkuser = {'table':'Users', 'method':'existence', 'where': req['username']}
        #ip = requests.get('https://checkip.amazonaws.com').text[:-1]
        #Existuser = (requests.post('http://'+ip+':8080/api/v1/db/read', data = json.dumps(checkuser), headers = headers)).json()
        #Existuser = requests.get('http://'+ip+':8080/api/v1/users', headers=headers)
        Existuser = requests.get('http://'+dns_ALB+'/api/v1/users', headers = {'Content-Type': 'application/json', 'Accept':'application/json', 'origin':'34.194.83.184'})
        checkride = {'table':'Rides', 'method':'existence', 'where': int(rideId)}
        Existride = (requests.post(readURL, data = json.dumps(checkride), headers = headers)).json()
        if(Existuser.status_code==204):
            return Response(status=204)
        elif(req['username'] in ast.literal_eval(Existuser.text) and Existride['Exists']):
            joinride={'table':'Rides', 'method':'join','where': [req['username'], int(rideId)]}
            response = (requests.post(writeURL, data = json.dumps(joinride), headers = headers)).json()
            return Response(status=response['status_code'])
        else:
            return Response(status=status.HTTP_204_NO_CONTENT)
    return Response(status=status.HTTP_405_METHOD_NOT_ALLOWED)


# 5.Delete Ride (Done)
@app.route('/api/v1/rides/<rideId>', methods = ['DELETE'])
def DeleteRide(rideId):
    if request.method=='DELETE':
        quer_res = db.session.query(Count).filter_by(base_count = 1).all()
        rideC = quer_res[0].rides_count
        db.session.query(Count).filter_by(base_count = 1).update(dict(rides_count=rideC+1))
        db.session.commit()

        checkride = {'table':'Rides', 'method':'existence', 'where': int(rideId)}
        Exists = (requests.post(readURL, data = json.dumps(checkride), headers = headers)).json()
        if(Exists['Exists']):
            delride = {"table" : "Rides" , "delete" : rideId}
            response = (requests.post(writeURL, data = json.dumps(delride), headers = headers)).json()
            return Response(status=response['status_code'])
        else:
            return Response(status=status.HTTP_400_BAD_REQUEST)
    return Response(status=status.HTTP_405_METHOD_NOT_ALLOWED)

@app.after_request
def after_request_callback(response):
    path = _request_ctx_stack.top.request.url
    if(response.status == '405 METHOD NOT ALLOWED' and '/api/v1/_count' not in path and '/db/clear' not in path):
        quer_res = db.session.query(Count).filter_by(base_count = 1).all()
        rideC = quer_res[0].rides_count
        db.session.query(Count).filter_by(base_count = 1).update(dict(rides_count=rideC+1))
        db.session.commit()
    return response

#count_api
@app.route('/api/v1/_count', methods = ['GET'])
def Count_Call():
    if(request.method=='GET'):
        quer_res = db.session.query(Count).filter_by(base_count = 1).all()
        res = []
        res.append(quer_res[0].rides_count)
        return jsonify(res)
    return Response(status=status.HTTP_405_METHOD_NOT_ALLOWED)

#Reset
@app.route('/api/v1/_count', methods = ['DELETE'])
def Reset_Count():
    if(request.method=='DELETE'):
        db.session.query(Count).filter_by(base_count = 1).update(dict(rides_count=0))
        db.session.commit()
        return Response(status=status.HTTP_200_OK)
    return Response(status=status.HTTP_405_METHOD_NOT_ALLOWED)

# Get number of rides
@app.route('/api/v1/rides/count', methods = ['GET'])
def Rides_Count():
    if(request.method=='GET'):
        quer_res = db.session.query(Count).filter_by(base_count = 1).all()
        rideC = quer_res[0].rides_count
        db.session.query(Count).filter_by(base_count = 1).update(dict(rides_count=rideC+1))
        db.session.commit()

        getrides={'table':'Rides', 'method': 'list_rides'}
        response = (requests.post(readURL, data = json.dumps(getrides), headers = headers)).json()
        res = []
        res.append(len(response['Result']))
        return jsonify(res)
    return Response(status=status.HTTP_405_METHOD_NOT_ALLOWED)

#6. DB Write
@app.route('/api/v1/db/write', methods = ['POST'])
def DBWrite():
    if(request.method == 'POST'):
        Request = (request.get_data()).decode()
        Request = ast.literal_eval(Request)
        if('insert' in Request):
            try:
                if(Request['table'] == 'Ride'):
                    obj= Rides(created_by=Request['insert']['created_by'], timestamp=Request['insert']['timestamp']
                    , source=int(Request['insert']['source']), destination=int(Request['insert']['destination']) , joined_users='')
                db.session.add(obj)
                db.session.commit()
            except IntegrityError:
                db.session.rollback()
                return {'status_code': 400}
            return {'status_code': 201}
        elif('delete' in Request):
            if(Request['table'] == 'Rides'):
                db.session.query(Rides).filter_by(ride_id = Request['delete']).delete()
            db.session.commit()
            return {'status_code': 200}
        elif(Request['table']=='Rides' and Request['method']=='join'):
            quer_res = db.session.query(Rides).filter_by(ride_id = Request['where'][1]).all()
            if((Request['where'][0] not in quer_res[0].joined_users) and (Request['where'][0] not in quer_res[0].created_by)):
                newusersadded = quer_res[0].joined_users+"$#"+Request['where'][0]
                db.session.query(Rides).filter_by(ride_id=Request['where'][1]).update(dict(joined_users=newusersadded))
                db.session.commit()
                return {'status_code': 200}
        elif(Request['table']=='Rides' and Request['method']=='delete_for_user'):
            db.session.query(Rides).filter_by(created_by = Request['per_delete']).delete()
            db.session.commit()
            return {'test':'return'}
    return {'status_code': 405}

#7. DB Read
@app.route('/api/v1/db/read', methods = ['POST'])
def DBRead():
    if(request.method=='POST'):
        Request = (request.get_data()).decode()
        Request = ast.literal_eval(Request)
        if(Request['table']=='Rides'):
            if(Request['method']=='query'):
                quer_res = db.session.query(Rides).filter_by(source = Request['where'][1]).filter_by(destination = Request['where'][2]).all()
                response_all = []
                for row in quer_res:
                    rowd = {}
                    if row.timestamp > Request['where'][0]:
                        rowd['rideId'] = row.ride_id
                        rowd['username'] = row.created_by
                        rowd['timestamp'] = row.timestamp
                        response_all.append(rowd)
                response = {"Result" : response_all}

            if(Request['method']=='list_details'):
                quer_res = db.session.query(Rides).filter_by(ride_id=Request['where'])
                response_all = []
                for row in quer_res:
                    rowd = {}
                    rowd['rideId'] = row.ride_id
                    rowd['Created_by'] = row.created_by
                    rowd['users']=((row.joined_users).split('$#'))[1:]
                    rowd['Timestamp'] = row.timestamp
                    rowd['source']=row.source
                    rowd['destination']=row.destination
                    response_all.append(rowd)
                response = {"Result" : response_all}

            if(Request['method']=='existence'):
                quer_res = db.session.query(Rides).filter_by(ride_id = Request['where'])
                if(quer_res.scalar() is None):
                    response = {"Exists": 0}
                else:
                    response = {"Exists": 1}
            if(Request['method']=='list_rides'):
                quer_res = db.session.query(Rides).all()
                response_all = []
                for row in quer_res:
                    response_all.append(row.ride_id)
                response = {"Result" : response_all}

            if(Request['method']=='list_rides'):
                quer_res = db.session.query(Rides).all()
                response_all = []
                for row in quer_res:
                    response_all.append(row.ride_id)
                response = {"Result" : response_all}
            return response
    return {'status_code': 405}

# 11.Clear Database[MAKE TWO COPIES, ONE IN EACH CONTAINER]
@app.route('/api/v1/db/clear',methods=['POST'])
def DBClear():
    if(request.method=='POST'):
        getrides={'table':'Rides', 'method': 'list_rides'}
        response = (requests.post(readURL, data = json.dumps(getrides), headers = headers)).json()
        db.session.query(Rides).delete()
        db.session.commit()
        return Response(status=status.HTTP_200_OK)
    return Response(status=status.HTTP_405_METHOD_NOT_ALLOWED)

if(__name__ == '__main__'):
    app.run(debug=True, host='0.0.0.0')