#Learn more or give us feedback
from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy

import requests
import os
import sys

from datetime import datetime
import csv

basedir = os.path.abspath(os.path.dirname(__file__))

application = Flask(__name__)
application.config["DEBUG"] = True
application.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///" + \
    os.path.join(basedir, "db.sqlite")

db = SQLAlchemy(application)

db_write_url = "http://172.17.0.1:80/api/v1/db/write"
db_read_url = "http://172.17.0.1:80/api/v1/db/read"
db_clear_url = "http://172.17.0.1:80/api/v1/db/clear"

user_url = "http://172.17.0.1:80/api/v1/db/read"   
# (above) this needs to be replaced by the load balancer ip so 
# it gets routed to load balancer and then to the users

load_balancer_ip = "http://RideSharing-492995951.us-east-1.elb.amazonaws.com" #load balancer ip
origin = {"Origin": "52.0.98.58"} #rides instance elastic ip

count = 0
method = ["GET","PUT","POST","HEAD"]

@application.route("/api/v1/rides/test")
def hello():
    return "In Rides"

class Places(db.Model):
    place_id = db.Column(db.Integer(), primary_key=True, autoincrement=False)
    name = db.Column(db.Text())


class Ride(db.Model):
    ride_id = db.Column(db.Integer(), primary_key=True, autoincrement=True)
    creator = db.Column(db.Text(), nullable=False)

    source_id = db.Column(db.Integer(), db.ForeignKey(
        "places.place_id"), nullable=False)
    destination_id = db.Column(db.Integer(), db.ForeignKey(
        "places.place_id"), nullable=False)

    timestamp = db.Column(db.DateTime(), nullable=False)


class Share(db.Model):
    index = db.Column(db.Integer(), primary_key=True, autoincrement=True)
    ride_id = db.Column(db.Integer(), db.ForeignKey(
        "ride.ride_id"), nullable=False)
    username = db.Column(db.Text(), nullable=False)


def create_db():
    db.create_all()
    place = Places.query.first()
    if(place is None):
        with open("AreaNameEnum.csv") as csv_file:
            rows = list(csv.reader(csv_file, delimiter=","))[1:]
            for num, name in rows:
                num = int(num)
                place = Places(place_id=num, name=name)
                db.session.add(place)
        db.session.commit()


@application.route("/api/v1/rides", methods=method)
def ride_create_list():
    global count
    count += 1

    if(request.method == "POST"):
        data = request.get_json()
        in_flag = False
        try:
            name = data['created_by']
            source = int(data['source'])
            destination = int(data['destination'])
            timestamp = data['timestamp']
            dt = datetime.strptime(timestamp, "%d-%m-%Y:%S-%M-%H")
            now = datetime.now()
        except:
            in_flag = True

        with open('testcases.csv','a',newline='') as fd:
            writer = csv.writer(fd)
            writer.writerow([name,source,destination,dt])
        source_query_dict = {"method": "select",
                             "table": "places",
                             "columns": ["id"],
                             "values": [source]
                             }

        destination_query_dict = {"method": "select",
                                  "table": "places",
                                  "columns": ["id"],
                                  "values": [destination]
                                  }

        name_query_dict = {"method": "select",
                           "table": "user",
                           "columns": ["username"],
                           "values": [name]
                           }

        name_response = requests.post(load_balancer_ip+
            "/api/v1/users",header=origin, json=name_query_dict).json()["results"]
        source_response = requests.post(
            db_read_url, json=source_query_dict).json()["results"]
        destination_response = requests.post(
            db_read_url, json=destination_query_dict).json()["results"]

        if (name_response == [] or source_response == [] or destination_response == [] or dt < now or in_flag):
            response_msg = {'response': 'Invalid Input.'}
            status = 400
        else:
            insert_dict = {"method": "insert",
                           "table": "ride",
                           "columns": ["creator", "source_id", "destination_id", "timestamp"],
                           "values": [name, source, destination, timestamp]
                           }
            requests.post(db_write_url, json=insert_dict)
            response_msg = {
                "response": "Ride created succesfully"}
            status = 201
    else:
        source = request.args.get('source')
        destination = request.args.get('destination')

        destination_query_dict = {"method": "select",
                                  "table": "places",
                                  "columns": ["id"],
                                  "values": [destination]
                                  }

        source_query_dict = {"method": "select",
                             "table": "places",
                             "columns": ["id"],
                             "values": [source]
                             }

        source_response = requests.post(
            db_read_url, json=source_query_dict).json()["results"]
        destination_response = requests.post(
            db_read_url, json=destination_query_dict).json()["results"]

        if (source_response == [] or destination_response == []):
            response_msg = {'response': 'Input details not correct'}
            status = 400
        else:
            query_dict = {"method": "select",
                          "table": "ride",
                          "columns": ["source", "destination"],
                          "values": [source, destination]
                          }
            query_response = requests.post(
                db_read_url, json=query_dict).json()["results"]

            if(query_response == []):
                response_msg = {'response': 'No rides available'}
                status = 204
            else:
                response_msg = []
                for ride_id, user, timestamp in query_response:
                    response_msg.append({"rideId": ride_id,
                                         "username": user,
                                         "timestamp": timestamp
                                         })
                status = 200
    return jsonify(response_msg), status

#___________________________________________________________________#
#                             Abhishek                              #
#___________________________________________________________________#


@application.route("/api/v1/rides/<ride_id>", methods=method)
def ride_details(ride_id):
    global count
    count += 1

    ride_query_dict = {"method": "select",
                       "table": "ride",
                       "columns": ["id"],
                       "values": [ride_id]
                       }

    response = requests.post(
        db_read_url, json=ride_query_dict).json()["results"]

    print(response)
    if(response == []):
        response_msg = {"response": "Ride does not exist"}
        if(request.method == "GET"):
            status = 204
        else:
            status = 400
    else:
        if(request.method == "GET"):
            ride_id, creator, timestamp, source_id, destination_id = response

            ride_query_dict["table"] = "share"
            shares = requests.post(db_read_url, json=ride_query_dict).json()[
                "results"]

            ride_query_dict["table"] = "places"
            ride_query_dict["values"] = [source_id]
            source = requests.post(db_read_url, json=ride_query_dict).json()[
                "results"][1]

            ride_query_dict["values"] = [destination_id]
            destination = requests.post(db_read_url, json=ride_query_dict).json()[
                "results"][1]

            users = [i[1] for i in shares]
            response_msg = {
                "rideID": ride_id,
                "Created_by": creator,
                "users": users,
                "Timestamp": timestamp,
                "source": source,
                "destination": destination
            }
            status = 200

        elif(request.method == "POST"):
            name = request.get_json()['username']

            query_dict = {"method": "select",
                          "columns": ["username"],
                          "table": "user",
                          "values": [name]
                          }

            user_response = requests.post(load_balancer_ip+
                "api/v1/users",header=origin, json=query_dict).json()["results"]
            if(user_response == []):
                response_msg = {"response": "User does not exist"}
                status = 400
            elif(response[1] == name):
                response_msg = {"response": "User joining his ride."}
                status = 400
            else:
                share_dict = {"method": "insert",
                              'table': "share",
                              'columns': ['id', "name"],
                              'values': [ride_id, name]
                              }

                response = requests.post(db_write_url, json=share_dict)
                response_msg = {'msg': 'User added succesfully'}
                status = 200

        else:
            ride_query_dict["method"] = "delete"
            response = requests.post(
                db_write_url, json=ride_query_dict)
            response_msg = {"response": "Ride deleted."}
            status = 200

    return jsonify(response_msg), status


@application.route("/api/v1/rides/count", methods=method)
def ride_count():
    global count
    count += 1

    query_dict = {"method": "select",
                  "columns": ["count"],
                  "table": "ride",
                  "values": []
                  }

    response_msg = requests.post(
        db_read_url, json=query_dict).json()["results"]

    return jsonify(response_msg), 200

#___________________________________________________________________#
#                             Vishwas                               #
#___________________________________________________________________#


@application.route("/api/v1/db/write", methods=["POST"])
def db_write():
    data = request.get_json()

    if(data["method"] == "insert"):
        if(data["table"] == "ride"):
            time = datetime.strptime(
                data["values"][3], "%d-%m-%Y:%S-%M-%H")
            ride = Ride(creator=data["values"][0], source_id=data["values"]
                        [1], destination_id=data["values"][2], timestamp=time)
            db.session.add(ride)
            db.session.commit()
            response = {"response": "Ride inserted"}
            status = 200
        elif(data["table"] == "share"):
            share = Share(ride_id=data["values"][0],
                          username=data["values"][1])
            db.session.add(share)
            db.session.commit()
        else:
            response = {"response": "Table Not Present"}
            status = 405

    elif(data["method"] == "delete"):
        if(data["table"] == "ride"):
            ride = Ride.query.filter_by(ride_id=data["values"][0]).first()
            if(ride is not None):
                db.session.delete(ride)
                db.session.commit()
                response = {"response": "Ride deleted"}
                status = 200
            else:
                response = {"response": "Ride not present"}
                status = 405
        else:
            response = {"response": "Table Not Present"}
            status = 405

    else:
        response = {"response": "Method Not Supported"}
        status = 405

    return jsonify(response), status


@application.route("/api/v1/db/read", methods=["POST"])
def db_read():
    data = request.get_json()
    res = []
    status = 200
    if(data["method"] == "select"):
        if(data["table"] == "places"):
            place = Places.query.filter_by(place_id=data["values"][0]).first()
            if(place is not None):
                res = [place.place_id, place.name]
            response = {"results": res}

        elif(data["table"] == "ride"):
            if(data["columns"][0] == "id"):
                ride = Ride.query.filter_by(ride_id=data["values"][0]).first()
                if(ride is not None):
                    time = ride.timestamp
                    time = time.strftime("%d-%m-%Y:%S-%M-%H")
                    res = [ride.ride_id, ride.creator, time,
                           ride.source_id, ride.destination_id]
            elif(data["columns"][0] == "count"):
                rides = Ride.query.all()
                res = [len(rides)]
            else:
                time_now = datetime.now()
                rides = Ride.query.filter_by(
                    source_id=data["values"][0], destination_id=data["values"][1]).all()
                if(rides is not None):
                    for ride in rides:
                        time = ride.timestamp
                        if(time >= time_now):
                            time = time.strftime("%d-%m-%Y:%S-%M-%H")
                            res.append([ride.ride_id, ride.creator, time])
            response = {"results": res}
        elif(data["table"] == "share"):
            shares = Share.query.filter_by(ride_id=data["values"][0]).all()
            if(shares is not None):
                for share in shares:
                    res.append([share.ride_id, share.username])
                response = {"results": res}
        else:
            response = {"response": "Table Not Present"}
            status = 405

    else:
        response = {"response": "Method Not Supported"}
        status = 405

    return jsonify(response), status


@application.route("/api/v1/db/clear", methods=["POST"])
def db_clear():
    meta = db.metadata
    for table in reversed(meta.sorted_tables):
        db.session.execute(table.delete())
    db.session.commit()
    create_db()
    return jsonify("DB deleted."), 200


@application.route("/api/v1/_count", methods=["GET", "DELETE"])
def count_request():
    global count
    if(request.method == "GET"):
        response_msg = [count]
    else:
        count = 0
        response_msg = []
    return jsonify(response_msg), 200


if __name__ == "__main__":
    create_db()
    application.run(debug=True,port=80,host="0.0.0.0")