#!/usr/bin/env python3


import sys
import os


from gevent import monkey
monkey.patch_all()


import requests
import flask
import datetime
from threading import Lock
from gevent.pywsgi import WSGIServer


app = flask.Flask(__name__)
usersapi_host = os.environ['USERSAPI_HOST']
usersdb_host = os.environ['USERSDB_HOST']
ridesdb_host = os.environ['RIDESDB_HOST']
publicip = requests.get('http://checkip.amazonaws.com/').text.strip()
n_requests = 0
n_requests_lock = Lock()


def increment_requests():

    global n_requests

    n_requests_lock.acquire()
    try:
        n_requests += 1
    finally:
        n_requests_lock.release()


@app.before_request
def before_request():

    non_increment_paths = ('/', '/api/v1/_count', '/api/v1/db/clear')

    inc_flag = True

    if flask.request.path in non_increment_paths:
        inc_flag = False

    if inc_flag:
        increment_requests()


@app.route('/', methods=['GET'])
def index():

    return flask.jsonify({}), 200


# API 3: Create a new ride (POST)
# API 4: List all the upcoming rides for a given source and destination (GET)
@app.route('/api/v1/rides', methods=['GET', 'POST'])
def createAndListRides():

    try:

        if flask.request.method == 'GET':

            query = {
                'source': flask.request.args.get('source'),
                'destination': flask.request.args.get('destination')
            }
            print('GET: source=', query['source'], '&destination=',
                  query['destination'], sep='')

            json = {
                'table': 'rides',
                'where': 'source=' + query['source'] + \
                         '&destination=' + query['destination']
            }

            f = open('AreaNameEnum.csv')
            data = dict()
            for line in f.readlines()[1:]:
                l, r = line.strip().split(',')
                data[l] = r
            f.close()

            source = query['source']
            dest = query['destination']
            if source not in data.keys() or \
               dest not in data.keys() or \
               source == dest:
                raise ValueError('invalid source/destination')

            resp = requests.post(ridesdb_host + '/api/v1/db/read', json=json)

            if resp.status_code not in (200, 204):
                raise ValueError('database read failed')

            if resp.status_code == 204:
                return flask.Response(status=204)
            else:
                temp = resp.json()
                resp_data = [None for i in range(len(temp))]
                for i, ride_id_hex in enumerate(temp):
                    tmp_json = temp[ride_id_hex]
                    timestamp = tmp_json['timestamp']
                    accept = datetime.datetime.strptime(timestamp,
                                               '%d-%m-%Y:%S-%M-%H') \
                                            > datetime.datetime.now()
                    if accept:
                        tmp_json['rideId'] = str(int(ride_id_hex, 16))
                        tmp_json['username'] = tmp_json['created_by']
                        del tmp_json['created_by']
                        del tmp_json['source']
                        del tmp_json['destination']
                        resp_data[i] = tmp_json
                resp_data = list(filter(lambda x: x is not None,
                                        resp_data))
                return flask.jsonify(resp_data), 200


        else: # POST

            ride = flask.request.get_json()
            print('POST:', ride)
            source = ride['source'].strip()
            dest = ride['destination'].strip()
            user = ride['created_by']
            timestamp = ride['timestamp']

            headers = {'Origin': publicip}
            if flask.request.host.startswith('ridesharing') and \
               flask.request.host.endswith('amaznonaws.com') and \
               'Via' in flask.request.headers:
                host = flask.request.host
            else:
                host = usersapi_host
            resp = requests.get(host + '/api/v1/users',
                                headers=headers)
            if resp.status_code == 200:
                if user in resp.json():
                    exists = True
                else:
                    exists = False
            elif resp.status_code == 204:
                exists = False
            else:
                raise ValueError('bad request')

            if not exists:
                raise ValueError('user does not exist')

            f = open('AreaNameEnum.csv')
            data = dict()
            for line in f.readlines()[1:]:
                l, r = line.strip().split(',')
                data[l] = r
            f.close()

            if source not in data.keys() or \
               dest not in data.keys() or \
               source == dest:
                raise ValueError('invalid source/destination')

            datetime.datetime.strptime(timestamp, '%d-%m-%Y:%S-%M-%H')

            ride['users'] = []  # users who joined (excluding creator)

            # if execution reaches here, input is valid
            json = {
                "operation": "insert",
                "table": "rides",
                "ins_doc": ride
            }

            resp = requests.post(ridesdb_host + '/api/v1/db/write', json=json)

            return flask.jsonify(dict()), 201

    except (ValueError, KeyError, TypeError) as e:
        flask.abort(flask.Response(response=str(e), status=400))

    finally:
        pass


# API 5: List all the details of a given ride (GET)
# API 6: Join an existing ride (POST)
# API 7: Delete a ride (DELETE)
@app.route('/api/v1/rides/<ride_id>', methods=['GET', 'POST', 'DELETE'])
def listRideDetailsOrJoinRideOrDeleteRide(ride_id):

    try:

        if flask.request.method == 'GET':

            print('GET:', ride_id)

            json = {
                'table': 'rides',
                'where': '_id=' + ride_id
            }

            resp = requests.post(ridesdb_host + '/api/v1/db/read', json=json)
            if resp.status_code == 400:
                raise ValueError('database operation failed')
            resp_json = resp.json()
            rideId = list(resp_json.keys())[0]
            resp_json = resp_json[rideId]
            resp_json['rideId'] = str(int(rideId, 16))

            if resp.status_code == 200:
                return resp_json, 200

            else:
                return flask.Response(status=204)

        elif flask.request.method == 'DELETE':

            print('DELETE:', ride_id)

            json = {
                'table': 'rides',
                'where': '_id=' + ride_id
            }

            resp = requests.post(ridesdb_host + '/api/v1/db/read', json=json)
            if resp.status_code == 400:
                raise ValueError('database operation failed')
            elif resp.status_code == 204:
                raise ValueError('ride not found')

            json = {
                'operation': 'delete',
                'table': 'rides',
                'where': '_id=' + ride_id
            }

            resp = requests.post(ridesdb_host + '/api/v1/db/write', json=json)

            return flask.jsonify(dict()), 200

        else:  # POST

            username = flask.request.get_json()['username']

            print('POST:', flask.request.get_json())

            headers = {'Origin': publicip}
            if flask.request.host.startswith('ridesharing') and \
               flask.request.host.endswith('amaznonaws.com') and \
               'Via' in flask.request.headers:
                host = flask.request.host
            else:
                host = usersapi_host
            resp = requests.get(host + '/api/v1/users',
                                headers=headers)
            if resp.status_code == 200:
                if username in resp.json():
                    exists = True
                else:
                    exists = False
            elif resp.status_code == 204:
                exists = False
            else:
                raise ValueError('bad request')

            if not exists:
                raise ValueError('user does not exist')

            json = {
                'table': 'rides',
                'where': '_id=' + ride_id
            }

            resp = requests.post(ridesdb_host + '/api/v1/db/read', json=json)
            if resp.status_code == 200:
                exists = True
            elif resp.status_code == 204:
                exists = False
            else:
                raise ValueError('bad request')

            if not exists:
                raise ValueError('ride does not exist')

            json = {
                'operation': 'update',
                'table': 'rides',
                'where': '_id=' + ride_id,
                'update_op': {'$addToSet': {'users': username}}
            }

            resp = requests.post(ridesdb_host + '/api/v1/db/write', json=json)

            return flask.jsonify(dict()), 200

    except (ValueError, KeyError, TypeError) as e:
        flask.abort(flask.Response(response=str(e), status=400))

    finally:
        pass


@app.route('/api/v1/db/clear', methods=['POST'])
def DBClear():

    try:

        resp = requests.post(ridesdb_host + '/api/v1/db/clear',
                             json=flask.request.get_json())
        if resp.status_code == 200:
            return flask.jsonify({}), 200
        else:
            raise ValueError('clear failed')

    except (ValueError, KeyError, TypeError) as e:
        flask.abort(flask.Response(response=str(e), status=400))

    finally:
        pass


@app.route('/api/v1/rides/count', methods=['GET'])
def ridesCount():

    try:

        json = {
            'table': 'rides'
        }

        resp = requests.post(ridesdb_host + '/api/v1/db/read', json=json)
        if resp.status_code == 204:
            resp_json = {}
        elif resp.status_code == 200:
            resp_json = resp.json()
        else:
            raise ValueError('database operation failed')

        return flask.jsonify([len(resp_json)]), 200

    except (ValueError, KeyError, TypeError) as e:
        flask.abort(flask.Response(response=str(e), status=400))

    finally:
        pass


@app.route('/api/v1/_count', methods=['GET', 'DELETE'])
def RequestCount():

    global n_requests

    try:

        if flask.request.method == 'GET':

            n_requests_lock.acquire()
            try:
                return flask.jsonify([n_requests]), 200
            finally:
                n_requests_lock.release()

        else: # DELETE

            n_requests_lock.acquire()
            try:
                n_requests = 0
                return flask.jsonify({}), 200
            finally:
                n_requests_lock.release()

    except (ValueError, KeyError, TypeError) as e:
        flask.abort(flask.Response(response=str(e), status=400))

    finally:
        pass


if __name__ == '__main__':
    server_type = 'debug'
    server_port = 1101
    if len(sys.argv) >= 2:
        if sys.argv[1] in ('debug', 'deploy'):
            server_type = sys.argv[1]
        else:
            print('Usage: ./<filename> [debug [port]|deploy [port]]')

        if len(sys.argv) == 3:
            server_port = int(sys.argv[2])

    if server_type == 'debug':
        app.run(debug=True, host='0.0.0.0', port=server_port)
    else:
        app.debug = True
        http_server = WSGIServer(('', server_port), app)
        http_server.serve_forever()
