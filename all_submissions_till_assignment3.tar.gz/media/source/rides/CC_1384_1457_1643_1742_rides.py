from flask import Flask, render_template,\
jsonify,request,abort
from flask_sqlalchemy import SQLAlchemy 
from multiprocessing import Value
from sqlalchemy import create_engine
from collections import OrderedDict
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column, Integer, String,ForeignKey ,DateTime
from sqlalchemy.orm import sessionmaker,scoped_session
import requests
from flask import Response
import json
import re
from datetime import datetime
#engine = create_engine('sqlite:///:cloud1:', echo=True) 
app=Flask(__name__)
counter = Value('i', 0)
ride_count = Value('i',0)
app.config['SQLALCHEMY_DATAdb.Model_URI'] = 'sqlite:///:c:'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS_URI'] = False 
db = SQLAlchemy(app)
Session = scoped_session(sessionmaker(bind=db))




class Ride(db.Model):
    __tablename__ = 'ride'

    id = Column(Integer, primary_key =  True)
    created_by = Column(String)
    timestamp = Column(String)
    source = Column(Integer)
    destination = Column(Integer)
    

    def __init__(self,created_by,timestamp,source,destination):
    	
    	self.created_by = created_by
    	self.timestamp = timestamp
    	self.source = source
    	self.destination = destination

class Riders(db.Model):
    __tablename__ = 'riders'
    id = Column(Integer, primary_key =  True)
    rideid = Column(Integer)
    name =Column(String)
    def __init__(self,rideid,name):
    	self.rideid = rideid
    	self.name =name

    


@app.errorhandler(405)
def method_not_found(e):
	r = request.path
	if(r == "/api/v1/rides"):
		with counter.get_lock():
			counter.value+=1
		return jsonify({}),405	

	
@app.route("/api/v1/rides",methods=["POST"])
def create_ride():
	with counter.get_lock():
		counter.value += 1

	created_by = request.get_json()["created_by"]
	timestamp = request.get_json()["timestamp"]
	source = int(request.get_json()["source"])
	destination =int(request.get_json()["destination"])
	if source == destination:
		return jsonify("Source and Destination are same"),400
	if source not in range(1,199):
		return jsonify("Source doesn't exist"),400
	if destination not in range(1,199):
		return jsonify("Destination doesn't exist"),400
	pattern = re.compile(r'\d\d-\d\d-\d\d\d\d:\d\d-\d\d-\d\d')
	if(re.match(pattern,timestamp) == None):
		return Response("Timestamp format not correct", status=400, mimetype='application/json')
	read_request = { "flag" : "1",
					"name" : created_by
					}

	r = requests.post(url = "http://0.0.0.0:80/api/v1/db/read",json = read_request )
	if(r.text != "None"):
		write_request = {	
				"flag" : "2",	
				"created_by" : created_by,
				"timestamp": timestamp,
				"source": source,
				"destination": destination
				}
		r = requests.post(url = "http://0.0.0.0:80/api/v1/db/write",json = write_request )
		if r.text == "success":
			with ride_count.get_lock():
				ride_count.value += 1
			return jsonify("Ride Created"),201
		else:
			return jsonify("{400:failed}"),400
		
	else:
		return Response("Username doesn't exist", status=400, mimetype='application/json')

@app.route("/api/v1/rides",methods = ["GET"])
def get_ride_id1():
	with counter.get_lock():
		counter.value += 1

	source = int(request.args.get("source"))
	destination = int(request.args.get("destination"))
	read_request = { "flag" : "2",
					"source" : source,
					"destination" : destination
					}

	r = requests.post(url = "http://0.0.0.0:80/api/v1/db/read",json = read_request )
	if r.text == "204":
		return jsonify(""),204
	else:
		res = json.loads(r.text)
		return jsonify(res),200
	 

	
@app.route("/api/v1/rides/<rideId>",methods=["GET"])
def get_rideDetails(rideId):
	with counter.get_lock():
		counter.value += 1

	read_request = { "flag" : "3",
					"rideid": rideId
	}
	r = requests.post(url = "http://0.0.0.0:80/api/v1/db/read",json = read_request )
	if r.text == "204":
		return jsonify(""),204
	else:
		res = json.loads(r.text)
		return jsonify(res),200

@app.route("/api/v1/rides/<rideId>",methods=["POST"])
def join_ride(rideId):
	with counter.get_lock():
		counter.value += 1

	username = request.get_json()["username"]
	read_request = { "flag" : "4",
					"name" : username,
					"rideid": rideId
	}
	r = requests.post(url = "http://0.0.0.0:80/api/v1/db/read",json = read_request )

	
	if(int(r.text) ==0 ):
		return jsonify("User Created the ride"),400
	elif(int(r.text) ==1 ):
		return jsonify("User has already joined the ride"),400
	elif(int(r.text) ==2 ):
		return jsonify("Username doesn't exist"),400
	elif(int(r.text) ==3 ):
		return jsonify("RideId doesn't exist"),400
	if(int(r.text) ==5 ):
		write_request = { "flag" : "3",
					"name" : username,
					"rideid": rideId
						}
		r = requests.post(url = "http://0.0.0.0:80/api/v1/db/write",json = write_request )
		
		if r.text== "success":
			return jsonify("Joined successfully"),201
		else:
			return jsonify("{2:fail}"),400	

	
		
@app.route("/api/v1/rides/<rideId>",methods=["DELETE"])
def delete_ride(rideId):
	with counter.get_lock():
		counter.value += 1

	read_request = { "flag" : "5",
					"rideid": rideId
	}
	r = requests.post(url = "http://0.0.0.0:80/api/v1/db/read",json = read_request )
	if r.text == "None":
		return Response("RideId doesn't exist", status=400, mimetype='application/json')
	else:
		write_request = { "flag" : "5",
					"rideid": rideId
					}
		r = requests.post(url = "http://0.0.0.0:80/api/v1/db/write",json = write_request )
		if r.text == "success":
			with ride_count.get_lock():
				ride_count.value -= 1
			return Response("RideId Deleted", status=200, mimetype='application/json')
		
@app.route("/api/v1/db/clear",methods=["POST"])
def clear_db():
	
	Ride.query.delete()
	Riders.query.delete()
	db.session.commit()
	return jsonify("database cleared"),200
		
@app.route("/api/v1/_count",methods = ["GET"])
def count():
	l = [counter.value]
	return jsonify(l),200
@app.route("/api/v1/_count",methods = ["DELETE"])
def reset_count():
	counter.value = 0
	return jsonify({}),200

@app.route("/api/v1/rides/count",methods = ["GET"])
def r_count():
	with counter.get_lock():
		counter.value += 1
	res = Ride.query.all()
	c = 0
	for i in res:
		c+=1
	l = [c]
	return jsonify(l),200


def compare_time(t1,t2):
	l1 = t1.split(" ")
	l2 = t2.split(":")
	date1 = l1[0].split("-")
	date2 = l2[0].split("-")
	time1 = l1[1].split(":")
	time2 = l2[1].split("-")
	d1,m1,y1 = int(date1[2]) ,int(date1[1]) ,int(date1[0])
	d2,m2,y2 = int(date2[0]) ,int(date2[1]) ,int(date2[2])
	s1,min1,h1 = int(time1[2][:2]) ,int(time1[1]) ,int(time1[0])
	s2,min2,h2 = int(time2[0]) ,int(time2[1]) ,int(time2[2])
	print("1 ",y1,m1,d1,h1,min1,s1)
	print("2 ",y2,m2,d2,h2,min2,s2)
	if(y1>y2):
		return 0
	elif y2>y1:
		return 1
	if(m1>m2):
		return 0
	elif m2>m1:
		return 1
	if(d1>d2):
		return 0
	elif d2>d1:
		return 1
	if(h1>h2):
		return 0
	elif h2>h1:
		return 1
	if(min1>min2):
		return 0
	elif min2>min1:
		return 1
	if(s1>s2):
		return 0

	return 1
		

@app.route("/api/v1/db/read",methods=["POST"])
def readdb():
	flag = request.get_json()["flag"]
	if int(flag) == 1:
		name = request.get_json()["name"]
		read_request = { "flag" : "2"}
		r = requests.get(url = "http://Users-Rides-2129458677.us-east-1.elb.amazonaws.com/api/v1/users")

		if r.status_code == 204:
			return "None"
		res = json.loads(r.text)
		if name not in r.text:
			return "None"
		else:
			return name
		
	if int(flag) == 2:
		source = int(request.get_json()["source"])
		destination = int(request.get_json()["destination"])
		f = 0
		res = Ride.query.filter_by(source = source).filter_by(destination = destination)
		l = []
		if(res == None):
			return jsonify("{}"),204
		for i in res:

			c = compare_time(str(datetime.now()),i.timestamp)
			
			if(c == 1):
				
				f = 1
				r1 = OrderedDict([("rideId",i.id),("username",i.created_by),("timestamp",i.timestamp)])
				l.append(r1)
			else:
				
				continue

		if f == 0:
			return "204"
		return jsonify(l),201
	if int(flag) == 3:
		rideId = request.get_json()["rideid"]
		res = Ride.query.filter_by(id = int(rideId)).first()
		if res == None:
			return "204"
		res1 = Riders.query.filter_by(rideid = int(rideId)).all()
		r1 = {}
		r1["rideId"] = rideId
		r1["users"] = []
		for i in res1:
			r1["users"].append(i.name)
		r1["Created_by"] = res.created_by
		r1["Timestamp"] = res.timestamp
		r1["source"] = res.source
		r1["destination"] = res.destination
		return Response(json.dumps(r1), status=201, mimetype='application/json')
		
		
	if int(flag) == 4:
		username = request.get_json()["name"]
		rideId = request.get_json()["rideid"]
		
		r = requests.get(url = "http://Users-Rides-2129458677.us-east-1.elb.amazonaws.com/api/v1/users")
		if r.text == "None":
			return 2
		res = json.loads(r.text)
		if username not in res:
			return "2"
		
		if Ride.query.filter_by(id = int(rideId)).first() == None:
			return "3"
		if(bool(Riders.query.filter_by(name = username).filter_by(rideid = rideId).first()) ): 
				return "1"

		if(bool(Ride.query.filter_by(id = rideId).filter_by(created_by = username).first())):
				return "0"
		else:
			return "5"
			
	if(int(flag) == 5):
		rideId = request.get_json()["rideid"]
		res = Ride.query.filter_by(id = int(rideId)).first()
		if res == None:
			return "None"
		else:
			return str(rideId)





@app.route("/api/v1/db/write",methods=["POST","DELETE"])
def writedb():
	flag = request.get_json()["flag"]
	
	if int(flag) == 2:
		created_by = request.get_json()["created_by"]
		timestamp = request.get_json()["timestamp"]
		source = int(request.get_json()["source"])
		destination =int(request.get_json()["destination"])
		r =Ride(created_by,timestamp,source,destination)
		db.session.add(r)
		db.session.commit()
		return "success"
	if int(flag) == 3:
		name = request.get_json()["name"]
		rideid = request.get_json()["rideid"]
		u = Riders(int(rideid),name)
		db.session.add(u)
		db.session.commit()
		res= Riders.query.filter_by(name = name).first()

		return "success"
	
	if int(flag) == 5:
		rideId = request.get_json()["rideid"]
		Ride.query.filter_by(id = int(rideId)).delete()
		Riders.query.filter_by(rideid = int(rideId)).delete()
		db.session.commit()
		return "success"


db.create_all()	
app.debug=True
app.run(host = '0.0.0.0',port=80)

