from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy 
from flask_marshmallow import Marshmallow
from sqlalchemy.orm.attributes import flag_modified
import os
from sqlalchemy import PickleType
import requests
import re
import sys
from datetime import datetime
from multiprocessing import Value

AreaEnum=list(range(1,199))
counter = Value('i', 0)

# Init app
app = Flask(__name__)
basedir = os.path.abspath(os.path.dirname(__file__))
# Database
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(basedir, 'db3.sqlite')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False 
# Init db
db = SQLAlchemy(app)
# Init ma
ma = Marshmallow(app)


class Ride(db.Model):
  rideId = db.Column(db.Integer, primary_key=True)
  created_by = db.Column(db.String())
  timestamp = db.Column(db.String())
  source = db.Column(db.Integer)
  destination = db.Column(db.Integer)
  riders_list = db.Column(db.PickleType())

  def __init__(self, created_by, timestamp, source, destination, riders_list=[]):
    self.created_by = created_by
    self.timestamp = timestamp
    self.source = source
    self.destination = destination
    self.riders_list = riders_list

# Ride Schema
class RideSchema(ma.Schema):
  class Meta:
    fields = ('rideId','timestamp','created_by', 'source', 'destination', 'riders_list')

# Init schema
ride_schema = RideSchema()
rides_schema = RideSchema(many=True)

db.create_all()


#3.New ride
@app.route('/api/v1/rides', methods=['POST'])
def add_ride():
  with counter.get_lock():
    counter.value += 1

  if(request.method!= 'POST'):
    return jsonify({}), 405
  timepat=re.compile(r'\b[0-9][0-9](-)[0-9][0-9](-)[0-9][0-9][0-9][0-9](:)[0-9][0-9](-)[0-9][0-9](-)[0-9][0-9]')
  timevalid=re.compile(r'\b(?:(?:31(-)(?:0?[13578]|1[02]))\1|(?:(?:29|30)(-)(?:0?[13-9]|1[0-2])\2))(?:(?:1[6-9]|[2-9]\d)?\d{2})$|^(?:29(-)0?2\3(?:(?:(?:1[6-9]|[2-9]\d)?(?:0[48]|[2468][048]|[13579][26])|(?:(?:16|[2468][048]|[3579][26])00))))$|^(?:0?[1-9]|1\d|2[0-8])(-)(?:(?:0?[1-9])|(?:1[0-2]))\4(?:(?:1[6-9]|[2-9]\d)?\d{2})(:)([0-5][0-9])(-)([0-5][0-9])(-)([0-1][0-9]|2[0-3])\b')
  created_by = request.json['created_by']
  timestamp = request.json['timestamp']
  source = request.json['source']
  destination = request.json['destination']
  dic={}
  dic["created_by"]=created_by
  dic["timestamp"]=timestamp
  dic["source"]=source
  dic["destination"]=destination
  dic["some"]="add_ride"
  urlr="http://meghs-loadbalancer-1110480893.us-east-1.elb.amazonaws.com:80/api/v1/users"
  headers={'Content-type':'application/json','Accept':'text/plain'}
  r=requests.get(url=urlr)
  result= r.json()
  if(created_by not in result):
    return jsonify({}), 400
  elif(int(source) not in AreaEnum or int(destination) not in AreaEnum or (int(source)==int(destination))):
    return jsonify({}), 400
  else:
    if(re.search(timepat, timestamp)):
      if(re.search(timevalid, timestamp) and len(created_by)!=0):
        urlw="http://54.85.191.15:80/api/v1/db/write"
        w=requests.post(url=urlw,json=dic,headers=headers)
        return jsonify({}), 201
      else:
        return jsonify({}), 400
    else:
      return jsonify({}), 400


#4.upcoming rides
@app.route('/api/v1/rides', methods=['GET'])
def upcoming_rides():
  with counter.get_lock():
    counter.value += 1

  if(request.method != 'GET'):
    return jsonify({}), 405
  dic={}
  dic["some"]="upcoming_rides"
  s=request.args.get('source')
  d=request.args.get('destination')
  dic["s"]=s
  dic["d"]=d
  if(int(s) not in AreaEnum or int(d) not in AreaEnum or (int(s)==int(d))):
    return jsonify({}), 400
  else:
    urlr=" http://54.85.191.15:80/api/v1/db/read"
    headers={'Content-type':'application/json','Accept':'text/plain'}
    r=requests.post(url=urlr,json=dic,headers=headers)
    result=r.json()
    if(not bool(result)):
      return jsonify({}), 204
    else:
      return r.text, 200


#5.Ride details
@app.route('/api/v1/rides/<rideId>', methods=['GET'])
def ride_details(rideId):
  with counter.get_lock():
    counter.value += 1

  if(request.method != 'GET'):
    return jsonify({}), 405
  dic={}
  dic["some"]="ride_details"
  dic["rideId"]=rideId
  urlr=" http://54.85.191.15:80/api/v1/db/read"
  headers={'Content-type':'application/json','Accept':'text/plain'}
  r=requests.post(url=urlr,json=dic,headers=headers)
  result=r.json()
  if(not bool(result)):
    return jsonify({}), 204
  else:
    return r.text, 200

#6.Join ride 
@app.route('/api/v1/rides/<rideId>', methods=['POST'])
def join_ride(rideId):
  with counter.get_lock():
    counter.value += 1

  if(request.method!= 'POST'):
    return jsonify({}), 405
  username = request.json['username']
  dic={}
  dic["rideId"]=rideId
  dic["username"]=username
  dic["some"]="join_ride"
  urlr=" http://54.85.191.15:80/api/v1/db/read"
  headers={'Content-type':'application/json','Accept':'text/plain'}
  r=requests.post(url=urlr,json=dic,headers=headers)
  result = r.text
  urlu="http://meghs-loadbalancer-1110480893.us-east-1.elb.amazonaws.com:80/api/v1/users"
  req=requests.get(url=urlu)
  results= req.json()
  if(result=="False" or username not in results):
    return jsonify({}), 204
  else:
    urlw= "http://54.85.191.15:80/api/v1/db/write"
    w=requests.post(url=urlw,json=dic,headers=headers)
    wcheck=w.text
    if(w.text=="None" or len(username)==0):
      return jsonify({}), 400
    else:
      return jsonify({}), 200

#7.Delete ride
@app.route('/api/v1/rides/<rideId>', methods=['DELETE'])
def delete_ride(rideId):
  with counter.get_lock():
    counter.value += 1

  if(request.method!= 'DELETE'):
    return jsonify({}), 405
  dic={}
  dic["some"]="delete_ride"
  dic["rideId"]=rideId
  urlr=" http://54.85.191.15:80/api/v1/db/read"
  headers={'Content-type':'application/json','Accept':'text/plain'}
  r=requests.post(url=urlr,json=dic,headers=headers)
  result = r.text

  if(result=="None"):
    return jsonify({}), 400
  else:
    urlw=" http://54.85.191.15:80/api/v1/db/write"
    w=requests.post(url=urlw,json=dic,headers=headers)
    return jsonify({}), 200

#Clear db
@app.route('/api/v1/db/clear', methods=['POST'])
def clear():
  with counter.get_lock():
    counter.value += 1

  if(request.method!= 'POST'):
    return jsonify({}), 405
  dic={}
  dic["some"]="clear"
  urlr=" http://54.85.191.15:80/api/v1/db/read"
  headers={'Content-type':'application/json','Accept':'text/plain'}
  r=requests.post(url=urlr,json=dic,headers=headers)
  result = r.text
  if(result=="False"):
    return jsonify({}), 400
  else:
    urlw=" http://54.85.191.15:80/api/v1/db/write"
    w=requests.post(url=urlw,json=dic,headers=headers)
    return jsonify({}), 200



#Count # of rides
@app.route('/api/v1/rides/count', methods=['GET'])
def count():
  with counter.get_lock():
    counter.value += 1

  if(request.method!='GET'):
    return jsonify({}), 405
  dic={}
  dic["some"]="count"
  urlr=" http://54.85.191.15:80/api/v1/db/read"
  headers={'Content-type':'application/json','Accept':'text/plain'}
  r=requests.post(url=urlr,json=dic,headers=headers)
  no = r.text
  lis = []
  lis.append(no)
  return str(lis), 200

#total # of http reqs
@app.route('/api/v1/_count', methods=['GET'])
def total():
  if(request.method!='GET'):
    return jsonify({}), 405
    
  lis = []
  no = counter.value
  lis.append(no)
  return str(lis), 200

  
#delete http reqs
@app.route('/api/v1/_count', methods=['DELETE'])
def delete():
  if(request.method!='DELETE'):
    return jsonify({}), 405
  with counter.get_lock():
    counter.value = 0
  if(counter.value == 0):
    return jsonify({}), 200


#8.Write db
@app.route('/api/v1/db/write', methods=['POST'])
def write_db():
  content=request.json
  if(content["some"]=="add_ride"):
    user=content["created_by"]
    ts=content["timestamp"]
    src=content["source"]
    dst=content["destination"]
    new_ride=Ride(user, ts, src, dst )
    db.session.add(new_ride)
    db.session.commit()
    return ride_schema.jsonify(new_ride)

  elif (content["some"]=="delete_ride"):
    ride1=content["rideId"]
    #ride = Ride.query.get(ride1)
    ride = Ride.query.filter_by(rideId=ride1).first()
    db.session.delete(ride)
    db.session.commit()
    return content
  
  elif(content["some"]=="join_ride"):
    content=request.json
    user=content["username"]
    rideId=content["rideId"]
    ride = Ride.query.filter_by(rideId=rideId).first()
    ucheck=ride.created_by
    print(ucheck)
    l=ride.riders_list
    if ((user not in l) and (ucheck!=user)):
      l.append(user)
      ride.riders_list=l
      flag_modified(ride,"riders_list")
      db.session.merge(ride)
      db.session.flush()
      db.session.commit()
      return ride_schema.jsonify(ride)
    else:
      return "None"

  elif (content["some"]=="clear"):
    #db.session.query(User).delete()
    db.session.query(Ride).delete()
    db.session.commit()
    return content



#9.Read db
@app.route('/api/v1/db/read', methods=['POST'])
def read_db():
  content=request.json
  if (content["some"]=="upcoming_rides"):
    source1=content["s"]
    destination1=content["d"]
    '''timestamp=content["timestamp"]
    dt_string2=timestamp[:10]+" "+timestamp[11:]
    dt_value = datetime.strptime(dt_string2, '%d-%m-%Y %S-%M-%H')
    present_ts=datetime.now()'''
    ride2=Ride.query.filter(Ride.source==int(source1),Ride.destination==int(destination1)).all()
    #print(ride2)
    #print(type(ride2))
    urlr="http://meghs-loadbalancer-1110480893.us-east-1.elb.amazonaws.com:80/api/v1/users"
    headers={'Content-type':'application/json','Accept':'text/plain'}
    r=requests.get(url=urlr)
    result= r.json()
    sk=str(ride2)
    upcoming=[]
    x=map(int, re.findall(r'\d+',sk))
    z=list(x)
    if(len(z)==0):
      return ride_schema.jsonify(ride2)
    #print(list(x))
    else:
      for i in z: 
        y=Ride.query.get(i)
        tstamp=y.timestamp
        dt_string2=tstamp[:10]+" "+tstamp[11:]
        dt_value = datetime.strptime(dt_string2, '%d-%m-%Y %S-%M-%H')
        present_ts=datetime.now()
        user1=y.created_by
        if(user1 not in result):
          pass
        elif(dt_value>present_ts):
          lol={}
          lol["rideId"]=y.rideId
          lol["username"]=y.created_by
          lol["timestamp"]=y.timestamp
          upcoming.append(lol)
      if(len(upcoming)==0):
          return "None"
      else:
        return jsonify(upcoming)

  elif (content["some"]=="ride_details"):
    ride1=content["rideId"]
    ride = Ride.query.get(ride1)
    return ride_schema.jsonify(ride)

  elif (content["some"]=="delete_ride"):
    ride1=content["rideId"]
    #ride=Ride.query.get(ride1)
    ride = Ride.query.filter_by(rideId=ride1).first()
    return str(ride)
  
  elif(content["some"]=="join_ride"):
    ride1=content["rideId"]
    ride = Ride.query.filter_by(rideId=ride1).first()
    b=str(ride)
    if(b!="None"):
    	return "True"
    else:
    	return "False"

  elif (content["some"]=="clear"):
    y = Ride.query.all()
    if not y:
      return "False"
    else:
      return "True"

  elif(content["some"]=="count"):
    c=Ride.query.count()
    #print(c)
    return str(c)
    

# Run Server
if __name__ == '__main__':
  app.run(host="0.0.0.0",port=80,debug=True)


