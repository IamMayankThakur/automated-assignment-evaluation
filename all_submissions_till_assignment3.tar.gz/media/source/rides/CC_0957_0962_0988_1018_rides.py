from flask import Flask,render_template,jsonify,request,abort
from flask_sqlalchemy import SQLAlchemy
import re
import requests
import datetime
from constants import Place
from multiprocessing import Value

app=Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI']='sqlite:///rides.db'
db=SQLAlchemy(app)
class Ride(db.Model):
    rideId=db.Column(db.Integer,primary_key=True)
    created_by=db.Column(db.String(200))
    timeStamp=db.Column(db.String(200),nullable=False)
    source=db.Column(db.String(200),nullable=False)
    destination=db.Column(db.String(200),nullable=False)

class Participant(db.Model):
    rideId=db.Column(db.Integer,primary_key=True)
    username=db.Column(db.String(200),primary_key=True)

db.create_all()
def date_validate(timestamp):
    date_format = '%d-%m-%Y:%S-%M-%H'
    try:
        date_obj = datetime.datetime.strptime(timestamp, date_format)
        return 1
    except ValueError:
        return 0

counter = 0

@app.route("/api/v1/_count",methods=["GET","DELETE"])
def count():
    if request.method=="GET":
        global counter
        temp=list()
        temp.append(counter)
        return jsonify(temp),200
    elif request.method=="DELETE":
        counter=0
        return {},200
    else:
        abort(405)

#databse write operation
@app.route("/api/v1/db/write",methods=["POST"])
def write():
    data=request.get_json()["insert"]
    column=request.get_json()["column"]
    table=request.get_json()["table"]
    data1=[]
    for i in data:
        if type(i) is str:
            print(type(i))
            data1.append("\'"+i+"\'")
        else:
            data1.append(str(i))
    #data=list(map(lambda x:'\''+x+'\'' if isinstance(x,str),data))	#inserting single qoute '' to data
    column=",".join(column)	#combining column with join
    data1=",".join(data1)#combining data with join
    try:
    	qry="insert into "+table+"("+column+") values("+data1+");"
    	db.session.execute(qry)
    	db.session.commit()
    	return {}
    except Exception as e:
    	print(e)
    	abort(400)

@app.route("/api/v1/db/read",methods=["POST","DELETE"])
def read():
    if request.method=="POST":	#to read from data
        a={}
        table=request.get_json()["table"]
        column=request.get_json()["columns"]
        where=request.get_json()["where"]
        column=",".join(column)
        qry="select "+column+" from "+table+ " where "+where+ ";"
        print(qry)
        try:
            result=db.session.execute(qry)
            count=0
            for i in result:
                a[count]=list(i)
                count+=1
            return jsonify(a)
        except Exception as e:
            print(e)
            abort(400)
    elif request.method=="DELETE":	#to delete from table
        table=request.get_json()["table"]
        where=request.get_json()["where"]
        qry="delete from "+table+" where "+where+";"       
        try:
            db.session.execute(qry)
            db.session.commit()
            return {}
        except Exception as e:
            print(e)
            abort(400)


        
@app.route("/api/v1/rides",methods=["PUT","GET","POST","DELETE"])
def newRide():
    global counter
    counter+=1
    ride_list=[]
    if request.method=="POST":

        try:
            created_by=request.get_json()["created_by"]
            timeStamp=request.get_json()["timestamp"]
            source=request.get_json()["source"]
            destination=request.get_json()["destination"]
            headers={'Origin':'50.17.167.22'}
            resp1=requests.get("http://rideShare-323334112.us-east-1.elb.amazonaws.com/api/v1/users",headers=headers)
            li=resp1.json()
            suc=0
            for i in li:
                if(created_by==i):
                    suc=1
            if(suc==1):
                if(int(source) in Place._value2member_map_ and int(destination) in Place._value2member_map_):
                    if(date_validate(timeStamp)):
                        a={"insert":[created_by,timeStamp,source,destination],\
                            "column":["created_by","timestamp","source","destination"],"table":"ride"}
                        resp=requests.post("http://50.17.167.22/api/v1/db/write",json=a)
                        if resp.status_code==200:
                            a={"columns":["rideId"],"table":"ride","where":"timestamp='"+timeStamp+"' and created_by='"+created_by+"'"}
                            rides=requests.post("http://50.17.167.22/api/v1/db/read",json=a)
                            rides=rides.json()
                            i=list(rides.keys())[-1]
                            i = rides[i]
                            b={"insert":[created_by,str(i[0])],"column":["username","rideId"],"table":"participant"}
                            print(b)
                            resp=requests.post("http://50.17.167.22/api/v1/db/write",json=b)
                            if resp.status_code==200:
                                return {},201
                            else:
                                abort(resp.status_code)
                        else:
                            abort(resp.status_code)
                    else:
                        abort(400)
                else:
                    abort(400)
            else:
                print("USERNAME NOT FOUND IN USER DATABASE")
                abort(resp1.status_code)
        except Exception as e:
    	    print(e)
    	    abort(400)
    elif request.method=="GET":
        try:
            source=request.args.get('source')
            destination=request.args.get('destination')
            a={"columns":["*"],"table":"ride","where":"source='"+source+"' and destination='"+destination+"'"}
            rides=requests.post("http://50.17.167.22/api/v1/db/read",json=a)
            if rides.status_code==200:
                rides=rides.json()
                for ride in rides:
                    ptime=datetime.datetime.now().strftime('%Y-%m-%d:%H-%M-%S')
                    user_time=rides[ride][2]
                    user_time=datetime.datetime.strptime(user_time,\
                        '%d-%m-%Y:%S-%M-%H').strftime('%Y-%m-%d:%H-%M-%S')
                    a={}
                    if(ptime<user_time):
                        a["rideId"]=rides[ride][0]
                        a["username"]=rides[ride][1]
                        a["timestamp"]=rides[ride][2]
                        ride_list.append(a)
                if(len(ride_list)==0):
                    return jsonify(ride_list),204
                return jsonify(ride_list)               
            else:
                abort(resp.status_code)

        except Exception as e:
            print(e)
            abort(400)
    else:
        abort(405)

@app.route("/api/v1/rides/<rideid>",methods=["PUT","GET","POST","DELETE"])
def Ridemodify(rideid):
    global counter
    counter+=1
    if request.method=="GET":
        try:
            a={"table":"ride","columns":["rideId","created_by","timeStamp","source","destination"],"where":"rideId="+rideid}
            resp1=requests.post("http://50.17.167.22/api/v1/db/read",json=a)
            print(type(resp1.json()),len(resp1.json()))
            if(len(resp1.json())>0):
                b={"table":"participant","columns":["username"],"where":"rideId="+rideid}
                resp2=requests.post("http://50.17.167.22/api/v1/db/read",json=b)
                gresp1=list(resp1.json().values())
                gresp2=list(resp2.json().values())
                gresp3=list()
                for i in range(len(gresp2)):
                    gresp3.append(gresp2[i][0])
                gresp2=gresp3
                gresp=[('rideId',gresp1[0][0]),('created_by',gresp1[0][1]),('users',gresp2),('Timestamp',gresp1[0][2]),('source',gresp1[0][3]),('destination',gresp1[0][4])]
                resp=dict(gresp)
                return jsonify(resp)
            else:
                return {},204
        except Exception as e:
            print(e)
            abort(400)
    elif request.method=="POST":
        try:
            user_name=request.get_json()['username']
            qry1 = {"table":"ride","columns":["rideId"],"where":"rideId="+rideid}
            qry1=requests.post("http://50.17.167.22/api/v1/db/read",json=qry1)
            headers={'Origin':'50.17.167.22'}
            qry2=requests.get("http://rideShare-323334112.us-east-1.elb.amazonaws.com/api/v1/users",headers=headers)
            li=qry2.json()
            suc=0
            for i in li:
                if(user_name==i):
                    suc=1
            if(len(qry1.json())>0 and suc==1):
                rideid=int(rideid)
                c={"insert":[rideid,user_name],"column":["rideId","username"],"table":"participant"}
                resp=requests.post("http://50.17.167.22/api/v1/db/write",json=c)
                if(resp.status_code==200):
                    return {}
                else:
                    abort(400)
            else:
                print("Username/rideid does not exist")
                abort(400)
        except Exception as e:
            print(e)
            abort(400)
    
    elif request.method=="DELETE":
        try:
            a={"table":"ride","columns":["rideId"],"where":"rideId="+rideid}
            b={"table":"participant","columns":["rideId"],"where":"rideId="+rideid}
            resp1=requests.post("http://50.17.167.22/api/v1/db/read",json=a)
            resp2=requests.post("http://50.17.167.22/api/v1/db/read",json=b)
            if resp1.status_code==200:
                if resp2.status_code==200:
                    resp1=requests.delete("http://50.17.167.22/api/v1/db/read",json=a)
                    resp2=requests.delete("http://50.17.167.22/api/v1/db/read",json=b)
                    if(resp1.status_code==200):
                        if(resp2.status_code==200):
                            return {}
                        #b={"table":"participant","columns":["rideId"],"where":"rideId="+rideid}
                        #resp2=requests.delete("http://50.17.167.22/api/v1/db/read",json=b)
                        #if resp2.status_code==200:
                            
                        #else:
                            #abort(resp2.status_code)
                        else:
                            abort(resp2.status_code)
                    else:
                        print("here1")
                        abort(resp1.status_code)
                else:
                    abort(resp2.status_code)
            else:
                print("here2")
                abort(resp1.status_code)
        except Exception as e:
            print(e)
            abort(400)
    else:
        abort(405)

@app.route("/api/v1/db/clear",methods=["POST"])
def rideclear():
    if(request.method!="POST"):
        abort(405)
    else:
        a={"table":"participant","columns":["*"],"where":"rideId like '%'"}
        resp1=requests.delete("http://50.17.167.22/api/v1/db/read",json=a)

        b={"table":"ride","columns":["*"],"where":"rideId like '%'"}
        resp2=requests.delete("http://50.17.167.22/api/v1/db/read",json=b)
        
        if((resp1.status_code==200)and(resp2.status_code==200)):
            return {},200
        else:
            abort(400)

@app.route("/api/v1/rides/count",methods=["PUT","GET","POST","DELETE"])
def rideCount():
    global counter
    counter+=1
    if(request.method!="GET"):
        abort(405)
    else:
        a={"table":"ride","columns":["rideId"],"where":"rideId like '%'"}
        resp1=requests.post("http://50.17.167.22/api/v1/db/read",json=a)
        co=len(resp1.json())
        a=[]
        a.append(co)
        return jsonify(a),200

if __name__=="__main__":
      app.debug=True #one parameter ip and  port
      app.run(host="0.0.0.0",port=8000)