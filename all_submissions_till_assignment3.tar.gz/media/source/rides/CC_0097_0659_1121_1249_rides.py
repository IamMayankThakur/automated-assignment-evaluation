from flask import Flask, request, render_template
from flask_restful import Resource, Api, abort
from flask_sqlalchemy import SQLAlchemy
from requests import put,get,post,delete
from constants import AreaEnum
import datetime
import sqlalchemy
import re

app = Flask(__name__)
api = Api(app)

app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:password@localhost' #connect to database rideshare
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

def setupenv(db):
	db.engine.execute("create database if not exists rideshare;")
	db.engine.execute("use rideshare;")
	db.engine.execute("drop table if exists UserRide,Ride;")
	ride_query = "create table if not exists Ride(RideID INT AUTO_INCREMENT, CREATED_BY TEXT NOT NULL, TIMESTAMP datetime NOT NULL, SOURCE INT, DEST INT, PRIMARY KEY(RIDEID));"
	user_ride_query = "create table if not exists UserRide(entryid INT AUTO_INCREMENT, RideID INT, username TEXT NOT NULL, Primary KEY(entryid), FOREIGN KEY(RideId) REFERENCES Ride(RideID) on delete cascade);"
	db.engine.execute(ride_query)
	db.engine.execute(user_ride_query)

def initial():
   f = open("keepcount.txt","w")
   f.write("0")
   f.close()

def update():
   f = open("keepcount.txt","r+")
   value = int(f.read())
   f.seek(0)
   f.write(str(value+1))
   f.close()

#using enum: AreaEnum(locality_id).name

#reversing date and time to fit mysql format
def format_time(timestamp):
    try:
        timestamp = datetime.datetime.strptime(timestamp,'%d-%m-%Y:%S-%M-%H')
    except ValueError:
        return -1
    return timestamp.strftime('%Y-%m-%d %H-%M-%S')

class DatabaseRead(Resource):
    def post(self):
       table = request.json['table name']
       column = request.json['column name']
       if(type(column)==list):
           column = ','.join(column)
       where = request.json['where']
       query = "select "+column+" from "+table+" where "+where+";"
       result = db.engine.execute(query)
       res = []
       for row in result:
           res.append(dict(row))
       if(len(res)==0):
           return {},204
       for row in res:  #every row in result
           for key,value in row.items():  #every item in the dictionary
              if(type(value)==datetime.datetime):
                  row[key] = row[key].strftime('%d-%m-%Y:%S-%M-%H')
       return {"result":res}

class DatabaseWrite(Resource):
    def post(self):
        querytype = 'insert'
        try:
            values = request.json['insert']
            for i in range(len(values)):
                if(type(values[i])==int):
                    values[i] = "'" + str(values[i]) + "'"
                else:
                    values[i] = "'" + values[i] + "'"
            values = ','.join(values)
            column = request.json['column name']
            column = ','.join(column)
        except:
            querytype='delete'
            condition = request.json['condition']
        table = request.json['table name']
        if(querytype=='insert'):
            query = "insert into "+table+"("+column+") values("+values+");"
        else:
            query = "delete from "+table+" where "+condition+";"
        try:
            result = db.engine.execute(query)
            if(result.rowcount==0):
                abort(400)
        except sqlalchemy.exc.IntegrityError:
            abort(400)
        return {}

class DatabaseClear(Resource):
    def post(self):
       update()
       db.engine.execute("drop database rideshare;")
       setupenv(db)
       return {},200

class Ride(Resource):
    def post(self):
        update()
        try:
            created_by = request.json['created_by']
            timestamp = request.json['timestamp']
            source = int(request.json['source'])
            dest = int(request.json['destination'])
        except TypeError:
            abort(400)
        if(source==dest):
            abort(400,message="Same Source and Destination")
        try:
            AreaEnum(source)  #checking if given source and dest exist
            AreaEnum(dest)
        except ValueError:
            abort(400,message="Invalid Source or Destination")
        timestamp = format_time(timestamp)
        if(timestamp==-1):
            abort(400,message="Bad Timestamp")
        headers={'Origin':'184.73.37.224'}
        userlist = get("http://cc-ssk-a3-1712167151.us-east-1.elb.amazonaws.com/api/v1/users",headers=headers)
        try:
            userlist = userlist.json()
        except:
            abort(400)
        if(created_by not in userlist): #user does not exist
            abort(400)
        jsonwrite = {'insert':[created_by,timestamp,source,dest],'column name':['created_by','timestamp','source','dest'],'table name':'Ride'} #inserting into Ride
        x = post('http://localhost/api/v1/db/write',json=jsonwrite)
        if(not(x.ok)): #error
            abort(x.status_code)

        jsonread = {'table name':"Ride",'column name':'rideid','where':"created_by='"+created_by+"' order by rideid desc"} #order by rideid desc, get latest ride
        result = post('http://localhost/api/v1/db/read',json=jsonread)
        resultjson = result.json()
        rideid = resultjson['result'][0]['rideid']
        jsonwrite = {'insert':[rideid,created_by],'column name':['rideid','username'],'table name':'UserRide'} #inserting into UserRide
        x = post('http://localhost/api/v1/db/write',json=jsonwrite)

        return {},201

    def get(self):
        update()
        source = request.args['source']
        destination = request.args['destination']
        if(source==destination):
            abort(400,message="Same Source and Destination")
        try:
            AreaEnum(int(source))  #checking if given source and dest exist
            AreaEnum(int(destination))
        except ValueError:
            abort(400,message="Invalid Source or Destination")
        jsonread = {"table name":"Ride","column name":["rideid","created_by","timestamp"],"where":"source="+source+" and dest="+destination+" and now() < timestamp"}
        result = post('http://localhost/api/v1/db/read',json=jsonread)
        if(result.status_code>200): #error -> either 400 or 204
            return {},result.status_code
        returnjson = []
        resultjson = result.json() #dictionary with key 'result' holding a list of dictionaries
        headers={'Origin':'184.73.37.224'}
        userlist = get("http://cc-ssk-a3-1712167151.us-east-1.elb.amazonaws.com/api/v1/users",headers=headers)
        userlist = userlist.json()
        for row in resultjson['result']: #iterate over each list
            ride = {}
            if(row['created_by'] not in userlist): #user does not exist
                continue
            for key,value in row.items(): #iterate over dictionary
                if(key=='created_by'): #call db read to get username of created_by
                    ride['username'] = value
                elif(key=='rideid'):
                    ride['rideId']=value
                else:
                    ride[key] = value
            returnjson.append(ride)
        if(len(returnjson)==0):
            return {},204
        return returnjson,200

    def delete(self):
       # update()
        abort(405)

    def put(self):
       # update()
        abort(405)

class RideDetails(Resource):
    def get(self,ride_id):
        update()
        jsonread = {"table name":"Ride","column name":["created_by","timestamp","source","dest"],"where":"RideID='"+ride_id+"'"}
        result = post('http://localhost/api/v1/db/read',json=jsonread)
        if(result.status_code>200): #rideid doesn't exist
             abort(400)
        resultjson = result.json()
        timestamp = resultjson['result'][0]['timestamp']
        source = resultjson['result'][0]['source']
        destination = resultjson['result'][0]['dest']
        created_by = str(resultjson['result'][0]['created_by'])

        headers={'Origin':'184.73.37.224'}
        userlist = get("http://cc-ssk-a3-1712167151.us-east-1.elb.amazonaws.com/api/v1/users",headers=headers)
        userlist = userlist.json()
        if(created_by not in userlist): #user does not exist
            abort(400)

        jsonread = {"table name":"UserRide","column name":"username","where":"RideID='"+ride_id+"'"}
        result_2 = post('http://localhost/api/v1/db/read',json=jsonread)
        if(result_2.status_code>200):
             abort(400)
        resultjson_2 = result_2.json()
        username_list = []
        for row in resultjson_2['result']: #iterate over each list
            username_list.append(row['username']) #add all riders to list

        username_list.remove(created_by) #remove user who created ride from list of users in ride

        for i in username_list:
            if i not in userlist:
                username_list.remove(i) #remove user from username_list if he doesn't exist
        returnjson = {"rideId":ride_id,"created_by":created_by,"users":username_list,"timestamp":timestamp,"source":source,"destination":destination}
        return returnjson

    def post(self,ride_id):
        update()
        try:
            username = request.json['username']
        except TypeError:
            abort(400)
        headers={'Origin':'184.73.37.224'}
        result = get("http://cc-ssk-a3-1712167151.us-east-1.elb.amazonaws.com/api/v1/users",headers=headers)

        result=result.json()
        if username not in result:
            abort(400)

        jsonread = {"table name":"Ride","column name":"RideID","where":"RideID='"+ride_id+"'"}
        result = post('http://localhost/api/v1/db/read',json=jsonread)
        if(result.status_code>200): #error -> either 400 or 204
           abort(400)  #if 204 is returned, then rideID does not exist, therefore 400

        jsonwrite = {'insert':[ride_id,username],'column name':['rideid','username'],'table name':'UserRide'} #inserting into UserRide
        x = post('http://localhost/api/v1/db/write',json=jsonwrite)
        if(not(x.ok)):
            abort(x.status_code)
        return {}

    def delete(self,ride_id):
        update()
        jsonwrite = {'table name':'Ride','condition':"RideID='"+ride_id+"'"}
        result = post('http://localhost/api/v1/db/write',json=jsonwrite)
        if(not(result.ok)):
            abort(result.status_code)
        return {}

    def put(self,ride_id):
       # update()
        abort(405)

class CountRequests(Resource):
    def get(self):
       f = open("keepcount.txt","r")
       value = int(f.read())
       f.close()
       return [value],200

    def delete(self):
        initial()
        return {},200

    def post(self):
        abort(405)

    def put(self):
        abort(405)

class HealthCheck(Resource):
   def get(self):
       return render_template('index.html')

class CountRides(Resource):
      def get(self):
          update()
          count = 0
          result = db.engine.execute("select * from Ride;")
          for row in result:
             count+=1
          return [count],200

      def post(self):
          abort(405)

      def put(self):
          abort(405)

      def delete(self):
          abort(405)

api.add_resource(DatabaseRead, '/api/v1/db/read')
api.add_resource(DatabaseWrite, '/api/v1/db/write')
api.add_resource(DatabaseClear, '/api/v1/db/clear')
api.add_resource(Ride,'/api/v1/rides')
api.add_resource(RideDetails,'/api/v1/rides/<string:ride_id>')
api.add_resource(CountRequests,'/api/v1/_count')
api.add_resource(HealthCheck,'/serve')
api.add_resource(CountRides,'/api/v1/rides/count')

if __name__ == "__main__":
    setupenv(db)
    initial()
    app.run(host='0.0.0.0',debug=True)
