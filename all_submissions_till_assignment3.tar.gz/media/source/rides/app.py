from flask import Flask, request, Response, session
from flask_sqlalchemy import SQLAlchemy
import requests as req
import json
import config
from datetime import datetime
from areas import area #dictionary with number to area name mapping
import re
import argparse

parser = argparse.ArgumentParser()
parser.add_argument("http_count")
args = parser.parse_args()
args.http_count = int(args.http_count)

app = Flask(__name__)
app.config.from_object(config.Config)
app.secret_key = config.Config.SECRET_KEY
db = SQLAlchemy(app)  # object to communicate with db

class Ride(db.Model):
	id = db.Column(db.Integer, primary_key=True)
	created_by = db.Column(db.String(50), nullable=False)
	timestamp = db.Column(db.DateTime, nullable=False)
	source = db.Column(db.Integer, nullable=False)
	destination = db.Column(db.Integer, nullable=False)
	users_joined=db.Column(db.String(500), nullable=False)
	# helper function to serialize Ride object

	def as_dict(self):
		obj = {}
		for c in self.__table__.columns:
			attr = getattr(self, c.name)
			if isinstance(attr, (datetime)):
				attr = attr.strftime('%d-%m-%Y:%S-%M-%H')
			obj.update({c.name: attr})
		return obj
db.create_all()

def resolve_area(area_num):
	try:
		return area[int(area_num)]
	except:
		return False

def validate_date(date_text):
	try:
		datetime.strptime(date_text, '%d-%m-%Y:%S-%M-%H')
		return True
	except:
		return False

def isValidHash(text):
	return re.match(r"^([0-9a-fA-F]{40})$", text)

def write_to_db(write_params):
	return req.post(
		url=app.config['URL']+'/api/v1/db/write',
		data=json.dumps(write_params),
		headers={'Content-Type': 'application/json'}
		)

def read_from_db(read_params):
	return req.post(
		url=app.config['URL']+'/api/v1/db/read',
		data=json.dumps(read_params),
		headers={'Content-Type': 'application/json'}
		)


#create new ride
@app.route('/api/v1/rides', methods=['POST'])
def create_ride():
	req_data = request.get_json()
	args.http_count += 1
	try:
		validate_date(req_data['timestamp'])
		resolve_area(req_data['source'])
		resolve_area(req_data['destination'])
	except:
		return Response(status=400)
	if all(keys in req_data for keys in ['created_by','timestamp','source','destination']) and validate_date(req_data['timestamp']):
		# send a post request to write into the DB with the keys
		write_request_body = {
			'type': 'add',
			'table': 'ride',
			'data': {
				'created_by': req_data['created_by'],
				'timestamp': req_data['timestamp'],
				'source': req_data['source'],
				'destination': req_data['destination'],
			}
		}
		write_request = write_to_db(write_request_body)
		print(write_request)
		# response = json.loads(write_request.text)
		if write_request.status_code == 200:
			return Response(status=201)
		elif write_request.status_code == 400:
			return Response(status=400)
		else:
			return Response(status=500)
	else:
		return Response(status=400)

# list all upcoming rides for a source and destination
@app.route('/api/v1/rides', methods=['GET'])
def list_rides():
	args_c = request.args
	args.http_count += 1
	try:
		resolve_area(args_c['source'])
		resolve_area(args_c['destination'])
	except:
		return Response(status=405)
	if resolve_area(args_c['source']) and resolve_area(args_c['destination']):
		read_request_body = {
			'table': 'ride',
			'wheres': {
				'source': args_c['source'],
				'destination': args_c['destination']
			}
		}
		rides_request = read_from_db(read_request_body)
		rides = json.loads(rides_request.content)
		if len(rides) == 0:
			return Response(status=204)
		response_data = []
		for ride in rides:
			# ride['source'] = resolve_area(ride['source'])
			# ride['destination'] = resolve_area(ride['destination'])
			response_data.append({
				'rideId': ride['id'],
				'username': ride['created_by'],
				'timestamp': ride['timestamp']
			})
		return Response(json.dumps(response_data), status=200, mimetype='application/json')
	else:
		message = {"success": False,
				   "message": "Please include source and destination"}
		return Response(json.dumps(message), status=405, mimetype='application/json')

# list all details of a given ride
@app.route('/api/v1/rides/<ride_id>', methods=['GET'])
def ride_details(ride_id):
	args.http_count += 1
	if ride_id:
		read_request_body = {
			'table': 'ride',
			'wheres': {
				'id': ride_id
			}
		}
		rides_request = read_from_db(read_request_body)
		try:
			ride_detail = json.loads(rides_request.content)[0]
		except:
			return Response(status=405)
		#make users list from user_is_list
		users = ride_detail['users_joined'].split(';')
		ride_detail.update({'users': users})
		ride_detail['source'] = resolve_area(ride_detail['source'])
		ride_detail['destination'] = resolve_area(ride_detail['destination'])
		return Response(json.dumps(ride_detail), status=200, mimetype='application/json')
	else:
		message = {"success": False, "message": "Please include ride id"}
		return Response(json.dumps(message), status=400, mimetype='application/json')

# join an existing ride
@app.route('/api/v1/rides/<ride_id>', methods=['POST'])
def join_ride(ride_id):
	args.http_count += 1
	try:
		req_data = request.get_json()
		req_data['username']
	except:
		return Response(status=400)
	if ride_id and req_data['username']!='':
		write_request_body = {
			'type': 'join',
			'table': 'ride',
			'data': {
				'ride': ride_id,
				'rider': req_data['username']
			}
		}
		write_request = write_to_db(write_request_body)
		if write_request.status_code == 200:
			return Response(status=200)
		else:
			return Response(status=400)
	else:
		return Response(status=400)

# delete a ride
@app.route('/api/v1/rides/<ride_id>', methods=['DELETE'])
def delete_ride(ride_id):
	args.http_count += 1
	if(ride_id):
		write_request_body = {
			'table': 'ride',
			'type': 'delete',
			'data': {'rideId': ride_id}
		}
		write_request = write_to_db(write_request_body)
		if write_request.status_code == 200:
			return Response(status=200)
		else:
			return Response(status=405)
	else:
		return Response(status=405)

#count total number of rides
@app.route('/api/v1/rides/count', methods=['GET'])
def get_ride_count():
	args.http_count += 1
	read_request_body = {
        'table' : 'ride',
		'type': 'count'
    }
	ride_count_request = read_from_db(read_request_body)
	ride_count = json.loads(ride_count_request.content)
	return Response(json.dumps([ride_count]), status=200, mimetype='application/json')

#clear DB
@app.route('/api/v1/db/clear', methods=['POST'])
def clear_db():
	clear_db_body = {
		'type':'clear'
	}
	clear_request = write_to_db(clear_db_body)
	if clear_request.status_code == 200:
		return Response(status=200)
	else:
		return Response(status=405)

#get total http requests made
@app.route('/api/v1/_count', methods=['GET'])
def get_count():
	return Response(json.dumps([args.http_count]), status=200)

#reset total http requests made
@app.route('/api/v1/_count', methods=['DELETE'])
def reset_count():
	args.http_count = 0
	return Response(status=200)

# write to db
@app.route('/api/v1/db/write', methods=['POST'])
def write_db():
	# Get the request body
	req_data = request.get_json()

	#If the operation is to clear the DB
	if req_data['type'] == 'clear':
		db.drop_all(bind=None)
		db.create_all()
		message = {"success": True, "message": "DB successfully deleted"}
		return Response(json.dumps(message), status = 200, mimetype = 'application/json')

	# Check if all the fields are present in the request body
	if 'type' not in req_data or 'table' not in req_data or 'data' not in req_data:
		message = {"success": False,
				   "message": "Please follow correct request body format"}
		return Response(json.dumps(message), status=400, mimetype='application/json')
	table_name = req_data['table']
	data = req_data['data']	
	if table_name.lower() == 'ride':
		all_users = json.loads(req.get(url = app.config['USERS_URL']+'/api/v1/users', headers={'Content-Type': 'application/json', 'Origin':'ec2-3-84-26-235.compute-1.amazonaws.com'}).content)
		# if the operation is to add to ride table
		if req_data['type'] == 'add':
			# check if user already exists in the table by the username
			if data['created_by'] in all_users:
				timestamp = datetime.strptime(data['timestamp'], '%d-%m-%Y:%S-%M-%H')
				new_ride = Ride(
					created_by=data['created_by'],
					timestamp=timestamp,
					source=data['source'],
					destination=data['destination'],
					users_joined = data['created_by'] #person who created is added to ride bydefault
				)
				db.session.add(new_ride)
				db.session.commit()
				message = {"success": True,
							"message": "Ride successfully added"}
				return Response(json.dumps(message), status=200, mimetype='application/json')
			else:
				message = {"success": False, "message": "User does not exist"}
				return Response(json.dumps(message), status=400, mimetype='application/json')
		# if the operation is to delete a user from the table
		elif req_data['type'] == 'delete':
			ride = Ride.query.filter_by(id=data['rideId']).first()
			if ride:
				temp_rider = ride.created_by
				db.session.delete(ride)
				db.session.commit()
				#if data['cascade'] is set, then, the user who created this ride (created_by), will be removed from all the rides they have joined
				# this is implemented to make deletion of user easier, so the effects cascade
				if('cascade' in req_data):
					a={}
					all_rides = Ride.query.filter_by(**a).all()
					for r in all_rides:
						if(temp_rider in r.users_joined.split(';')):
							users_joined = r.users_joined.split(';')
							users_joined.remove(temp_rider)
							r.users_joined = ';'.join(users_joined)
							db.session.commit()
				message = {"success": True,"message": "Ride successfully deleted"}
				return Response(json.dumps(message), status=200, mimetype='application/json')
			else:
				message = {"success": False, "message": "Ride not found"}
				return Response(json.dumps(message), status=400, mimetype='application/json')
		elif req_data['type'] == 'join':
			ride = Ride.query.filter_by(id=data['ride']).first()
			rider_name = data['rider']
			if ride and (rider_name in all_users):
				existing_joined_users = ride.users_joined.split(';')
				if((rider_name not in existing_joined_users) and (rider_name!=ride.created_by)):
					existing_joined_users.append(rider_name.strip())
					users_joined = ';'.join(existing_joined_users)
					ride.users_joined = users_joined
					db.session.commit()
					message = {"success": True, "message": "User added to ride"}
					return Response(json.dumps(message), status=200, mimetype='application/json')
				else:
					message = {"success": False, "message": "Ride not found"}
					return Response(json.dumps(message), status=204, mimetype='application/json')
			else:
				message = {"success": False, "message": "Ride not found"}
				return Response(json.dumps(message), status=400, mimetype='application/json')
		else:
			message = {"success": False, "message": "Write type unidentified"}
			return Response(json.dumps(message), status=400, mimetype='application/json')
	else:
		message = {"success": False,
				   "message": "No such table is present in the db"}
		return Response(json.dumps(message), status=400, mimetype='application/json')

# read from db
@app.route('/api/v1/db/read', methods=['POST'])
def read_db():
	# send { table : table_name, wheres : {attr1:attr1, attr2:attr2, ...} }
	req_data = request.get_json()
	table_name = req_data['table'].lower()
	if table_name == 'ride' and 'type' in req_data.keys() and req_data['type'].lower() == 'count':
		query = Ride.query.all()
		return Response(json.dumps(len(query)), status = 200, mimetype = 'application/json')
	try:
		wheres = req_data['wheres']
	except:
		wheres=[]
	tables = {'ride': Ride}
	if table_name in tables:
		Table = tables[table_name]
	else:
		message = {"success": False,
				   "message": "No such table is present in the db"}
		return Response(json.dumps(message), status=400, mimetype='application/json')
	query = {}
	for attr in wheres:
		if attr in app.config['ATTRIBUTES'][table_name] or attr == 'id':
			query.update({str(attr): wheres[attr]})
	result = Table.query.filter_by(**query)
	# serialize the result into python dict
	try:
		result = [i.as_dict() for i in result]
		return Response(json.dumps(result), mimetype='application/json')
	except:
		return Response(json.dumps({}), mimetype='application/json')

@app.route('/', defaults={'u_path': ''}, methods=['GET', 'POST', 'PUT', 'DELETE'])
@app.route('/<path:u_path>', methods=['GET', 'POST', 'PUT', 'DELETE'])
def fallback(u_path):
	args.http_count+=1
	return Response(status = 200)

if __name__ == "__main__":
	app.run(debug=True, port=8000, host='0.0.0.0')
