from flask import Flask,request,jsonify,make_response,session

from flask_sqlalchemy import SQLAlchemy
import requests
import json
import sys
import re
from constants import Places
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column, Integer, String,DateTime
#from sqlalchemy.orm import sessionmaker,scoped_session
import requests
from flask import Response
from sqlalchemy.orm import sessionmaker,scoped_session
from enum import Enum
from datetime import datetime
from multiprocessing import Value

counter = Value('i', 0)
app = Flask(__name__)
app.config['SQLALCHEMY_DATAdb.Model_URI'] = 'sqlite:///:ride_mgmt:'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)
counter = 0
enum_list = list(map(int,Places))

@app.errorhandler(405)
def method_not_found(e):
	path = request.path
	if(path == "/api/v1/rides"):
		counter.value+=1
		return jsonify({}),405
class rides(db.Model):
    __tablename__ = 'rides'

    rideId = Column(Integer, primary_key =  True)
    created_by = Column(String)
    timestamp = Column(String)
    source = Column(String)
    destination = Column(String)
    

    def __init__(self,created_by,timestamp,source,destination):
    	
    	self.created_by = created_by
    	self.timestamp = timestamp
    	self.source = source
    	self.destination = destination

class jtable(db.Model):
    __tablename__ = 'jtable'
    #rideId = Column(Integer, primary_key =  True)
    rideId = Column(Integer, primary_key = True)
    rider_list =Column(String, primary_key = True)
    def __init__(self,rideId,rider_list):
    	self.rideId = rideId
    	self.rider_list =rider_list


#Write to Database
@app.route('/api/v1/db/write',methods=['POST'])
def write():
	data = request.get_json()
	method = data['type']

	#create Ride
	if(method == 'POST'):
		created_by = data['created_by']
		source=data['source']
		destination=data['destination']
		timestamp=data['timestamp']
		create_ride= rides(created_by,timestamp,source,destination)
		db.session.add(create_ride)
		db.session.commit()
		return make_response("",200)
	#join ride
	elif(method == 'jtable'):
		rideId = data['rideId']
		username = data['username']
		create_ride= jtable(rideId,username)	
		db.session.add(create_ride)
		db.session.commit()
		return make_response("",200)
	#delete ride
	elif(method == 'ride'):
		rideId = data['rideId']
		db.session.query(rides).filter(rides.rideId == rideId).delete()
		db.session.commit()
		return  make_response("deleted",200)
	#delete user in ride table
	elif(method=='second'):
		username = data['username']
		db.session.query(rides).filter(rides.created_by == username).delete()
		db.session.commit()
		return  make_response("deleted",200)
	#delete user in jtable
	elif(method=='third'):
		username = data['username']
		db.session.query(jtable).filter(jtable.rider_list == username).delete()
		db.session.commit()
		return  make_response("deleted",200)

#Read from the database
@app.route('/api/v1/db/read',methods = ['POST'])
def read():
	data = request.get_json()
	table = data['table']

 	#Ride table
	if(table == "rides"):
		read_data = rides.query.all()
		ride_data = dict()
		ride_data['rideId'] = []
		ride_data['created_by'] = []
		ride_data['timestamp'] = []
		ride_data['source'] = []
		ride_data['destination'] = []
		for ride in read_data:
			ride_data['rideId'].append(ride.rideId)
			ride_data['created_by'].append(ride.created_by)
			ride_data['timestamp'].append(ride.timestamp)
			ride_data['source'].append(ride.source)
			ride_data['destination'].append(ride.destination)
		return ride_data
	#rider_list table
	elif(table == 'jtable'):
		read_data = jtable.query.all()
		join_data = dict()
		join_data['rideId'] = []
		join_data['rider_list'] =[]
		for user in read_data:
			join_data['rideId'].append(user.rideId)
			join_data['rider_list'].append(user.rider_list)
		return join_data

#Clear the Database
@app.route('/api/v1/db/clear',methods = ['POST'])
def clear_db():
	if(request.method != 'POST'):
		return jsonify ({}),405
	db.session.query(rides).delete()
	db.session.query(jtable).delete()
	db.session.commit()
	return make_response("",200)

#Create a Ride
@app.route('/api/v1/rides',methods=['POST'])
def create_ride():
	with counter.get_lock():
		counter.value+=1
	if(request.method!='POST'):
		return jsonify({}),405
	
	data = request.get_json()
	created_by = data['created_by']
	timestamp=data['timestamp']
	pattern = re.compile(r'^(0[1-9]|[12][0-9]|3[01])[- /.](0[1-9]|1[012])[- /.](19|20)\d\d:(?:[012345]\d)-(?:[012345]\d)-(?:[01]\d|2[0123])$')
	cheader = {'Origin':'3.85.157.37'}
	if(not (re.match(pattern,timestamp))):
		return jsonify({}),400
	else:
		time1 = datetime.strptime(timestamp,"%d-%m-%Y:%S-%M-%H" )
		time = datetime.strftime(time1,"%Y-%m-%d %H:%M:%S")
		source=int(data['source'])
		destination=int(data['destination'])
		#r = requests.get(url = "http://flask1:80/api/v1/users" )
		
		read_data = requests.get('http://rideshare-1251858583.us-east-1.elb.amazonaws.com:80/api/v1/users',headers=cheader)

		read_data = read_data.json()
		#read_data = json.loads(read_data.text)
		print(type(read_data))
		print(read_data)
		for i in range(len(read_data)):
			if(created_by == read_data[i] and source in enum_list and destination in enum_list):
				print(type(created_by),created_by,type(read_data[0]),read_data[0])
				response = requests.post('http://127.0.0.1:80/api/v1/db/write',json={"type":request.method,"created_by":created_by,"timestamp":time,"source":source,"destination":destination})
				if(response):
					return jsonify({}),201
		else:
			return jsonify({}),400

#List All the Rides.
@app.route('/api/v1/rides',methods=['GET'])
def list_rides():
	with counter.get_lock():
		counter.value+=1
	if(request.method!='GET'):
		return jsonify({}),405
	source = int(request.args.get("source"))
	destination = int(request.args.get("destination"))
	read_data = requests.post('http://127.0.0.1:80/api/v1/db/read',json={"table":"rides"})
	read_data = read_data.json()
	upcoming = []
	current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
	current_time = datetime.now().strptime(current_time,"%Y-%m-%d %H:%M:%S")
	for i in range(len(read_data["created_by"])):
		time1 = datetime.strptime(read_data['timestamp'][i],"%Y-%m-%d %H:%M:%S")
		if(source == int(read_data['source'][i]) and destination == int(read_data['destination'][i]) and time1>current_time):
			time1 = datetime.strptime(read_data['timestamp'][i],"%Y-%m-%d %H:%M:%S")
			time = datetime.strftime(time1,"%d-%m-%Y:%S-%M-%H")
			upcoming.append({"rideId":read_data['rideId'][i],"username":read_data['created_by'][i],"timestamp":time})
	if(len(upcoming)!=0):
		return jsonify(upcoming),200
	elif(len(upcoming)==0):
		return jsonify({}),204
	else:
		return jsonify({}),400


#Ride Details
@app.route('/api/v1/rides/<rideId>',methods=['GET'])
def ride_details(rideId):
	with counter.get_lock():
		counter.value+=1
	read_data = requests.post('http://127.0.0.1:80/api/v1/db/read',json={"table":"rides"})
	read_data = read_data.json()
	join_data = requests.post('http://127.0.0.1:80/api/v1/db/read',json={"table":"jtable"})
	join_data = join_data.json()
	rideId = int(rideId)
	jlist=[]
	for i in range(len(join_data['rideId'])):
		if rideId==join_data['rideId'][i]:
			jlist.append(join_data['rider_list'][i])
	for i in range(len(read_data["rideId"])):
		if(rideId == read_data["rideId"][i]):
			time1 = datetime.strptime(read_data['timestamp'][i],"%Y-%m-%d %H:%M:%S" )
			time = datetime.strftime(time1,"%d-%m-%Y:%S-%M-%H")
			return jsonify({"rideId":rideId,"created_by":read_data['created_by'][i],"users":jlist,"timestamp":time,"source":read_data['source'][i],"destination":read_data['destination'][i]})
	else:
		return jsonify({}),204

#Join the existing Ride
@app.route('/api/v1/rides/<rideId>',methods = ['POST'])
def join_ride(rideId):
	with counter.get_lock():
		counter.value+=1
	if(request.method!='POST'):
		return jsonify({}),405
	rideId = int(rideId)
	data = request.get_json()
	username = data['username']
	cheader = {'Origin':'3.85.157.37'}
	ride_data = requests.post('http://127.0.0.1:80/api/v1/db/read',json={"table":"rides"})
	ride_data = ride_data.json()
	user_data = read_data = requests.get('http://rideshare-1251858583.us-east-1.elb.amazonaws.com//:80/api/v1/users',headers=cheader)
	user_data = user_data.json()
	jtable_data = requests.post('http://127.0.0.1:80/api/v1/db/read',json={"table":"jtable"})
	jtable_data = jtable_data.json()
	current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
	current_time = datetime.now().strptime(current_time,"%Y-%m-%d %H:%M:%S")
	if(username in user_data):
		for i in range(len(ride_data['rideId'])):
			time1 = datetime.strptime(ride_data['timestamp'][i], "%Y-%m-%d %H:%M:%S")
			if(rideId == ride_data['rideId'][i] and time1>current_time and username != ride_data['created_by'][i]):
				write = requests.post('http://127.0.0.1:80/api/v1/db/write',json={"type":"jtable","rideId":rideId,"username":username})
				if(write):
					return jsonify({}),200
		else:
			return jsonify({}),204
	else:
		return jsonify({}),400



#Delete the ride
@app.route('/api/v1/rides/<rideId>',methods = ['DELETE'])
def delete_ride(rideId):
	with counter.get_lock():
		counter.value+=1
	if(request.method!='DELETE'):
		return jsonify({}),405
	user_data = requests.post('http://127.0.0.1:80/api/v1/db/read',json={"table":"rides"})
	user_data = user_data.json()
	rideId =int(rideId)
	for i in range(len(user_data['rideId'])):	
		if rideId == user_data['rideId'][i]:
			write = requests.post('http://127.0.0.1:80/api/v1/db/write',json={"type":"ride","rideId":rideId})
			if(write):
				return jsonify({}),200
			return jsonify({}),400
	else:
		return jsonify({}),204

#Get the count of HTTP requests
@app.route('/api/v1/_count',methods = ['GET'])
def count_requests():
	if(request.method!='GET'):
		return jsonify({}),405
    
	return jsonify([counter.value]),200


#Reset the Http requests counter
@app.route('/api/v1/_count',methods = ['DELETE'])
def reset_count():
	
	if(request.method!='DELETE'):
		return jsonify({}),405
	counter.value = 0
	return jsonify({}),200

#Count the rides
@app.route('/api/v1/rides/count',methods = ['GET'])
def count_rides():
	with counter.get_lock():
		counter.value+=1
	if(request.method!='GET'):
		return jsonify({}),405
	read_data = requests.post('http://127.0.0.1:80/api/v1/db/read',json={"table":"rides"})
	read_data = read_data.json()
	#print(len(read_data['rideId']))
	return jsonify([len(read_data['rideId'])]),200

if __name__=="__main__":
	db.create_all()
	app.debug = True
	app.run(host = '0.0.0.0',port=80)


