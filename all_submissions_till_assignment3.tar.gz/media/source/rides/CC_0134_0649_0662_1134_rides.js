const Ride = require('../../models/Ride');
// const Counter = require('../../models/Counter');
// var incCounter = require('../../middleware/counter').incCounter;

var globalC = 0;

rp = require('request-promise-native');

function checkDate(date){
  var pattern = new RegExp("^(3[01]|[12][0-9]|0[1-9])-(1[0-2]|0[1-9])-[0-9]{4}:([0-5]?[0-9])-([0-5]?[0-9])-(2[0-3]|[01]?[0-9])$");
  if (date.search(pattern)===0) return true;
  else return false;

}

function convertToISO(date){
  var cleanDate = date.replace(/-/g, " ");
  cleanDate = cleanDate.replace(/:/g, " ");
  var splitDate = cleanDate.split(" "); 
  var final = splitDate[2]+"-"+splitDate[1]+"-"+splitDate[0]+"T"+splitDate[5]+":"+splitDate[4]+":"+splitDate[3]+"Z";
  return final;
}  

function convertToFormat(date){
  var cleanDate = date.replace("T", "-");
  cleanDate = cleanDate.replace("Z", "");
  cleanDate = cleanDate.replace(/:/g, "-");
  var splitDate = cleanDate.split("-");
  var final = splitDate[2]+"-"+splitDate[1]+"-"+splitDate[0]+":"+(parseInt(splitDate[5]).toString())+"-"+splitDate[4]+"-"+splitDate[3];
  return final;
}

module.exports = (app) => {
  app.use('/api/v1/rides', (req, res, next)=>{
    console.log("Incremented. Inside use.");
    globalC += 1;
    next();
  });

  //API:3 Create a new ride
  app.post('/api/v1/rides', (req, res) => {
    var created_by = req.body.created_by;
    var timestamp = req.body.timestamp;
    var source = parseInt(req.body.source);
    var destination = parseInt(req.body.destination);

    if (!created_by) {
        return res.status(400).send({
            success: false,
            message: 'Error: created_by cannot be blank.'
        });
    }
    if (!source) {
        return res.status(400).send({
            success: false,
            message: 'Error: source cannot be blank.'
        });
    }
    if (!destination) {
        return res.status(400).send({
            success: false,
            message: 'Error: destination cannot be blank.'
        });
    }

    if(source == destination) {
      return res.status(400).send({
        success: false,
        message: 'Error: source is equal to destination.'
      });
    }

    if (source < 1 || source > 198) {
      return res.status(400).send({
          success: false,
          message: 'Error: source out of range.'
      });
    }

    if (destination < 1 || destination > 198) {
      return res.status(400).send({
          success: false,
          message: 'Error: destination out of range.'
      });
    }
    var options = {
      method: 'GET',
      uri: 'http://PESURideShare-972905440.us-east-1.elb.amazonaws.com/api/v1/users',
      headers: {
        'Origin': 'http://18.213.180.134'
      }
    };
    rp(options).then((RPRes) => {
        var previousUsers = JSON.parse(RPRes);
        console.log(previousUsers);

        if (previousUsers.length == 0) {
          return res.status(400).send({
              success: false,
              message: 'Error: User does not exist.'
          });
        }
        userFlag = false;
        for(var i = 0; i<previousUsers.length; i++){
          if(previousUsers[i]==created_by){
            userFlag = true;
          }
        }
        if (!userFlag) {
          return res.status(400).send({
              success: false,
              message: 'Error: User not in list.'
          });
        }        

        const newRide = new Ride();

        if(timestamp){
            if(checkDate(timestamp) == true){
              var returnedDate = convertToISO(timestamp);
              var dateObject = new Date(returnedDate);
              var todaysDate = new Date();

              // FIXME: Check if required
              var adjustedDate = new Date(todaysDate.getTime() + 60000);

              if(dateObject<adjustedDate){
                return res.status(400).send({
                  success: false,
                  message: 'Error: Timestamp is before now.'
                });
              }

              newRide.timestamp = new Date(returnedDate);
            }
            else{
              return res.status(400).send({
                success: false,
                message: 'Error: Timestamp not in correct format.'
              });
            }
        }

        newRide.created_by = created_by;
        newRide.source = source;
        newRide.destination = destination;
        newRide.created_by = created_by;

        newRide.save((err) => {
          if (err) {
            console.log(err.message); 
            return res.status(500).send({
                success: false,
                message: "Error: Server error.",
                error: err.message,
              });
          }
          console.log("Ride " + newRide._id + " added to DB.");
        return res.status(201).send({});
        //   return res.status(201).send({
        //     success: true,
        //     message: 'Ride created.'
        // });
          
        });
      
      
    }).catch((err) => {
      console.log("RP GET failed.");
      console.log(err);      
      return res.status(500).send({
        success: false,
        message: "Error: Server error.",
        error: err.message,
      });
    });

    // Find to check if user is valid
    // User.find({
    //     username: created_by
    // }, (err, previousUsers) => {
    //     if (err) {
    //         console.log(err.message);
    //         return res.status(500).send({
    //           success: false,
    //           message: "Error: Server error.",
    //           error: err.message,
    //         });
    //     } if (previousUsers.length == 0) {
    //         return res.status(400).send({
    //             success: false,
    //             message: 'Error: User does not exist.'
    //         });
    //     }
    //     const newRide = new Ride();

    //     if(timestamp){
    //         if(checkDate(timestamp) == true){
    //           var returnedDate = convertToISO(timestamp);
    //           var dateObject = new Date(returnedDate);
    //           var todaysDate = new Date();

    //           // FIXME: Check if required
    //           var adjustedDate = new Date(todaysDate.getTime() + 60000);

    //           if(dateObject<adjustedDate){
    //             return res.status(400).send({
    //               success: false,
    //               message: 'Error: Timestamp is before now.'
    //             });
    //           }

    //           newRide.timestamp = new Date(returnedDate);
    //         }
    //         else{
    //           return res.status(400).send({
    //             success: false,
    //             message: 'Error: Timestamp not in correct format.'
    //           });
    //         }
    //     }

    //     newRide.created_by = created_by;
    //     newRide.source = source;
    //     newRide.destination = destination;
    //     newRide.created_by = created_by;

    //     newRide.save((err) => {
    //       if (err) {
    //         console.log(err.message); 
    //         return res.status(500).send({
    //             success: false,
    //             message: "Error: Server error.",
    //             error: err.message,
    //           });
    //       }
    //       console.log("Ride " + newRide._id + " added to DB.")
    //       return res.status(201).send({});
    //     //   return res.status(201).send({
    //     //     success: true,
    //     //     message: 'Ride created.'
    //     // });
    //     });
    // });
  });



  // API: 4 List all upcoming rides for a given source and destination
  app.get('/api/v1/rides/', (req, res) => {
    var source = parseInt(req.query.source);
    var destination = parseInt(req.query.destination);

    if(source == destination) {
      return res.status(400).send({
        success: false,
        message: 'Error: source is equal to destination.'
      });
    }

    if (source < 1 || source > 198) {
      return res.status(400).send({
          success: false,
          message: 'Error: source out of range.'
      });
    }

    if (destination < 1 || destination > 198) {
      return res.status(400).send({
          success: false,
          message: 'Error: destination out of range.'
      });
    }

    var retRides = [];

    if (!source) {
      return res.status(400).send({
        success: false,
        message: 'Error: source parameter cannot be blank.'
      });
    }
    if (!destination) {
        return res.status(400).send({
          success: false,
          message: 'Error: destination parameter cannot be blank.'
        });
    }

    Ride.find({
      source : source,
      destination : destination,
      timestamp : { $gte : new Date() } // Only ge
    }, (err, rides) => {
      if (err) {
        console.log(err.message);
            return res.status(500).send({
                success: false,
                message: "Error: Server error.",
                error: err.message,
        });
      }
      
      if (rides.length == 0) {
        return res.status(204).send({ 
          success: false,
          message: 'Error: Rides not found.'
        });
      }

      var formatedDate;

      for(var i = 0; i < rides.length; i++){
        formatedDate = convertToFormat(rides[i].timestamp.toISOString());
        retRides.push({
          "rideId":rides[i]._id,
          "username":rides[i].created_by,
          "timestamp":formatedDate
        });
      }

    return res.status(200).send(retRides);
    // return res.status(200).send({
    //   success: true,
    //   message: "Rides successfully retrieved.",
    //   rides: retRides
    // });
      

    });
  });

  // API: 5 List all the details of a given ride
  app.get('/api/v1/rides/:rideId', (req, res) => {
    var rideId = req.params.rideId;

    if (!rideId) {
      return res.status(400).send({
        success: false,
        message: 'Error: rideId parameter cannot be blank.'
      });
    }
    if(rideId.includes("count")){
      console.log("Caught inside GET by rideId.");
      Ride.find({}, (err, rides) => {
        var count = rides.length;
        console.log("No. of rides is: " + count.toString());
        if (err) {
          console.log(err.message);
          return res.status(500).send({
              success: false,
              message: "Error: Server error.",
              error: err.message,
            });
        }
        return res.status(200).send([count]);
        // return res.status(200).send({
        //     success: true,
        //     message: "Number of rides success.",
        //     data: count
        // }); 
      });
    }
    else{
    Ride.find({
      _id : rideId,
    }, (err, ride) => {
      if (err) {
        console.log(err.message);
        return res.status(500).send({
          success: false,
          message: "Error: Server error.",
          error: err.message
        });
      }
      if (ride.length == 0) {
        return res.status(400).send({
          success: false,
          message: 'Error: Ride not found.'
        });
      }

      var formatedDate = convertToFormat(ride[0].timestamp.toISOString());

      var rideStruct = {
        "rideId": ride[0]._id,
        "created_by": ride[0].created_by,
        "users": ride[0].users,
        "timestamp": formatedDate,
        "source": ride[0].source,
        "destination": ride[0].destination
      }

    return res.status(200).send(rideStruct);
        // return res.status(200).send({
        //   success: true,
        //   message: "Ride successfully retrieved.",
        //   ride: rideStruct
        // });
      
    });
    }
  });


  //API:6 Join an existing ride
  app.post('/api/v1/rides/:rideId', (req, res) => {
    var rideId = req.params.rideId;
    var username = req.body.username;

    if (!rideId) {
      return res.status(400).send({
        success: false,
        message: 'Error: rideId not provided.'
      });
    }

    var options = {
      method: 'GET',
      uri: 'http://PESURideShare-972905440.us-east-1.elb.amazonaws.com/api/v1/users',
      headers: {
        'Origin': 'http://18.213.180.134'
      }
    };

    rp(options).then((RPRes) => {
      var previousUsers = JSON.parse(RPRes);
      console.log(previousUsers);

      if (previousUsers.length == 0) {
        return res.status(400).send({
            success: false,
            message: 'Error: User does not exist.'
        });
      }
      userFlag = false;
      for(var i = 0; i<previousUsers.length; i++){
        if(previousUsers[i]==created_by){
          userFlag = true;
        }
      }
      if (!userFlag) {
        return res.status(400).send({
            success: false,
            message: 'Error: User not in list.'
        });
      }
      
      Ride.findOneAndUpdate({
        _id: rideId
        }, {
            $addToSet: { users : username }
        }, { new: true }, (err, ride) => {
            if (err) {
              console.log(err.message);
              return res.status(500).send({
                  success: false,
                  message: "Error: Server error.",
                  error: err.message,
                });
            }

            if(ride.length == 0){
              return res.status(204).send({
                success: false,
                message: 'Error: Ride does not exist.'
              });
            }
         
            console.log("Ride "+ ride._id + " added to user " + user._id);
          return res.status(200).send({});
          // return res.status(200).send({
          //   success: true,
          //   message: "User successfully added.",
          // });
            
            
      });

    }).catch((err) => {
      console.log("RP GET failed.");
      console.log(err);
      return res.status(500).send({
        success: false,
        message: "Error: Server error.",
        error: err.message,
      }); 
    });

    // User.find({
    //   username: username,
    // }, (err, user) => {
    //   if (err) {
    //     console.log(err.message);
    //     return res.status(500).send({
    //       success: false,
    //       message: "Error: Server error.",
    //       error: err.message
    //     });
    //   }
    //   if (user.length == 0) {
    //     return res.status(400).send({
    //       success: false,
    //       message: 'Error: User does not exist.'
    //     });
    //   }

    //   Ride.findOneAndUpdate({
    //     _id: rideId
    //     }, {
    //         $addToSet: { users : username }
    //     }, { new: true }, (err, ride) => {
    //         if (err) {
    //           console.log(err.message);
    //           return res.status(500).send({
    //               success: false,
    //               message: "Error: Server error.",
    //               error: err.message,
    //             });
    //         }

    //         if(ride.length == 0){
    //           return res.status(204).send({
    //             success: false,
    //             message: 'Error: Ride does not exist.'
    //           });
    //         }
         
    //         console.log("Ride "+ ride._id + " added to user " + user._id);
    //         return res.status(200).send({});
    //         // return res.status(200).send({
    //         //   success: true,
    //         //   message: "User successfully added.",
    //         // });
            
    //   });
    // })
  }),

  //API: 7 Delete a ride
  app.delete('/api/v1/rides/:rideId', (req, res) => {
    var rideId = req.params.rideId;
    if (!rideId) {
        return res.status(405).send({
            success: false,
            message: "Error: rideId not recieved."
        });
    }

    Ride.findOneAndDelete({
        _id : rideId
    }, (err, ride) => {
        if (err) {
          console.log(err.message);
          return res.status(500).send({
              success: false,
              message: "Error: Server error.",
              error: err.message,
            });
        }
        if (ride.length == 0) {
            return res.status(405).send({
                success: false,
                message: 'Error: ride not found.'
            });
        }


      return res.status(200).send({});
          // return res.status(200).send({
          //     success: true,
          //     message: "Ride " + ride._id + " successfully deleted."
          // }); 
    })
  });

  // app.get('api/v1/rides/count/', (req, res) => {
  //   Ride.find({}, (err, rides) => {
  //     var count = rides.length;
  //     console.log("No. of rides is: " + count.toString());
  //     if (err) {
  //       console.log(err.message);
  //       return res.status(500).send({
  //           success: false,
  //           message: "Error: Server error.",
  //           error: err.message,
  //         });
  //     }
  //     return res.status(200).send([count]);
  //     // return res.status(200).send({
  //     //     success: true,
  //     //     message: "Number of rides success.",
  //     //     data: count
  //     // }); 
  //   });
  // });

  //API X: Return count
  app.get('/api/v1/_count/', (req, res) => {
    console.log("Incrementing.");
    res.status(200).send([globalC]);
  });

  //API X+1: Delete or reset count
  app.delete('/api/v1/_count/', (req, res) => {
      console.log("Reset.");
      globalC = 0;
      return res.status(200).send({});    
  });
};
