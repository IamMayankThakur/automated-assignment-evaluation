from flask import Flask, Request, jsonify,request ,  Response,json , url_for
from collections import defaultdict
import csv
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm.attributes import flag_modified
#from sqlalchemy.types import *
from flask_marshmallow import Marshmallow
from sqlalchemy import PickleType
#import os
#from crud import *
import datetime
import requests
#import tldextract
import re
from datetime import datetime
from datetime import date
app = Flask(__name__)
#basedir = os.path.abspath(os.path.dirname(__file__))
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///CC_0024_0162_1618_1640_app1.sqlite'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
dab = SQLAlchemy(app)
ma = Marshmallow(app)
from multiprocessing import Value
counter = Value("i",0)


@app.errorhandler(405)
def method_not_found(e):
    path=request.path
    if(path=="/api/v1/users"):
        counter.value+=1
        return jsonify({}),405



class Ride(dab.Model):
    rideId=dab.Column(dab.Integer(),primary_key=True)
    created_by=dab.Column(dab.String())
    source=dab.Column(dab.Integer())
    destination=dab.Column(dab.Integer())
    timestamp=dab.Column(dab.String())
    riders=dab.Column(dab.PickleType())
    #users = dab.Column(dab.String())

    def __init__(self,created_by,source,destination,timestamp,riders=[]):
        self.created_by=created_by
        self.source=source
        self.destination=destination
        self.timestamp=timestamp
        self.riders=riders
        #self.users=users

class RideSchema(ma.Schema):
    class Meta:
        fields=('created_by','source','destination','timestamp','riders')

ride_schema=RideSchema()
rides_schema=RideSchema(many=True)

dab.create_all()

def check(number1,number2):
    lis=[]
    for i in range(1,199):
        lis.append(i)
    if int(number1) in lis and  int(number2) in lis:
        return True
    else:
        return False

def converter(string):
    arr=string.split(',')
    arr1=arr[0].split('/')
    arr2=arr[1].split(':')
    date=arr1[1]+"-"+arr1[0]+"-"+arr1[2]+":"+arr2[2]+"-"+arr2[1]+"-"+(arr2[0]).strip(" ") 
    return str(date)

@app.route("/api/v1/rides", methods=["POST"])
def new_ride():
    with counter.get_lock():
        counter.value+=1
    dic = {}
    dictt={}
    dictt["some"] = "adduser"
    url="http://Load-Balancer-646677035.us-east-1.elb.amazonaws.com:80/api/v1/users"
    #url="http://127.0.0.1:8080/api/v1/users"
    s = request.get_json()["created_by"]
    dictt['username'] = s
    r = requests.get(url,headers = {'Origin':'3.213.139.88'})
    created_by=request.get_json()["created_by"]
    r1=r.text
    x=r1.strip("[")
    y=x.strip("]")
    lis = y.split(",")
    lis1=[]
    for i in lis:
        x=i.strip()
        y=x.strip("'")
        lis1.append(y)
    if created_by in lis1:
        num1=request.get_json()["source"]
        num2=request.get_json()["destination"]
        if num1==num2:         
            return jsonify({}),400
        elif(check(num1,num2)):
            dic["created_by"]=request.get_json()["created_by"]
            dic["source"]=request.get_json()["source"]
            dic["destination"]=request.get_json()["destination"]
            time = request.get_json()["timestamp"]   
            arr=time.split(":")
            da=[]
            for i in arr:
                da.append(i.split('-'))
            pa = re.compile("^[0-9][0-9]\-[0-9][0-9]\-[0-9][0-9][0-9][0-9]\:[0-9][0-9]\-[0-9][0-9]\-[0-9][0-9]$")
            try:
                if re.match(pa,time):
                    d  = datetime(int(da[0][2]),int(da[0][1]),int(da[0][0]),int(da[1][2]),int(da[1][1]),int(da[1][0])) 
                    dtime = d.strftime("%m/%d/%Y, %H:%M:%S")
                    dic['timestamp'] = dtime
                    #dic["timestamp"]= json.dumps(d, default = myconverter)
                    dic["some"] = "rides"
                    dic['riders'] = []
                    #dictt=json.dumps(dic, default = myconverter)
                    url="http://3.213.139.88:80/api/v1/db/write"
                    headers = {'Content-type': 'application/json', 'Accept': 'text/plain'}
                    r = requests.post(url, json = dic, headers=headers)
                    return jsonify({}),201 
                else:
                    return jsonify({}),400       
            except ValueError:
                return jsonify({}),400
        else:
            return jsonify({}),400
    else:
        return jsonify({}),400

@app.route("/api/v1/rides", methods=["GET"])
def list_details():
    with counter.get_lock():
        counter.value+=1
    source = request.args.get('source')
    destination = request.args.get('destination')
    if(source==destination):
        return jsonify({}),400
    elif(check(source,destination)):
        dicto ={}
        dicto['source']  = source
        dicto['destination'] = destination
        dicto['some'] = 'list'
        url="http://3.213.139.88:80/api/v1/db/read"
        headers = {'Content-type': 'application/json', 'Accept': 'text/plain'}
        r = requests.post(url,json = dicto ,headers = headers)
        if r.text=="None":
            return jsonify({}),204
        else:
            return r.text
    else:
        return jsonify({}),400
        


@app.route("/api/v1/rides/<rideId>",methods=["GET"])
def get_details(rideId):
    with counter.get_lock():
        counter.value+=1
    #rideid = request.args.get('rideId')
    #ride=Ride.query.get(rideId)
    #if(ride):
    data = {}
    data['rideId'] = rideId
    data['some'] = 'ridesid'
    url="http://3.213.139.88:80/api/v1/db/read"
    headers = {'Content-type': 'application/json', 'Accept': 'text/plain'}
    r = requests.post(url,json=data,headers = headers)
    #return r.text
    x=r.json()
    if(not x):
        return jsonify({}),204
    else:
        dumb={}
        dit={}
        dit["some"]="get_details"
        dit["riders"]=r.json()["riders"]
        url="http://3.213.139.88:80/api/v1/db/read"
        headers = {'Content-type': 'application/json', 'Accept': 'text/plain'}
        res = requests.post(url,json=dit,headers = headers)
        dumb["rideId"]=rideId
        dumb["created_by"]=r.json()["created_by"]
        li=r.json()["riders"]
        dumb["users"]=res.json()
        dumb["timestamp"]=converter(r.json()["timestamp"])
        dumb["source"]=str(r.json()["source"])
        dumb["destination"]=str(r.json()["destination"])
        return dumb
        #return res.text

@app.route("/api/v1/rides/<rideId>",methods=["POST"])
def join_ride(rideId):
    with counter.get_lock():
        counter.value+=1
    data = {}
    dic={}
    username = request.json['username']    
    dic['username'] = username
    dic['rideId'] = rideId
    dic['some'] = "join_ride"
    url="http://3.213.139.88:80/api/v1/db/read"
    headers = {'Content-type': 'application/json', 'Accept': 'text/plain'}
    r = requests.post(url,json=dic,headers=headers)
    #return str(type(r.text))
    x=r.json()
    if(str(x["exists"])=="None"):
        return jsonify({}),400
    url1="http://Load-Balancer-646677035.us-east-1.elb.amazonaws.com:80/api/v1/users"
    headers = {'Origin': '3.213.139.88'}
    #url1="http://3.213.139.88:80/api/v1/users"
    r2 = requests.get(url1,headers = headers)
    r3 = r2.text
    x=r3.strip("[")
    y=x.strip("]")
    lis = y.split(",")
    lis1=[]
    for i in lis:
        x1=i.strip()
        y=x1.strip("'")
        lis1.append(y)
    if username in lis1:
        data['some'] = 'join_rides'
        data['rideId'] = rideId
        data['username'] = username
        url="http://3.213.139.88:80/api/v1/db/write"
        headers = {'Content-type': 'application/json', 'Accept': 'text/plain'}
        r = requests.post(url,json = data ,headers = headers)   
        if(r.text=="creator" or r.text=="already added"):
            return jsonify({}),400
        else:
            return jsonify({}),200
    else:
        return jsonify({}),400
          


@app.route("/api/v1/rides/<rideId>", methods=["DELETE"])
def ride_delete(rideId):
    with counter.get_lock():
        counter.value+=1
    dic = {}
    dic['rideId'] = rideId
    dic['some'] = "delete_ride"
    url="http://3.213.139.88:80/api/v1/db/read"
    headers = {'Content-type': 'application/json', 'Accept': 'text/plain'}
    r = requests.post(url,json = dic ,headers = headers)
    #return r.json
    x = r.json()
    if str(x['exists'])=="None":
        return jsonify({}),400
    else:
        url="http://3.213.139.88:80/api/v1/db/write"
        headers = {'Content-type': 'application/json', 'Accept': 'text/plain'}
        res = requests.post(url, json = dic, headers=headers)
        return jsonify({}),200
        #return res.text

@app.route("/api/v1/db/clear",methods=["POST"] )
def clear_db():
    with counter.get_lock():
        counter.value+=1
    rides=Ride.query.all()
    for ride in rides:
        dab.session.delete(ride)
        dab.session.commit()
    return jsonify({}),200


@app.route("/api/v1/rides/count",methods=["GET"])
def rides_count():
    count = 0
    with counter.get_lock():
        counter.value+=1
    rides=Ride.query.all()
    for ride in rides:
        count+=1
    li = []
    li.append(count)
    return str(li)


@app.route("/api/v1/db/write", methods=["POST"])
def write_dab():
    content = ""
    #ext = tldextract.extract("http://3.213.139.88:80/user")
    if (request.json['some'] == "rides"):
        content = request.json
        created_by = content['created_by']
        source = content['source']
        destination = content['destination']
        timestamp = content['timestamp']
        riders = content['riders']
        #riders.append(created_by)
        new_ride = Ride(created_by,source,destination,timestamp,riders )
        dab.session.add(new_ride)
        dab.session.commit()
        return content

    elif (request.json['some'] == 'join_rides'):
        content = request.json
        rideId = content['rideId']
        username = content['username']
        ride=Ride.query.filter_by(rideId=rideId).first()
        x=ride.riders
        if ride.created_by == username:
            return "creator"
        elif (username not in x):
            x.append(username)
            ride.riders=x
            flag_modified(ride,"riders")
            dab.session.merge(ride)
            dab.session.flush()
            dab.session.commit()
            return ride_schema.jsonify(ride)
        else:
            return "already added"

    elif (request.json['some'] == 'delete_ride'):
        content = request.json
        rideId = content['rideId']
        ride=Ride.query.get(rideId)
        dab.session.delete(ride)
        dab.session.commit()
        return ride_schema.jsonify(ride)
        
@app.route('/api/v1/db/read',methods=['POST'])
def read_dab():
    content = ''
    if (request.json['some'] == 'ridesid'):
        content = request.json
        rideId = content['rideId']
        ride=Ride.query.get(rideId)
        return ride_schema.jsonify(ride)
    elif request.json['some'] == "join_ride":
        content = request.json
        username=content['username']
        rideId=content['rideId']
        exists=dab.session.query(Ride.rideId).filter_by(rideId=rideId).scalar()
        dic={}
        dic['exists'] = exists
        return dic

    elif(request.json['some']=='delete_ride'):
        content = request.json
        rideId = content['rideId']
        exists=dab.session.query(Ride.rideId).filter_by(rideId=rideId).scalar()
        dic = {}
        dic['exists'] = exists
        return dic
    elif (request.json['some'] == 'list'):     
        content1 = request.json
        source = content1['source']
        destination = content1['destination']    
        ride_id=dab.session.query(Ride.rideId).filter(Ride.source==source,Ride.destination==destination).all()
        s=str(ride_id)
        lis=[]
        x=map(int,re.findall(r'\d+',s))
        for i in list(x):
            ride=Ride.query.get(i)
            dumb={}
            dumb["rideId"]=ride.rideId
            dumb["username"]=ride.created_by
            username = ride.created_by
            timestamp = ride.timestamp
            now = datetime.now()
            timestamp = datetime.strptime(timestamp, '%m/%d/%Y, %H:%M:%S')
            url1="http://Load-Balancer-646677035.us-east-1.elb.amazonaws.com:80/api/v1/users"
            headers = {'Origin': '3.213.139.88'}
            #url1="http://3.213.139.88:8080/api/v1/users"
            r2 = requests.get(url1,headers = headers)
            r3 = r2.text
            x=r3.strip("[")
            y=x.strip("]")
            listt = y.split(",")
            lis1=[]
            for i in listt:
                x1=i.strip()
                y=x1.strip("'")
                lis1.append(y)
            if username not in lis1:
                pass    
            elif now > timestamp:
                pass
            else:
                dumb["timestamp"]=converter(ride.timestamp)
                lis.append(dumb)
        if(len(lis)==0):
            return "None"
        else:
            return jsonify(lis)
    elif (request.json['some'] == 'get_details'):
        content=request.json
        riders=content['riders']
        new_riders=[]
        url1="http://Load-Balancer-646677035.us-east-1.elb.amazonaws.com:80/api/v1/users"
        headers = {'Origin': '3.213.139.88'}
        #url1="http://3.213.139.88:80/api/v1/users"
        r2 = requests.get(url1,headers = headers)
        r3 = r2.text
        x=r3.strip("[")
        y=x.strip("]")
        lis = y.split(",")
        lis1=[]
        for i in lis:
            x1=i.strip()
            y=x1.strip("'")
            lis1.append(y)
        for rider in riders:
            if rider in lis1:
                new_riders.append(rider)
            else:
                pass
        return jsonify(new_riders)


        
@app.route("/api/v1/_count",methods=['GET'])
def get_count():
    li = []
    li.append(counter.value)
    return str(li)

@app.route("/api/v1/_count",methods=['DELETE'])
def reset_count():
    counter.value=0
    return jsonify({}),200

  
if __name__ == '__main__':
    app.run(host="0.0.0.0",port=80,debug=True)



