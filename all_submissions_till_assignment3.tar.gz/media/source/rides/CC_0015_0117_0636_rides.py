import pymongo
from flask import abort, request, json, Flask, Response
from random import randint
import enum
import requests
import json

myclient = pymongo.MongoClient("mongodb://localhost:27017/")
app = Flask(__name__)

myRides = myclient["Rides"]
myUsers = myclient["Users"]
ridesCol = myRides["rides"]
usersCol = myUsers["users"]
rideId = set()
global count
count = 0


def generate_id():
    l = [1]
    while l:
        n = randint(1, 9999)
        query = {"rideId": n}
        doc = ridesCol.find(query)
        l = []
        for x in doc:
            l.append(x)
    return n


@app.route("/api/v1/rides", methods=["POST", "GET"])  # 3 and 4
def create_ride():
    global count

    count += 1
    if request.method == "POST":

        try:
            data = request.get_json()
            # print(data)
        except:
            # print("\n\nhi\n\n")
            return Response(json.dumps({"success": "false"}), status=400, mimetype="application/json")

        if not(data["created_by"] or data["timestamp"] or data["source"] or data["destination"]):
            return Response(json.dumps({"success": "false"}), status=400, mimetype="application/json")

        # change url of this request so that it calls add_users API of users microservice
        # temp = requests.get("http://localhost:8000/api/v1/rides", json=data)

        # if temp.status_code == 200:
        #     pass
        # else:

        #     return Response(json.dumps({"success": "false"}), status=400, mimetype="application/json")

        query = {"username": data["created_by"]}
        doc = usersCol.find(query)
        l = []
        for x in doc:
            l.append(x)

        if not l:
            return Response(json.dumps({"success": "false"}), status=400, mimetype="application/json")

        data['table'] = 'rides'
        data['type'] = 'insert'
        response = requests.post(
            "http://localhost:8000/api/v1/db/write", json=data)

        if response.status_code == 201:
            return Response(json.dumps({"success": "true"}), status=201, mimetype="application/json")

    elif request.method == "GET":

        data = request.get_json()
        if data:
            return Response(json.dumps({"success": "false"}), status=400, mimetype="application/json")

        source = request.args.get("source")
        destination = request.args.get("destination")

        query = {"source": source, "destination": destination}
        doc = ridesCol.find(query)
        l = []
        for x in doc:
            l.append(x)
        if not l:
            return Response(json.dumps({"success": "empty body"}), status=204, mimetype="application/json")

        data['table'] = 'rides'
        data['type'] = 'read'
        data['source'] = source
        data['destination'] = destination
        response = requests.post(
            "http://localhost:8000/api/v1/db/read", json=data)

        if response.status_code == 400:
            return Response(json.dumps({"success": "false"}), status=400, mimetype="application/json")

        elif response.status_code == 200:
            data1 = response.json()
            final = []
            for x in data1:
                temp = {}
                temp['rideId'] = x['rideId']
                temp['username'] = x["created_by"]
                temp['timestamp'] = x['timestamp']
                final.append(temp)
            return Response(json.dumps(final), status=200, mimetype="application/json")


# 5 and 6 and 7
@app.route("/api/v1/rides/<rideId>", methods=["GET", "POST", "DELETE"])
def list_details(rideId):

    global count
    count += 1

    
    if request.method == "GET":
        data = request.get_json()
        if data:
            return Response(json.dumps({"success": "false"}), status=400, mimetype="application/json")

        data = {}
        data['table'] = 'rides'
        data['type'] = 'rideId'
        data['rideId'] = rideId
        response = requests.post(
            "http://localhost:8000/api/v1/db/read", json=data)

        if response.status_code == 204:
            return Response(json.dumps({"success": "empty body"}), status=204, mimetype="application/json")

        elif response.status_code == 200:
            data1 = response.json()
            return Response(json.dumps(data1), status=200, mimetype="application/json")

    elif request.method == "POST":
        try:
            data = request.get_json()
        except:
            return Response(json.dumps({"success": "false"}), status=400, mimetype="application/json")

        # change url of this request so that it calls add_users API of users microservice
        temp = requests.get("http://localhost:8000/api/v1/rides", json=data)

        if temp.status_code == 200:
            pass
        else:
            return Response(json.dumps({"success": "false"}), status=400, mimetype="application/json")

        data['rideId'] = rideId
        data['table'] = 'rides'
        data['type'] = 'join'

        response = requests.post(
            "http://localhost:8000/api/v1/db/write", json=data)

        if response.status_code == 204:
            return Response(json.dumps({"success": "false"}), status=204, mimetype="application/json")
        elif response.status_code == 200:
            return Response(json.dumps({"success": "true"}), status=200, mimetype="application/json")

    elif request.method == "DELETE":
        data = request.get_json()
        if data:
            return Response(json.dumps({"success": "false"}), status=400, mimetype="application/json")

        data = {}
        data['table'] = 'rides'
        data['type'] = 'delete'
        data['rideId'] = rideId

        response = requests.post(
            "http://localhost:8000/api/v1/db/write", json=data)

        if response.status_code == 204:
            return Response(json.dumps({"success": "false"}), status=204, mimetype="application/json")

        elif response.status_code == 200:
            return Response(json.dumps({"success": 'true'}), status=200, mimetype="application/json")


@app.route("/api/v1/db/clear", methods=["POST"])
def clear():
    global count
    count += 1
    data = request.get_json()

    if data:
        return Response(json.dumps({"success": "false"}), status=400, mimetype="application/json")

    data = {}
    data['table'] = 'clear'
    response = requests.post(
        "http://localhost:8000/api/v1/db/write", json=data)

    if response.status_code == 200:
        return Response(json.dumps({"success": 'true'}), status=200, mimetype="application/json")


@app.route("/api/v1/_count", methods=["GET", "DELETE"])
def httpcount():

    global count
    if request.method == "GET":
        return Response(json.dumps([count]), status=200, mimetype="application/json")

    elif request.method == "DELETE":
        count = 0
        return Response(json.dumps({"success": 'true'}), status=200, mimetype="application/json")


@app.route("/api/v1/rides/count", methods=["GET","PUT","POST","DELETE","HEAD"])
def ridec():
    if request.method != "GET":
        return Response(json.dumps({"success":"false"}), status=405, mimetype="application/json")

    temp = ridesCol.find()
    ridecount = 0
    for x in temp:
        ridecount += 1
    return Response(json.dumps([ridecount]), status=200, mimetype="application/json")


@app.route("/api/v1/db/write", methods=["POST"])
def write():

    data = request.get_json()
    # print(data)
    if data['table'] == 'users':
        if data['type'] == 'insert':
            # data to be inserted
            temp = {"username": data["username"], 'password': data['password']}
            a = usersCol.insert(temp)
            # print("hey")
            return Response(json.dumps({"success": 'true'}), status=201, mimetype="application/json")

        elif data['type'] == 'delete':
            temp = {"username": data['username']}
            usersCol.delete_one(temp)
            return Response(json.dumps({"success": 'true'}), status=200, mimetype="application/json")

    elif data['table'] == 'rides':
        if data['type'] == 'insert':
            n = generate_id()
            temp = {"rideId": n, "created_by": data["created_by"], "users": [], "timestamp": data["timestamp"],
                    "source": data["source"], "destination": data["destination"]}

            a = ridesCol.insert(temp)
            return Response(json.dumps({"success": "true"}), status=201, mimetype="application/json")

        elif data['type'] == 'join':
            # print(data)
            queryUser = {"username": data['username']}
            queryRide = {"rideId": int(data['rideId'])}

            docU = usersCol.find(queryUser)
            docR = ridesCol.find(queryRide)
            lU = []
            lR = []

            for x in docU:
                lU.append(x)
            for x in docR:
                lR.append(x)
            # if lR['created_by']==data['username']:
            #     return {"success":"false"},400
            # print(queryUser)
            # print(queryRide)
            # print("yee")

            if not lU or not lR:
                return Response(json.dumps({"success": "false"}), status=204, mimetype="application/json")

            # print("hey")
            lR[0]['users'].append(data['username'])
            query = {"rideId": int(data['rideId'])}
            new = {"$set": {"users": lR[0]['users']}}
            # print(query)
            ridesCol.update_one(query, new)
            # print("heyy")
            return Response(json.dumps({"success": "true"}), status=200, mimetype="application/json")

        elif data['type'] == 'delete':
            query = {"rideId": int(data['rideId'])}

            doc = ridesCol.find(query)

            l = []
            for x in doc:
                l.append(x)
            # print(l)

            if not l:
                return Response(json.dumps({"success": "false"}), status=204, mimetype="application/json")

            ridesCol.delete_one(query)

            return Response(json.dumps({"success": "true"}), status=200, mimetype="application/json")

    elif data['table'] == 'clear':

        myclient.drop_database("Rides")

        return Response(json.dumps({"success": "true"}), status=200, mimetype="application/json")


@app.route("/api/v1/db/read", methods=["POST"])
def read():

    data = request.get_data()
    data = json.loads(data)

    if data['table'] == 'rides':
        if data['type'] == 'read':

            temp = []
            query = {"source": data['source'],
                     "destination": data["destination"]}
            doc = ridesCol.find(query)

            for x in doc:
                if not validate_timestamp(x['timestamp']):
                    return Response(json.dumps({"success": "false"}), status=400, mimetype="application/json")

                x.pop("_id")
                temp.append(x)
            # print("\n\n\n",temp,"\n\n\n")
            return json.dumps(temp), 200

        elif data['type'] == 'rideId':

            query = {"rideId": int(data["rideId"])}
            doc = ridesCol.find(query)
            l = []
            for x in doc:
                l.append(x)

            if not l:
                return Response(json.dumps({"success": "empty body"}), status=204, mimetype="application/json")

            temp = l[0]
            temp.pop('_id')
            return Response(json.dumps(temp), status=200, mimetype="application/json")

    elif data['table'] == 'users':
        if data['type'] == 'list':

            temp = usersCol.find()
            l = []
            data = []

            for x in temp:
                l.append(x)

            if not l:
                return Response(json.dumps({"success": "empty body"}), status=204, mimetype="application/json")
            for i in range(len(l)):
                x = l[i]
                x.pop("_id")
                data.append(x)

            return Response(json.dumps(data), status=200, mimetype="application/json")


if __name__ == "__main__":
    app.debug = True
    app.run()
