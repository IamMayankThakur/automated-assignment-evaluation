from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask import Flask,jsonify,request,Response
import requests
from sqlalchemy import func
from sqlalchemy.sql import select,text
from sqlalchemy import create_engine
from numpy import genfromtxt
import datetime
import re

app = Flask(__name__)
app.config['SQLALCHEMY_TRACK_MODIFICATIONS']=False
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///rides.sqlite'
db = SQLAlchemy(app)

 
#Rides table        
class Rides(db.Model):
	rideId = db.Column(db.Integer, primary_key=True,nullable=False)
	created_by = db.Column(db.String(),nullable=False)
	users=db.Column(db.String())
	timestamp = db.Column(db.String(19), nullable=False)
	source = db.Column(db.String(),nullable=False)
	destination = db.Column(db.String(),nullable=False)
	
	def __init__(self,created_by,users,timestamp,source,destination):
	    self.created_by=created_by
	    self.users=users
	    self.timestamp=timestamp
	    self.source=source
	    self.destination=destination
	    
#HTTP
class http(db.Model):
	col = db.Column(db.Integer, primary_key=True, nullable=False)	
	count = db.Column(db.String)
	
	def __init__(self,count):
	    self.count=count	

#AreaNum table
class area(db.Model):
	num = db.Column(db.String(),primary_key=True,nullable=False)
	area = db.Column(db.String())
	
	def __init__(self,num,area):
	    self.num=num
	    self.area=area
	    
db.create_all()

def Load_Data(file_name):
    data = genfromtxt(file_name, delimiter=',', skip_header=1,converters={1: lambda s: str(s,'utf-8')})
    return data.tolist()
    
file_name = "AreaNameEnum.csv" 
data = Load_Data(file_name) 
try:
	for i in data:
	    record = area(i[0],i[1])
	    db.session.add(record)
	db.session.commit()
except:
    db.session.rollback()

@app.before_request
def before():
    path=request.path
    if path.startswith('/api/v1/rides'):
        c={"flag":"add","insert":{"count":"1"},"table":"http"}
        requests.post("http://rides:80/api/v1/db/write",json=c)

#add ride
@app.route("/api/v1/rides",methods=["POST"])
def add_ride():
	try:
		cr=request.get_json()["created_by"]
		ti=request.get_json()["timestamp"]
		s=request.get_json()["source"]
		d=request.get_json()["destination"]		        			
	except:
		return {},500 
	try:
		    d1=datetime.datetime.strptime(ti,'%d-%m-%Y:%S-%M-%H')
	except:
		return Response("Timestamp should be in the format dd-mm-yyyy:ss-mm-hh", status=400,mimetype='application/text')
	if(s==d):
		return Response("Source and destination cannot be the same",status=400,mimetype='application/text')
	che={"Origin":"http://34.231.128.76"}
	re=requests.get("http://load-balancer-alb-1238542300.us-east-1.elb.amazonaws.com/api/v1/users",json={"table":"User","columns":["username"]},headers=che)
	fla=0
	for i in re.json():
		if(cr==i):
			fla=1
	if(fla==0):
		return {},405
	else:
		j={"flag":"add","insert":{"created_by":cr,"timestamp":ti,"source":s,"destination":d},"table":"Rides"}
		requests.post("http://rides:80/api/v1/db/write",json=j)
		return {},201

#remove ride	
@app.route("/api/v1/rides/<rideId>",methods=["DELETE"])
def remove_ride(rideId):
	re=requests.post("http://rides:80/api/v1/db/read",json={"table":"Rides","columns":["rideId"],"where":"rideId="+"'"+rideId+"'"})
	if(not re.json()):
		return "Ride Id does not exist",400
	else:
		j={"flag":"delete","rideId":rideId,"table":"Rides"}
		r=requests.post("http://rides:80/api/v1/db/write",json=j)
		return {},200
		
#list details of ride
@app.route("/api/v1/rides/<rideId>")
def ride_details(rideId):
	re=requests.post("http://rides:80/api/v1/db/read",json={"table":"Rides","columns":["rideId"],"where":"rideId="+"'"+rideId+"'"})
	if(not re.json()):
		return {},405
	else:
		a=requests.post("http://rides:80/api/v1/db/read",json={"table":"Rides","columns":["rideId","created_by","users","timestamp","source","destination"],"where":"rideId="+"'"+rideId+"'"})
		if(not a.json()):
			return {},204
		return jsonify(a.json()),200

#{"username":"abcde","password":"1111111111111111111111111111111111111111"}
#list upcoming rides between source and destination
@app.route('/api/v1/rides')
def upcoming():
	source=request.args.get('source')
	destination=request.args.get('destination')
	if((source.isdigit()==False) or (destination.isdigit()==False)):
		return Response("Source and destination must be an integer",status=400,mimetype='application/text')
	ar=db.session.query(area).count()
	if(int(source)<1 or int(source)>ar or int(destination)<0 or int(destination)>ar):
		return {},405
	re=requests.post("http://rides:80/api/v1/db/read",json={"table":"Rides","columns":["rideId","created_by","timestamp"],"where":"source="+"'"+str(source)+"' "+"and destination="+"'"+str(destination)+"'"})
	t1 = datetime.datetime.today().strftime("%d-%m-%Y:%S-%M-%H")
	t4 = datetime.datetime.strptime(t1,'%d-%m-%Y:%S-%M-%H')
	d,a={},[]
	for i in re.json():
		t2 = i["timestamp"]
		t3 = datetime.datetime.strptime(t2,'%d-%m-%Y:%S-%M-%H')		
		if(t3>t4):
			for col,val in i.items():
				d={**d,**{col:val}}
			a.append(d)
	if(len(a)):
		b=[]
		for j in a:
			cr=j["created_by"]
			r=j["rideId"]
			t=j["timestamp"]
			b.append({"rideId":r,"username":cr,"timestamp":t})
		return jsonify(b),200
	else:
		return {},204
	

#join a ride
@app.route('/api/v1/rides/<rideId>',methods=["POST"])
def join_ride(rideId):
	un=request.get_json()["username"]
	che={"Origin":"http://34.231.128.76"}
	re=requests.get("http://load-balancer-alb-1238542300.us-east-1.elb.amazonaws.com/api/v1/users",json={"table":"User","columns":["username"]},headers=che)
	fla=0
	for i in re.json():
		if(un==i):
			fla=1
	if(fla==0):
		return {},405
	else:
		j={"flag":"update","columns":{"username":un,"rideId":rideId},"table":"Rides"}
		a=requests.post("http://rides:80/api/v1/db/write",json=j)
		if(a.text=='405'):
			return {},405
	return {},200
	
#total number of rides
@app.route("/api/v1/rides/count")
def total_rides():
	re=requests.post("http://rides:80/api/v1/db/read",json={"table":"Rides","columns":["rideId"]})
	t=re.json()
	l=[]
	l.append(len(t))
	return jsonify(l),200

#total http
@app.route("/api/v1/_count")
def total_http():
	re=requests.post("http://rides:80/api/v1/db/read",json={"table":"http","columns":["col"]})
	t=re.json()
	l=[]
	l.append(len(t))
	return jsonify(l),200
	
#reset http
@app.route("/api/v1/_count",methods=["DELETE"])
def reset():
	http.query.delete()
	db.session.commit()
	return {},200

#database clear
@app.route("/api/v1/db/clear",methods=["POST"])
def clear():
	Rides.query.delete()
	db.session.commit()
	return {},200

#database read
@app.route("/api/v1/db/read",methods=["POST"])
def read():
	k=request.get_json()["table"]
	j=request.get_json()["columns"]
	if(k=="Rides"):
		new=[]
		for i in j:
			new.append(text(i))
		try:
			t=request.get_json()["where"]
			stmt = select(new).where(text(t)).select_from(text("Rides"))
			return (execute(stmt))
		except:
			stmt = select(new).select_from(text("Rides"))
			return (execute(stmt))
	elif(k=="http"):
		new=[]
		for i in j:
			new.append(text(i))
		stmt = select(new).select_from(text("http"))
		return (execute(stmt))
		
def execute(stmt):
	rs=db.engine.execute(stmt)
	d,a={},[]
	for row in rs:
		for col,val in row.items():
			d={**d,**{col:val}}
		a.append(d)
	return jsonify(a)	

#database write
@app.route("/api/v1/db/write",methods=["POST"])
def write():
	flag=request.get_json()["flag"]
	k=request.get_json()["table"]
	if(flag=="add"):
		j=request.get_json()["insert"]
		if(k=="Rides"):
			ri= Rides(j["created_by"],j["created_by"],j["timestamp"],j["source"],j["destination"])
			db.session.add(ri)
		if(k=="http"):
			ht= http(j["count"])
			db.session.add(ht)
	elif(flag=="delete"):
		if(k=="Rides"):
			rid=request.get_json()["rideId"]
			Rides.query.filter_by(rideId=rid).delete()
			db.session.commit()     			
	elif(flag=="update"):
		j=request.get_json()["columns"]
		un=j["username"]
		ri=j["rideId"]
		stmt = select([text("users")]).where(text("rideId="+"'"+ri+"'")).select_from(text("Rides"))
		rs=db.engine.execute(stmt)
		for i in rs:
			b=i[0]
		li=b.split(',')
		for h in li:
			if(h==un):
				return ('405')
		a=Rides.query.filter_by(rideId=ri).update(dict(users=b+','+un))		
	db.session.commit()
	return {}

if __name__=="__main__":
	app.debug=True
	app.run(host='0.0.0.0',port=80)
