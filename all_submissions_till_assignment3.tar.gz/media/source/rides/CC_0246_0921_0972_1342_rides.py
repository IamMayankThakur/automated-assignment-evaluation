# on 8000

from flask import Flask, render_template, jsonify, request, abort
import flask
import sqlite3
import string
import json
import requests
import ast
import datetime
import os

app = Flask(__name__)

os.system("rm a2.db")
mydb = sqlite3.connect('a2.db')
mycursor = mydb.cursor()
mydb.execute(
    "CREATE TABLE rides (ride_ID INTEGER,created_by VARCHAR(255),uname VARCHAR(255),timestamp VARCHAR(255),source INT,dest INT,PRIMARY KEY(ride_ID,uname))")
mydb.execute("CREATE TABLE http_count (count INTEGER)")
#mydb.execute("INSERT INTO http_count VALUES (0)")
mydb.commit()
mydb.close()
# df = pd.read_csv('area.csv')
ride_no = 1


h= {'Origin':"54.224.149.146"}
count1=0
# f = open("count.txt","w")
# f.write("0")
# f.close()

@app.before_request
def count_inc():
    url = request.path
    global count1
#     db=["/api/v1/db/read","/api/v1/db/write","/api/v1/_count","/api/v1/rides/check"]
    # u=["/api/v1/users","/api/v1/users/<username>","/api/v1/db/clear"]
#     flag=0
#     for ur in app.url_map.iter_rules():
#         if(url not in db and url==ur):
#             flag=1
#     print(flag)    

    if(url.startswith('/api/v1/rides')):
        mydb = sqlite3.connect('a2.db')
        count1 = count1+1
        mydb.execute("INSERT INTO http_count VALUES ("+str(count1)+")")
        mydb.commit()
        mydb.close()
        
#         f = open("count.txt","r")
#         count = int(f.read())
#         f.close()
#         f = open("count.txt","w")
#         count+= 1
#         f.write(str(count))
#         f.close()
        #count1+=1

# @app.after_request
# def count_dec(response):
#     url = request.path
#     db=["/api/v1/db/read","/api/v1/db/write","/api/v1/_count","/api/v1/rides/check"]
#     stats = [200,201,405]

#     status = response.status_code
#     if(status not in stats and url not in db):
#         f = open("count.txt","r")
#         count = int(f.read())
#         f.close()
#         f = open("count.txt","w")
#         count-= 1
#         f.write(str(count))
#         f.close()
#     return response

# ----------------------------------------------------3--------------------------------------------
@app.route("/api/v1/rides", methods=["POST"])
def addRide():
    # print("API#3")
    # global count
    # count += 1

    # f = open("count.txt","r")
    # count = int(f.read())
    # f.close()
    # f = open("count.txt","w")
    # count+= 1
    # f.write(str(count))
    # f.close()

    global ride_no
    uname = request.get_json()["created_by"]
    time = request.get_json()["timestamp"]
    source = request.get_json()["source"]
    dest = request.get_json()["destination"]
    if source == dest:
        return abort(405)
    if int(source) in range(1, 199) and int(dest) in range(1, 199):
        users = []

        # obj = {
        #     "columns": "uname",
        #     "where": "uname='"+uname+"'",
        #     "table": "users"
        # }
        # obj = json.dumps(obj)  # stringified json
        # obj = json.loads(obj)  # content-type:application/json
        # # send request to db api
        # x = requests.post("http://users:80/api/v1/db/read", json=obj)
        # print(x.text)
        # Parse the text response (mycursor.fetchall() list) from read api to list
        # users = ast.literal_eval(x.text)
        # users = []
        # query = "SELECT uname FROM users WHERE uname ='"+uname+"'"
        # mycursor.execute(query)
        # users = mycursor.fetchall()
        x = requests.get("http://as3-1035255316.us-east-1.elb.amazonaws.com/api/v1/users",headers=h)
        users = ast.literal_eval(x.text)

        if(uname not in users):
            return abort(400)
        else:
            obj = {
                "operation": "insert",
                "column": "(ride_ID,created_by,uname,timestamp,source,dest)",
                "insert": "("+str(ride_no)+",'"+uname+"','"+uname+"','"+time+"',"+source+","+dest+")",
                "table": "rides"
            }
            ride_no += 1
            obj = json.dumps(obj)  # stringified json
            obj = json.loads(obj)  # content-type:application/json
            # send request to db api
            x = requests.post(
                "http://0.0.0.0:80/api/v1/db/write", json=obj)
            return (jsonify({}), 201)
    else:
        return abort(400)


# -------------------------------------------4-------------------------------------------------------
@app.route("/api/v1/rides", methods=["GET"])
def upcRides():
    # f = open("count.txt","r")
    # count = int(f.read())
    # f.close()
    # f = open("count.txt","w")
    # count+= 1
    # f.write(str(count))
    # f.close()

    #print("API#4")
    source = flask.request.args.get('source')
    destination = flask.request.args.get('destination')
    #print(source, destination, type(destination))
    if(int(source) in range(1, 199) and int(destination) in range(1, 199)):
        obj = {
            "columns": "ride_ID,created_by,timestamp,source,dest",
            "where": "source="+source+",dest="+destination,
            "table": "rides",
            "distinct": 1
        }
        obj = json.dumps(obj)  # stringified json
        obj = json.loads(obj)  # content-type:application/json
        # send request to db api
        x = requests.post("http://0.0.0.0:80/api/v1/db/read", json=obj)
        #print(x.text)
        # return(x.text)
        # print(x.text)
        rideDetails = ast.literal_eval(x.text)
        if(len(rideDetails) == 0):
            return ("[{}]", 204)
        res = []
        for ride in rideDetails:
            dt = datetime.datetime.strptime(ride[2], "%d-%m-%Y:%S-%M-%H")
            if(dt < datetime.datetime.now()):
                continue
            # obj = {
            #     "columns": "uname",
            #     "where": "uname= '"+ride[1]+"'",
            #     "table": "users"
            # }
            # # query = 'SELECT uname FROM users WHERE uname="'+ride[1]+'"'
            # obj = json.dumps(obj)  # stringified json
            # obj = json.loads(obj)
#             x = requests.get("http://as3-1035255316.us-east-1.elb.amazonaws.com/api/v1/users",headers=h)
#             users = ast.literal_eval(x.text)
#             if(ride[1] not in users):
#                 return abort(400)
            r = {
                "rideId": ride[0],
                "username": ride[1],
                "timestamp": ride[2]
            }
            # r = json.dumps(r)
            # r = json.loads(r)
            res.append(r)
        return (jsonify(res), 200)
    return abort(400)

# ---------------------------------------------------5---------------------------------------------------
# Get ride details given the rideID
@app.route("/api/v1/rides/<rideId>", methods=["GET"])
def rideDetails(rideId):
    # f = open("count.txt","r")
    # count = int(f.read())
    # f.close()
    # f = open("count.txt","w")
    # count+= 1
    # f.write(str(count))
    # f.close()

    obj = {
        "columns": "ride_ID,created_by,uname,timestamp,source,dest",
        "where": "ride_ID = '"+rideId+"'",
        "table": "rides"
    }
    obj = json.dumps(obj)  # stringified json
    obj = json.loads(obj)
    x = requests.post("http://0.0.0.0:80/api/v1/db/read", json=obj)
    rideDetails = ast.literal_eval(x.text)
    # query = "SELECT * FROM rides WHERE ride_ID='"+rideId+"'"
    # mycursor.execute(query)
    # rideDetails = mycursor.fetchall()
    if(len(rideDetails) == 0):
        return abort(400)
    res = []
    for ride in rideDetails:
        res.append(ride[2])
    ride = {
        "ride_Id": rideDetails[0][0],
        "created_by": rideDetails[0][1],
        "users": res,
        "timestamp": rideDetails[0][3],
        "source": rideDetails[0][4],
        "destination": rideDetails[0][5]
    }
    ride = json.dumps(ride)
    ride = json.loads(ride)
    return (str(ride), 200)

# ---------------------------------------------------6---------------------------------------------------
# Join rides
@app.route("/api/v1/rides/<rideId>", methods=["POST"])
def joinRide(rideId):
    # f = open("count.txt","r")
    # count = int(f.read())
    # f.close()
    # f = open("count.txt","w")
    # count+= 1
    # f.write(str(count))
    # f.close()

    uname = request.get_json()["username"]
    # obj = {
    #     "columns": "uname",
    #     "where": "uname= '"+uname+"'",
    #     "table": "users"
    # }
    # # query = 'SELECT uname FROM users WHERE uname="'+ride[1]+'"'
    # obj = json.dumps(obj)  # stringified json
    # obj = json.loads(obj)
    x = requests.get("http://as3-1035255316.us-east-1.elb.amazonaws.com/api/v1/users",headers=h)
    users = ast.literal_eval(x.text)

    # query = "SELECT uname FROM users WHERE uname ='"+uname+"'"
    # mycursor.execute(query)
    # users = mycursor.fetchall()
    if(uname not in users):
        return abort(400)

    obj = {
        "columns": "uname,timestamp,source,dest",
        "where": "ride_ID= "+rideId,
        "table": "rides",
        "distinct": 1
    }
    obj = json.dumps(obj)  # stringified json
    obj = json.loads(obj)
    x = requests.post("http://0.0.0.0:80/api/v1/db/read", json=obj)
    users1 = ast.literal_eval(x.text)
    # q1 = "SELECT * FROM rides WHERE ride_ID ='"+rideId+"'"
    # mycursor.execute(q1)
    # users1 = mycursor.fetchall()
    if(len(users1) == 0):
        return abort(405)
    users1 = users1[0]
    # print("-------------\n", users1, len(users1))
    obj = {
        "operation": "insert",
        "column": "(ride_ID,created_by,uname,timestamp,source,dest)",
        "insert": "("+str(rideId)+",'"+users1[0]+"','"+uname+"','"+str(users1[1])+"',"+str(users1[2])+","+str(users1[3])+")",
        "table": "rides"
    }
    obj = json.dumps(obj)  # stringified json
    obj = json.loads(obj)  # content-type:application/json
    # send request to db api
    x = requests.post("http://0.0.0.0:80/api/v1/db/write", json=obj)
    # sql = "INSERT INTO rides(ride_ID,uname,timestamp,source,dest) VALUES ('" + str(
    #     users1[0])+"','" + uname+"','"+users1[2]+"','"+str(users1[3])+"','"+str(users1[4])+"')"
    # mycursor.execute(sql)
    return ("{}", 200)

# ----------------------------------------------------7----------------------------------------------
# Delete by rideId
@app.route("/api/v1/rides/<rideId>", methods=["DELETE"])
def delRide(rideId):
    # f = open("count.txt","r")
    # count = int(f.read())
    # f.close()
    # f = open("count.txt","w")
    # count+= 1
    # f.write(str(count))
    # f.close()

    obj = {
        "columns": "uname,timestamp,source,dest",
        "where": "ride_ID= "+str(rideId),
        "table": "rides"
    }
    obj = json.dumps(obj)  # stringified json
    obj = json.loads(obj)
    x = requests.post("http://0.0.0.0:80/api/v1/db/read", json=obj)
    users = ast.literal_eval(x.text)
    # query = 'SELECT rideId FROM rides WHERE ride_ID ="'+rideId+'"'
    # # val = (username)
    # mycursor.execute(query)
    # users = mycursor.fetchall()
    #print(users)
    if(len(users) == 0):
        return abort(405)
    else:
        obj = {
            "operation": "delete",
            "column": "ride_ID",
            "insert": rideId,
            "table": "rides"
        }
        obj = json.dumps(obj)  # stringified json
        obj = json.loads(obj)  # content-type:application/json
        # send request to db api
        x = requests.post("http://0.0.0.0:80/api/v1/db/write", json=obj)
        # query = 'DELETE FROM rides WHERE ride_ID="'+rideId+'"'
        # # val = (username)
        # mycursor.execute(query)
        # mydb.commit()
        return ("{}", 200)

# -------------------------------------------------TOTAL NUMBER OF RIDES------------------------------------
@app.route("/api/v1/rides/count", methods=["GET"])
def totalRides():
    # f = open("count.txt","r")
    # count = int(f.read())
    # f.close()
    # f = open("count.txt","w")
    # count+= 1
    # f.write(str(count))
    # f.close()

    obj = {
        "columns": "COUNT(ride_ID)",
        "where": "",
        "table": "rides"
    }
    obj = json.dumps(obj)  # stringified json
    obj = json.loads(obj)
    x = requests.post("http://0.0.0.0:80/api/v1/db/read", json=obj)
    users = ast.literal_eval(x.text)
    return(jsonify(users[0]),200)


# -------------------------------------------------4 Write to db-------------------------------------------------
# Write into a DB
@app.route("/api/v1/db/write", methods=["POST"])
def insert():
    mydb = sqlite3.connect('a2.db')
    mycursor = mydb.cursor()
    op = request.get_json()["operation"]
    column = request.get_json()["column"]
    insert = request.get_json()["insert"]
    table = request.get_json()["table"]
    query = ''
    if(op == "insert"):
        query += 'INSERT INTO ' + table+' '+column+' VALUES ('
        insert = insert[1:len(insert)-1]
        insert = insert.split(",")
        # insert = list(map(lambda x:str(x),insert))
        for i in range(len(insert)):
            if(i != 0):
                query += ","
            query += insert[i]
        query += ")"

    else:
        query += 'DELETE FROM '+table+' WHERE ('
        column = column.split(",")
        insert = insert.split(",")
        if(len(column) != len(insert)):
            abort(400)
        for i in range(len(column)):
            if(i != 0):
                query += 'AND'
            query += column[i]+'='+insert[i]
        query += ")"
    #print(query)
    query = query+";"
    mydb.execute(query)
    mydb.commit()
    mydb.close()
    return ("{}", 200)

# -------------------------------------------------5 Read fron DB-------------------------------------------------
# Read into a DB
@app.route("/api/v1/db/read", methods=["POST"])
def read():
    mydb = sqlite3.connect('a2.db')
    mycursor = mydb.cursor()
    #print("------API#9------")
    query = 'SELECT '
    columns = request.get_json()["columns"]
    where = request.get_json()["where"]
    table = request.get_json()["table"]
    try:
        distinct = request.get_json()["distinct"]
        query += 'DISTINCT '
    except:
        distinct = '0'
    '''
    Made the read a little more flexible with respect to where conditions and select * condition
    '''
    if len(columns) != 1:
        for col in columns.split(','):
            query += col+','
        query = query[0:-1]
    else:
        query = 'SELECT '+columns
    if where != '':
        query = query+' FROM '+table+' WHERE ('
        where = where.split(",")
        for i in range(len(where)):
            if(i != 0):
                query += ' AND '
            query += where[i]
        query += ")"
    else:
        query = query+' FROM '+table
    #print(query)
    query = query+";"
    s = mydb.execute(query)
    # s = mycursor.fetchall()
    res = []
    for row in s:
        res.append(row)
    # Return a string of mycursor.fetchall() that the calling api can parse into a list easily
    mydb.close()
    return (jsonify(res), 200)

# -------------------------------------------------6 CLEAR DB----------------------------------------
@app.route("/api/v1/db/clear", methods=["POST"])
def clear():
    # f = open("count.txt","r")
    # count = int(f.read())
    # f.close()
    # f = open("count.txt","w")
    # count+= 1
    # f.write(str(count))
    # f.close()

    mydb = sqlite3.connect('a2.db')
    mycursor = mydb.cursor()
    query = 'SELECT name FROM sqlite_master WHERE type="table"'
    mycursor.execute(query)
    s = mycursor.fetchall()
    # s = mycursor.fetchall()
    # print("(((((((((",s)

    for table in s:
        # print(table[0])
        query = "DELETE FROM "+table[0]
        mydb.execute(query)
        mydb.commit()

    mydb.close()
    return(jsonify({}), 200)

# ---------------------------------------7 COUNT REQUESTS------------------------------------------
@app.route("/api/v1/_count", methods=["GET"])
def totalRequests():
    global count1
    mydb = sqlite3.connect('a2.db')
    s = mydb.execute("SELECT COUNT(*) FROM http_count");
    res = []
    for row in s:
        res.append(row)
    res = res[0]
    mydb.close()
    # x = requests.get("http://users:80/api/v1/users/_count")
    # c1 = ast.literal_eval(x.text)
    # c1=int(c1)

#     f = open("count.txt","r")
#     count = int(f.read())
#     f.close()
    # count+=c1
    return(jsonify(res),200)
#    return abort(405)


# --------------------------------------8 RESET REQUESTS -------------------------------------------
@app.route("/api/v1/_count", methods=["DELETE"])
def resetRequests():
    global count1
    mydb = sqlite3.connect('a2.db')
    mydb.execute("DELETE FROM http_count")
    count1=0
    mydb.commit()
    mydb.close()
    # x = requests.delete("http://users:80/api/v1/users/_count")
    # c1 = x.status_code
    # if(c1!=200):
    #     abort(405)

#     f = open("count.txt","w")
#     #count = int(f.read())
#     count = 0
#     f.write(str(count))
#     f.close()
#     count1=0
    return(jsonify({}),200)
    
#    return abort(405)


if __name__ == '__main__':
    app.debug = True
    app.run(host="0.0.0.0",port=80)
