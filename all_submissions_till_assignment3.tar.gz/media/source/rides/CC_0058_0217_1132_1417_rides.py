from flask import * 
from flask import request
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import *
from sqlalchemy import exc
from datetime import datetime
import requests
from numpy import genfromtxt

app = Flask(__name__)
app.config['JSON_SORT_KEYS'] = False

app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///rides.db'
 
db = SQLAlchemy(app)


class Area(db.Model):
	__tablename__ = 'Area'
	areano = db.Column(db.Integer, primary_key = True)
	areaname = db.Column(db.String(50))

class Rides(db.Model):
	__tablename__ = 'Rides'
	rideId = db.Column(db.Integer, primary_key = True)
	created_by = db.Column(db.String(50))
	timestamp = db.Column(db.DateTime)
	source = db.Column(db.Integer, db.ForeignKey('Area.areano'))
	dest = db.Column(db.Integer, db.ForeignKey('Area.areano'))

class UserRides(db.Model):
	__tablename__ = 'UserRides'
	rideId = db.Column(db.Integer, db.ForeignKey('Rides.rideId'), primary_key = True)
	username = db.Column(db.String(50), primary_key = True)

class ReqTable(db.Model):
	__tablename__ = 'ReqTable'
	rowid = db.Column(db.Integer, primary_key = True, autoincrement=True)
	content = db.Column(db.String(50))

db.create_all()

def Load_Data(file_name):
	data = genfromtxt(file_name,delimiter=',',converters={1: lambda s: str(s,'utf-8')})
	return data.tolist()
file_name = "AreaNameEnum.csv"
data = Load_Data(file_name)
try:
	for i in data:
		record = Area(areano=i[0],areaname=i[1])
		db.session.add(record)
	db.session.commit()
except:
	db.session.rollback()

def checkloc(source,dest):
	query1 = "SELECT COUNT(*) from Area where areano = '"+source+"'"
	mydata1 = {"query":query1}
	r1 = requests.post("http://127.0.0.1:5000/api/v1/db/read",json=mydata1)
	res1 = json.loads(r1.text)
	count1 = res1[0]["COUNT(*)"]
	query2 = "SELECT COUNT(*) from Area where areano = '"+dest+"'"
	mydata2 = {"query":query2}
	r2 = requests.post("http://127.0.0.1:5000/api/v1/db/read",json=mydata2)
	res2 = json.loads(r2.text)
	count2 = res2[0]["COUNT(*)"]
	if (count1 == 0 or count2 == 0):
		return 0
	else:
		return 1

def getusers():
	read_req=requests.get(url='http://my-load-balancer-367738757.us-east-1.elb.amazonaws.com/api/v1/users')
	res = json.loads(read_req.text)
	return res

def increment():
	mydata = {"table":"ReqTable","insert": ["test"]}
	r = requests.post("http://127.0.0.1:5000/api/v1/db/write",json=mydata)


@app.errorhandler(405)
def method_not_allowed(e):
        increment()
        return jsonify(error=str(e)),405
                       
@app.route("/api/v1/_count",methods=["GET"])
def http_req():
	query= "SELECT COUNT(*) from ReqTable"
	mydata = {"query":query}
	r = requests.post("http://127.0.0.1:5000/api/v1/db/read",json=mydata)
	res = json.loads(r.text)
	count = res[0]["COUNT(*)"]
	l = [count]
	return jsonify(l),200

@app.route("/api/v1/_count",methods=["DELETE"])
def http_req_del():
	query= "DELETE from ReqTable"
	mydata = {"query":query}
	r = requests.post("http://127.0.0.1:5000/api/v1/db/read",json=mydata)
	res = json.loads(r.text)
	return "200",200

### API 3 ###
@app.route("/api/v1/rides",methods=["POST"])
def create_ride():
	increment()
	create = request.get_json()["created_by"]
	time = request.get_json()["timestamp"]
	src = request.get_json()["source"]
	dst = request.get_json()["destination"]
	usrs = getusers()
	if create not in usrs:
		return Response("Given username does not exist",status = 400,mimetype='application/text')
	else:
		if(checkloc(src,dst)):
			mydata = {"table":"Rides","insert":[create,time,src,dst]}
			r = requests.post("http://127.0.0.1:5000/api/v1/db/write",json=mydata)
			res = r.text
			query = "SELECT rideId FROM Rides where created_by = '"+create+"'"
			qdata = {"query":query}
			q = requests.post("http://127.0.0.1:5000/api/v1/db/read",json=qdata)
			qt = q.text
			json_data = json.loads(qt)
			for item in json_data:
				ride = item["rideId"]
			mydata1 = {"table":"UserRides","insert":[ride,create]}
			r1 = requests.post("http://127.0.0.1:5000/api/v1/db/write",json=mydata1)
			if r1.text == "201":
				return Response("Created ride successfully",status = 201,mimetype='application/text')
			else:
				return Response("Internal server error",status = 500,mimetype='application/text')
		else:
			return Response("Wrong source or destination code",status = 400,mimetype='application/text')

	

### API 4 ###
@app.route("/api/v1/rides",methods=["GET"])
def up_rides():
	increment()
	d1 = datetime.now()
	s_d1 = str(d1)
	source = request.args.get("source")
	destination = request.args.get("destination")
	if(checkloc(source,destination)):
		query = "SELECT rideId,created_by,timestamp FROM Rides WHERE timestamp >= '"+s_d1+"' and source = '"+source+"' and dest = '"+destination+"'"
		mydata = {"query":query}
		r = requests.post("http://127.0.0.1:5000/api/v1/db/read",json=mydata)
		ch = r.text.replace("created_by","username")
		res = json.loads(ch)
		if len(res)==0:
			return Response("No rides found",status = 204,mimetype='application/text')
		else:
			for i in res:
				tm = i["timestamp"]
				newt = datetime.strptime(tm,"%Y-%m-%d %H:%M:%S.%f")
				convnewt = newt.strftime("%d-%m-%Y:%S-%M-%H")
				i["timestamp"] = convnewt
			return jsonify(res),200
	else:
		return Response("Wrong source or destination code",status = 400,mimetype='application/text')

### API 5 ###
@app.route("/api/v1/rides/<rideId>",methods=["GET"])
def ride_details(rideId):
	increment()
	query = "SELECT created_by,source,dest,timestamp from Rides where rideId = '"+rideId+"'"
	mydata = {"query":query}
	r = requests.post("http://127.0.0.1:5000/api/v1/db/read",json=mydata)
	res = json.loads(r.text)
	if len(res)==0:
		return Response("Invalid Ride ID",status = 400,mimetype='application/text')
	else:
		query2 = "SELECT username from UserRides where rideId = '"+rideId+"'"
		mydata2 = {"query":query2}
		r2 = requests.post("http://127.0.0.1:5000/api/v1/db/read",json=mydata2)
		res2 = json.loads(r2.text)
		usrs = []
		for i in res2:
			name = i["username"]
			usrs.append(name)
		tm = res[0]["timestamp"]
		newt = datetime.strptime(tm,"%Y-%m-%d %H:%M:%S.%f")
		convnewt = newt.strftime("%d-%m-%Y:%S-%M-%H")
		returnjson = {"rideId":rideId,"created_by":res[0]["created_by"],"users":usrs,"timestamp":convnewt,"source":res[0]["source"],"destination":res[0]["dest"]}
		return jsonify(returnjson),200

### API 6 ###
@app.route("/api/v1/rides/<rideId>",methods=["POST"])
def addusrride(rideId):
	increment()
	usn = request.get_json()["username"]
	query = "SELECT COUNT(*) from Rides where rideId = '"+rideId+"'"
	mydata = {"query":query}
	r = requests.post("http://127.0.0.1:5000/api/v1/db/read",json=mydata)
	res = json.loads(r.text)
	count = res[0]["COUNT(*)"]
	if count==0:
		return Response("Invalid rideId",status = 400,mimetype='application/text')
	else:
		usrs = getusers()
		if usn not in usrs:
			return Response("Username does not exist",status = 400,mimetype='application/text')
		else:
			mydata3 = {"table":"UserRides","insert":[rideId,usn]}
			r3 = requests.post("http://127.0.0.1:5000/api/v1/db/write",json=mydata3)
			res3 = r3.text
			if res3 == "201":
				return Response("Added user to ride",status = 200,mimetype='application/text')
			elif res3 == "400":
				return Response("User already added to the ride",status = 400,mimetype='application/text')
			elif res3 == "500":
				return Response("Internal server error",status = 500,mimetype='application/text')

##API 7 ##
@app.route("/api/v1/rides/<rideId>",methods=["DELETE"])
def del_ride(rideId):
	increment()
	query3= "SELECT COUNT(*) from Rides where rideId = '"+rideId+"'"
	mydata3 = {"query":query3}
	r3= requests.post("http://127.0.0.1:5000/api/v1/db/read",json=mydata3)
	res3 = json.loads(r3.text)
	count = res3[0]["COUNT(*)"]
	if count==0:
		return Response("Ride dosen't exist",status = 400,mimetype='application/text')
	else:
		query = "DELETE from UserRides where rideId = '"+rideId+"'"
		mydata = {"query":query}
		r = requests.post("http://127.0.0.1:5000/api/v1/db/read",json=mydata)
		res = r.text
		query2 = "DELETE FROM Rides where rideId = '"+rideId+"'"
		mydata2 = {"query":query2}
		r2 = requests.post("http://127.0.0.1:5000/api/v1/db/read",json=mydata2)
		res2 = r2.text
		if res=="200" and res2=="200":
			return Response("Ride deleted successfully",status = 200,mimetype='application/text')
		else:
			return Response("Internal server error",status = 500,mimetype='application/text')

@app.route("/api/v1/rides/count",methods=["GET"])
def count_ride():
	increment()
	query= "SELECT COUNT(*) from Rides"
	mydata = {"query":query}
	r = requests.post("http://127.0.0.1:5000/api/v1/db/read",json=mydata)
	res = json.loads(r.text)
	count = res[0]["COUNT(*)"]
	l = [count]
	return jsonify(l)

### Test ###
@app.route("/api/v1/area",methods=["GET"])
def getarea():
	query= "SELECT * from Area"
	mydata = {"query":query}
	r= requests.post("http://127.0.0.1:5000/api/v1/db/read",json=mydata)
	return jsonify(r.text)


### API 8 ###
@app.route("/api/v1/db/write",methods=["POST"])
def write_db():
	tbl = request.get_json()["table"]
	data = request.get_json()["insert"]
	if (tbl == "Rides"):
		frmt = "%d-%m-%Y:%S-%M-%H"
		date = datetime.strptime(data[1],frmt)	
		row = Rides(created_by=data[0],timestamp=date,source=int(data[2]),dest=int(data[3]))
		db.session.add(row)
		db.session.commit()
		return 'Added New Ride'
	elif (tbl == "UserRides"):
		try:
			row = UserRides(rideId=int(data[0]),username=data[1])
			db.session.add(row)
			db.session.commit()
			return '201'
		except exc.IntegrityError as e:
			db.session().rollback()
			return '400'
		except:
			return '500'
	elif (tbl == "ReqTable"):
		try:
			row = ReqTable(content=data[0])
			db.session.add(row)
			db.session.commit()
			return '201'
		except exc.IntegrityError as e:
			db.session().rollback()
			return '400'
		except:
			return '500'

### API 9 ###
@app.route("/api/v1/db/read",methods=["POST"])
def read_db():
	query = request.get_json()["query"]
	res = {}
	engine = create_engine('sqlite:///rides.db')
	connection = engine.connect()
	if "DELETE" in query:
		connection.execute(query)
		return "200"
	else:
		result = connection.execute(query)
		res = [dict(x) for x in result]
		return jsonify(res)

### clearDB API ###
@app.route("/api/v1/db/clear",methods=["POST"])
def clear_db():
	#increment()
	engine = create_engine('sqlite:///rides.db')
	connection = engine.connect()
	query = "DELETE FROM UserRides"
	connection.execute(query)
	query2 = "DELETE FROM Rides"
	connection.execute(query2)
	return "200"

@app.route('/',methods=["GET"])
def adduser():
	return "hello in Docker 01"

@app.route('/redirect',methods=["GET"])
def redirect():
	read_req=requests.get(url='http://172.17.0.1:8080/')
	data=read_req.json()
	return data

if(__name__=="__main__"):
    app.run(host="0.0.0.0", debug=True)
