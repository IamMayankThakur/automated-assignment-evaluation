from flask import Flask, jsonify, request, abort
from flask_sqlalchemy import SQLAlchemy
import requests, json
from areas import Areas
import datetime
import subprocess

application = Flask(__name__)
application.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///ride.db'
application.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(application)


class Ride(db.Model):
	rideId = db.Column(db.Integer, primary_key=True)
	created_by = db.Column(db.String(80), nullable=False)
	timestamp = db.Column(db.DateTime, nullable=False)
	source = db.Column(db.Integer, nullable=False)
	destination = db.Column(db.Integer, nullable=False)


class RideUsers(db.Model):
	Id = db.Column(db.Integer, primary_key=True)
	rideId = db.Column(db.Integer)
	username = db.Column(db.String(80), nullable=False)


ADDR = UADDR = "http://A3-1166210111.us-east-1.elb.amazonaws.com"
PORT = ":80"
WRADR = f'http://0.0.0.0{PORT}/api/v1/db/write'
RADR = f'http://0.0.0.0{PORT}/api/v1/db/read'
headers = {"Content-Type": "application/json"}


def is_present(username):
	try:
		ip = subprocess.check_output(["curl", "http://169.254.169.254/latest/meta-data/public-ipv4"])
		ip.decode()
	except:
		ip = "0.0.0.0"
	resp = requests.get(url=f"{UADDR}{PORT}/api/v1/users",headers={"Origin":f'http://{ip}'})
	if resp.status_code == 204:
		return None
	elif username in resp.json():
		return username


# @application.route("/api/v1/rides/<rideid>", methods=["DELETE", "GET", "POST", "PUT"])
# def delete_a_ride(rideid):
# 	if request.method == "DELETE":
# 		update_count()
# 		rideid = int(rideid)
# 		data = {"operation": 7, "rideId": rideid}
# 		resp = requests.post(url=WRADR, json=data, headers=headers)
# 		r_json = resp.json()
# 		if r_json["Error"] == "ride does not exist":
# 			return {}, 400
# 		if r_json["Error"] == "":
# 			return {}, 200
# 	else:
# 		return method_not_allowed()


@application.route("/api/v1/db/clear", methods=["DELETE", "GET", "POST", "PUT"])
def clear_db():
	if request.method == "POST":
		update_count()
		db.drop_all()
		db.create_all()
		return {}, 200
	else:
		return method_not_allowed()


@application.route("/api/v1/db/write", methods=["POST"])
def write_to_db():
	operation = request.get_json()["operation"]
	if operation == 3:
		created_by = request.get_json()["created_by"]
		timestamp = request.get_json()["timestamp"]
		timestamp = datetime.datetime.strptime(timestamp, "%d-%m-%Y:%S-%M-%H")
		src = request.get_json()["source"]
		dst = request.get_json()["destination"]
		new_ride = Ride(created_by=created_by, timestamp=timestamp, source=src, destination=dst)
		db.session.add(new_ride)

	elif operation == 6:
		rideid = request.get_json()["rideId"]
		uname = request.get_json()["username"]
		usr = is_present(uname)
		ride = Ride.query.filter_by(rideId=rideid).first()
		if not usr or not ride:
			return jsonify({"Error": "user or ride or both do not exist"})
		if ride.created_by == uname:
			return jsonify({"Error": "user is the creator of ride"})
		new_entry = RideUsers(rideId=ride.rideId, username=uname)
		db.session.add(new_entry)
	elif operation == 7:
		rideid = request.get_json()["rideId"]
		ride = Ride.query.filter_by(rideId=rideid).first()
		if not ride:
			return jsonify({"Error": "ride does not exist"})
		entries_from_RideUsers = RideUsers.query.filter_by(rideId=rideid).all()
		for entry in entries_from_RideUsers:
			db.session.delete(entry)
		db.session.delete(ride)
	db.session.commit()
	return jsonify({"Error": ""})


@application.route("/api/v1/db/read", methods=["POST"])
def read_from_db():
	operation = request.get_json()["operation"]
	# if operation == 3:
	# 	uname = request.get_json()["username"]
	# 	if not (is_present(uname)):
	# 		return jsonify({"Error": "user does not exist"})
	# 	return jsonify({"Error": ""})
	# elif operation == 4:
	if operation == 4:
		src = request.get_json()["source"]
		dst = request.get_json()["destination"]
		if not Ride.query.all():
			return jsonify({"Error": "", "rideList": []})
		ctime = datetime.datetime.now()
		rides = Ride.query.filter_by(source=src, destination=dst).filter( Ride.timestamp > ctime).all()
		rides_list = [{"rideId": ride.rideId, "created_by": ride.created_by, "timestamp": datetime.datetime.strftime(ride.timestamp, "%d-%m-%Y:%S-%M-%H")} for ride in rides]
		return jsonify({"Error": "", "rideList": rides_list})
	elif operation == 5:
		rideid = request.get_json()["rideId"]
		ride = Ride.query.filter_by(rideId=rideid).first()
		if not ride:
			return jsonify({"Error": "rideId does not exist"})
		ts = datetime.datetime.strftime(ride.timestamp, "%d-%m-%Y:%S-%M-%H")
		user_list = [entry.username for entry in RideUsers.query.filter_by(rideId=rideid).all()]
		ride_details = {"created_by": ride.created_by, "source": ride.source, "destination": ride.destination, "timestamp": ts, "users": user_list}
		return jsonify({"Error": "", "ride_details": ride_details})
	elif operation == 11:
		rides = Ride.query.all()
		r_count = len(rides)
		return jsonify({"count":r_count})
	return jsonify({"Error": ""})


@application.route("/api/v1/rides", methods=["DELETE", "GET", "POST", "PUT"])
def add_a_ride_or_upcoming_rides():
	if request.method == "POST":
		update_count()
		try:
			created_by = request.get_json()["created_by"]
			source = request.get_json()["source"]
			destination = request.get_json()["destination"]
			timestamp = request.get_json()["timestamp"]
		except KeyError:
			return {}, 400

		if source == destination:
			return {}, 400

		try:
			ts = datetime.datetime.strptime(
				timestamp, "%d-%m-%Y:%S-%M-%H")
		except ValueError:
			return {}, 400
		usr = is_present(created_by)

		if (not usr or not (int(source) < len(Areas) and int(destination) < len(Areas))):
			return {}, 400
		else:
			data = {"operation": 3, "created_by": created_by, "source": source,
                            "destination": destination, "timestamp": timestamp}
			resp = requests.post(url=WRADR, json=data, headers=headers)
			if resp.json()["Error"] == "":
				return {}, 201
	elif request.method == "GET":
		update_count()
		src = request.args.get("source")
		dst = request.args.get("destination")
		if ((src is None or dst is None) or not (int(src) < len(Areas) and int(dst) < len(Areas))):
			return {}, 400

		data = {"operation": 4, "source": src, "destination": dst}
		resp = requests.post(url=RADR, json=data, headers=headers)
		r_json = resp.json()
		print(r_json)
		err = r_json["Error"]
		if err == "":
			ride_list = r_json["rideList"]
			if ride_list == []:
				return {}, 204
			# details
			else:
				return jsonify(ride_list), 200
		else:
			return {}, 400
	else:
		return method_not_allowed()


@application.route("/api/v1/rides/<int:rideid>", methods=["DELETE", "GET", "POST", "PUT"])
def get_ride_details_or_join_a_ride_or_delete_a_ride(rideid):
	if request.method == "GET":
		update_count()
		rideid = int(rideid)
		data = {"operation": 5, "rideId": rideid}
		resp = requests.post(url=RADR, json=data, headers=headers)
		err = resp.json()["Error"]
		if err == "rideId does not exist":
			return {}, 400
		else:
			return resp.json()["ride_details"], 200
	elif request.method == "POST":
		update_count()
		rideid = int(rideid)
		try:
			uname = request.get_json()["username"]
		except KeyError:
			return {}, 400

		data = {"operation": 6, "username": uname, "rideId": rideid}

		resp = requests.post(url=WRADR, json=data, headers=headers)
		try:
			a = resp.json()["response"]
			return jsonify({"val": a})
		except:
			pass
		err = resp.json()["Error"]
		if err == "user or ride or both do not exist":
			return {}, 400
		elif err == "user is the creator of ride":
			return {}, 400
		else:
			# all OK
			return {}, 200
	elif request.method == "DELETE":
		update_count()
		rideid = int(rideid)
		data = {"operation": 7, "rideId": rideid}
		resp = requests.post(url=WRADR, json=data, headers=headers)
		r_json = resp.json()
		if r_json["Error"] == "ride does not exist":
			return {}, 400
		if r_json["Error"] == "":
			return {}, 200
	else:
		return method_not_allowed()


@application.route("/api/v1/rides/count", methods=["DELETE", "GET", "POST", "PUT"])
def count_rides():
	if request.method =="GET":
		update_count()
		data = {"operation": 11}
		resp = requests.post(url=RADR, json=data, headers=headers)
		r_json = resp.json()
		#print(r_json,type(r_json))
		count = r_json["count"]

		return str("[ " + str(count)+" ]"), 200
	else:
		return method_not_allowed()


@application.route("/api/v1/_count", methods=["DELETE", "GET", "POST", "PUT"])
def count_requests_and_reset_request():
	if request.method == "GET":
		#return {"msg":"hi"},200
		with open("count.txt") as c:
			request_count = json.load(c)["count"]
		return str("[ " + str(request_count)+" ]"), 200
	elif request.method == "DELETE":
		with open("count.txt", "w") as c:
			request_count = 0
			json.dump({"count": request_count}, c)
		return {}, 200
	else:
		return method_not_allowed()


# @application.route("/api/v1/_count", methods=["DELETE", "GET", "POST", "PUT"])
# def reset_requests(): delete
# 	with open("count.txt", "w") as c:
# 		request_count = 0
# 		json.dump({"count":request_count}, c)
# 	return {}, 200


@application.route("/test")
def test():
	return requests.get(url=f"{UADDR}{PORT}/api/v1/users")


@application.route("/")
def index():
	return jsonify("<h4>Hello ride World</h4>")

def update_count():
	with open("count.txt","r+") as c:
		request_count = json.load(c)["count"]
		request_count += 1
		c.seek(0)
		c.truncate()
		json.dump({"count":request_count},c)


@application.errorhandler(405)
def method_not_allowed():
	update_count()
	return {}, 405

if __name__ == "__main__":
	db.create_all()
	try:
		a = open("count.txt")
		a.close()
	except:
		with open("count.txt", "w") as c:
			request_count = 0
			json.dump({"count": request_count}, c)
	application.run(debug=True,host="0.0.0.0",port=int(PORT[1:]))
