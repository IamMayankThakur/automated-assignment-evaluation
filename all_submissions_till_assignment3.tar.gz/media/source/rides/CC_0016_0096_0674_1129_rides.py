import sys
import os
from dbb import db
from dbb import rides
from dbb import users
from sqlalchemy.exc import IntegrityError
from flask import Flask
from flask import request
from flask import jsonify
from flask import url_for
from flask import redirect
import json
from sqlalchemy import text
import requests
import datetime

n1=0

app = Flask(__name__)
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

#app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:////home/harshith/Desktop/6th_semester/cloud/flask/assignment1/not/san/cloud.db'
app.config['SQLALCHEMY_DATABASE_URI'] 	= 'sqlite:///../data/ride.db'
db.init_app(app)

		

@app.route('/api/v1/rides/count', methods=['POST','PUT','DELETE','PATCH','COPY','HEAD','OPTIONS','LINK','UNLINK','PURGE','LOCK','UNLOCK','PROPFIND','VIEW'])#API0.3
def count_ride1():
	
	global n1
	n1=n1+1
	return jsonify({}),405
		
		
@app.route('/api/v1/rides', methods=['PUT','DELETE','PATCH','COPY','HEAD','OPTIONS','LINK','UNLINK','PURGE','LOCK','UNLOCK','PROPFIND','VIEW'])#API0.3
def t_ride1():
	
	global n1
	n1=n1+1
	return jsonify({}),405	
	
	
@app.route('/api/v1/rides/<rideId>',methods=['PUT','PATCH','COPY','HEAD','OPTIONS','LINK','UNLINK','PURGE','LOCK','UNLOCK','PROPFIND','VIEW']) #API 7
def d_ride(rideId):
		
		global n1
		n1=n1+1
		return jsonify({}),405
			

@app.route('/api/v1/rides', methods=['POST']) #API 3
def add_ride():

	global n1
	n1=n1+1	
	if(request.method!="POST"):
			return jsonify({}),405
		
	_json = request.json
	_created_by = _json['created_by']
	_timestamp = _json['timestamp']
	_source = _json['source']
	_destination = _json['destination']
	
	try:
		date_obj = datetime.datetime.strptime(_timestamp, '%d-%m-%Y:%S-%M-%H')
	except:
		return jsonify({}),400
	

		
	if _created_by and _timestamp and _source and _destination and request.method == 'POST':
		
	
		url='http://load-balancer-1248704762.us-east-1.elb.amazonaws.com/api/v1/users'
		#url='http://ec2-34-239-72-32.compute-1.amazonaws.com/api/v1/db/read' 
		response=requests.get(url,headers={'Origin':'ec2-52-71-16-98.compute-1.amazonaws.com'})
		x =json.loads(response.text)
		if(_created_by not in x):
			return jsonify({}),400
		
		
		url='http://ec2-52-71-16-98.compute-1.amazonaws.com/api/v1/db/write' 
		obj={'table':'rides','created_by':_created_by,'timestamp':_timestamp,'source':_source,'destination':_destination,  		'method': 'POST'}
		response = requests.post(url,json=obj)
		if(response.status_code == 201):
				return jsonify({}),201
		else:
				return jsonify({}),400
				
		
			


@app.route('/api/v1/rides',methods=['GET']) #API 4
def ride():

	global n1
	n1=n1+1
	if(not(request.method == 'GET')):
		return jsonify({}),405			
				
		
	_source=request.args.get('source')
	_destination=request.args.get('destination')
	
	
	
	url='http://ec2-52-71-16-98.compute-1.amazonaws.com/api/v1/db/read'
	
	obj={'table':'rides','source':_source,'destination':_destination,'columns':["rideId","created_by","timestamp"],'method': 'GET'}
	response = requests.post(url,json=obj)
	x =json.loads(response.text.replace("created_by","username"))
	now_timestamp = datetime.datetime.now()

	
	if(response.text=="{}\n"):
		return jsonify({}),204
	else:	
		
		
		lst=[]
		for i in x:
			m=i['timestamp']
			if(datetime.datetime.strptime(m,'%d-%m-%Y:%S-%M-%H')>=now_timestamp):
				lst.append(i)
			else:
				continue
 			
		
		
		if(lst):
			return jsonify(lst),200
		else:
			return jsonify({}),204	
	


		
		
@app.route('/api/v1/db/clear',methods=['POST']) #API z
def del2():

	if(not(request.method == 'POST')):
		return jsonify({}),405
		
	
	
	sql = "DELETE FROM rides"
	
	
	x=db.session.execute(sql)
	db.session.commit()
	
	
	if(x):
		return jsonify({}),200
	else:
		return jsonify({}),400	
			
 		
	
	
	
@app.route('/api/v1/rides/<int:rideId>',methods=['GET'])  #API 5
def oneride(rideId):

		global n1
		n1=n1+1	
	
		url='http://ec2-52-71-16-98.compute-1.amazonaws.com/api/v1/db/read'
		
		if(not(request.method == 'GET')):
			return jsonify({}), 405
			
        	
	
		obj={'table':'rides','rideId':rideId,'method': 'GETALL'}
		response = requests.post(url,json=obj)
		x =json.loads(response.text)
		
		if(response.text == "{}\n"):
			return jsonify({}), 204
			
		else:
			return x,200
			#return response.text,200
        	        	
       
		
@app.route('/api/v1/rides/<int:rideId>', methods=['POST'])   #API 6
def update_user(rideId):
	
		global n1
		n1=n1+1
		if(not(request.method=='POST')):
			return jsonify('dd'),405
			
		url='http://ec2-52-71-16-98.compute-1.amazonaws.com/api/v1/db/read'
			
		obj={'table':'rides','rideId':rideId,'method': 'GETALL'}
		response1 = requests.post(url,json=obj)
		
		if(response1.text == "{}"):
			return jsonify({}), 400
			
				
		_json = request.json
		_name= _json['username']
				
		url='http://ec2-34-239-72-32.compute-1.amazonaws.com/api/v1/db/read' 
		obj={'table':'users','name':_name,'method': 'GET'}
		response2 = requests.post(url,json=obj)	
		if(response2.status_code == 400):
				return jsonify({}),400
				
		x = json.loads(response1.text)
		passengers = x["users"]
		
		
		if not passengers:                        
			passengers = _name 
		else:
			if(_name in passengers):
				return jsonify({}),204
			passengers=passengers +','+_name
		
		
		
		url='http://ec2-52-71-16-98.compute-1.amazonaws.com/api/v1/db/write' 
		obj={'table':'rides','users': passengers,'rideId':rideId,'method': 'UPDATE'}
		response = requests.post(url,json=obj)
		if(response.status_code == 200):
				return jsonify({}),200
		else:	
				return jsonify({}),400
			
		
			
		

@app.route('/api/v1/rides/<rideId>', methods=['DELETE']) #API 7
def delete_ride(rideId):
	
		global n1
		n1=n1+1
		if(not(request.method=="DELETE")):
			return jsonify({}),405
			
		url='http://ec2-52-71-16-98.compute-1.amazonaws.com/api/v1/db/read'
			
		obj={'table':'rides','rideId':rideId,'method': 'GETALL'}
		response = requests.post(url,json=obj)
		
		if(response.text == "{}\n"):
			return jsonify({}), 400
		
		url='http://ec2-52-71-16-98.compute-1.amazonaws.com/api/v1/db/write' 
		obj={'table':'rides','rideId':rideId,'method': 'DELETE'}
		response = requests.post(url,json=obj)
		return jsonify({}),200
		
		
		
 
	
@app.route('/api/v1/rides/count', methods=['GET']) #API countrides
def count_ride():
	
	global n1
	n1=n1+1
	if(request.method!="GET"):
			return jsonify({}),405
			
	sql = "SELECT COUNT(*) FROM rides"
	
	
	x=db.session.execute(sql)
	dic={}
	
	for i in x:
		dic[1]=i[0]
		
	no=dic[1]
	#print(no)
	
	li=[]
	li.append(no)
	if(x):
		return jsonify(li),200
	else:
		return jsonify({}),400	
			
	

@app.route('/api/v1/_count', methods=['GET']) #API counthttp
def count_http():
	
	if(request.method!="GET"):
			return jsonify({}),405
	
	lst=[]
	lst.append(n1)		
	return jsonify(lst),200	
			
			
			
@app.route('/api/v1/_count', methods=['DELETE']) #API clearhttp
def clear_http():
	
	if(request.method!="DELETE"):
			return jsonify({}),405
			
	global n1
	
	n1=0
	return jsonify({}),200	



@app.route('/api/v1/db/write',methods=["POST"])  #API 8
def write():
	try:
		_json = request.get_json()
		
				
				
		if(_json['table']=='rides'):
			if (_json['method']=='POST'):				
				
				a=_json['created_by']
				b=_json['timestamp']
				c=_json['source']
				d=_json['destination']
				
				e= "\'" + a + "\'" + "," + "\'" + b + "\'" + "," + c + "," + d 
				sql = text("INSERT INTO rides (created_by,timestamp,source,destination) VALUES ("+e+")")
				#data = (_json['created_by'],_json['timestamp'],_json['source'],_json['destination'],)
				
				
				x=db.session.execute(sql)
				db.session.commit()
						
			
				if(x):
					return jsonify({}),201
				else:
					return jsonify({}),400	

		
			if (_json['method']=='DELETE2'):	
				
				
				#db.session.execute("DELETE FROM rides WHERE created_by=%s", (_json['created_by'],))
				c="\'" + _json['created_by'] + "\'"
				sql = text("DELETE FROM rides WHERE created_by="+c)
								
				db.session.execute(sql)
							
				db.session.commit()
				
				
				return jsonify({}),200
			
			if (_json['method']=='DELETE'):	
				
				
				#db.session.execute("DELETE FROM rides WHERE rideId=%s", (_json['rideId'],))
				a= _json['rideId']
				c=str(a) 
				sql = text("DELETE FROM rides WHERE rideId="+c)
								
				db.session.execute(sql)							
				db.session.commit()				
				
				return jsonify({}),200
				
				
				
			if (_json['method']=='UPDATE'):
			
				c="\'" + _json["users"] + "\'"
				d=_json['rideId'] 
				b=str(d)
				
				sql = text("UPDATE rides SET users="+c+" WHERE rideId="+b)
				
				
				
				x=db.session.execute(sql) #, {'users':_json["users"],'rideId':_json["rideId"]} )
				db.session.commit()
				
				
				
				if(x):
					return jsonify({}),200
				else:
					return jsonify({}),400	
			
		
		
			else:
				return not_found()			
			
				
						
	except Exception as e:
		print(e)
			


@app.route('/api/v1/db/read',methods=['POST'])   #API 9
def read():


	try:
		_json = request.get_json()
		
		
		
				
		
		if(_json['table']=='rides'):
		
			if (_json['method']=='GET'):
			
				columns=_json["columns"]
				
				a= _json['source'] 
				b= _json['destination'] 
				
				select_stmt = text("SELECT rideId,created_by,timestamp FROM rides WHERE source="+a+" and destination="+b)
				
				
				x=db.session.execute(select_stmt)
				
				
				dic = {}
				li=[]
				for row in x:
					dic={}
					for i in range(len(row)):
						if(columns[i] not in dic):
							dic[columns[i]]=row[i]
					li.append(dic)
				return jsonify(li)
				
				
				
			if (_json['method']=='GETUSERS'):
			
				_name=_json["name"]
				
				columns=['rideId','users']
				select_stmt = text("SELECT rideId,users FROM rides")
				x=db.session.execute(select_stmt)
				#rows = cursor.fetchall()
				#resp = jsonify(x)
				dic = {}
				li=[]
				#return jsonify({}),200
				for row in x:
					dic={}
					for i in range(len(row)):
						if(columns[i] not in dic):
							dic[columns[i]]=row[i]
					li.append(dic)
				return jsonify(li)
				
				
				'''if(x):
					return resp,200
				else:
					return jsonify({}),400	'''
				
				
				
			if (_json['method']=='GETALL'):	
				
				a=_json['rideId']
				b=str(a)
				
				sql=text("SELECT * FROM rides WHERE rideId="+b)
				x=db.session.execute(sql)  # ", _json['rideId'])
				#row = cursor.fetchone()
				#resp = jsonify(x)
				
				columns=['rideId','created_by','timestamp','source','destination','users']
				dic = {}
				li=[]
				
				for row in x:
			
					dic={}
					for i in range(len(row)):
						if(columns[i] not in dic):
							dic[columns[i]]=row[i]
				
				
				return jsonify( dic)
				
				
				
	except Exception as e:
		print(e)
	
		
		
				




		
@app.errorhandler(404)
def not_found(error=None):
    message = {
        'status': 404,
        'message': 'Not Found: ' + request.url,
    }
    resp = jsonify(message)
    resp.status_code = 404

    return resp
		
if __name__ == "__main__":
    if os.environ.get('PORT') is not None:
        app.run(debug=True, host='0.0.0.0', port=os.environ.get('PORT'))
    else:
        app.run(debug=True, host='0.0.0.0',port=80) 
