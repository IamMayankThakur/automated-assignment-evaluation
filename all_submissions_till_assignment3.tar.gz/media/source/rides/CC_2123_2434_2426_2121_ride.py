from flask import Flask,render_template,jsonify,request,abort
from random import seed
import datetime
import random
import pymysql
import string
import requests
import json

app=Flask(__name__)


#Database connection
connection = pymysql.connect(host="172.18.0.2", port=3306, user="root", passwd="password", database="cloud")
cursor = connection.cursor()
http_count = 0

#Load Balancers Checks this.
@app.route("/")
def new_method():
    return "", 200

# Creating New Ride
@app.route("/api/v1/rides", methods=["POST"])
def new_ride():
    # {"ride":{"created_by":"Aishu","timestamp":"02-02-2020:00-02-12","source":"Hebbala","destination":"Horamavu"}}
    rideid = 0
    app.config["http_count2"] += 1
    ride_info = dict(request.get_json())
    ride_info['timestamp'], rideid = format(str(ride_info['timestamp']).split(":"))

    #Verify user existence
    req = requests.get('http://52.71.191.12/api/v1/users')
    users = list(json.loads(req.text))
    valid = 0
    for i in range(len(users)):
        if (users[i] == str(ride_info["created_by"])):
            valid = 1
            break
    # return jsonify({"hi":valid}), 400

    if(valid == 1):
        if(int(ride_info["source"]) == int(ride_info["destination"])):
            return jsonify({}), 400

        elif(int(ride_info["source"]) < 1 or int(ride_info["source"]) > 198):
            return jsonify({}), 400

        elif(int(ride_info["destination"]) < 1 or int(ride_info["destination"]) > 198):
            return jsonify({}), 400


        #Adding new ride to DB
        payload = {"insert":[rideid, str(ride_info["created_by"]),str(ride_info["source"]),\
            str(ride_info["destination"]),ride_info["timestamp"]],"columns":["Ride_Id",\
                "Created_by","Source","Destination","Time_Stamp"],"table":"Rides"}
        req = requests.put("http://0.0.0.0:80/api/v1/db/write", json = {"query": payload})

        if(req.status_code == 201):
            return jsonify({}), 201
        else:
            return jsonify({}), 400
    else:
        return jsonify({}), 400


#Listing All Upcoming Rides
@app.route("/api/v1/rides", methods=["GET"])
def list_all_rides():
    app.config["http_count2"] += 1
    try:
        arguments = request.args
    except:
        return jsonify({}), 400
    loc_validate = 0
    valid_user = list()
    src = ""
    dest = ""
    if(int(arguments['source']) >= 1 or int(arguments['source']) <= 198):
        loc_validate += 1
        src = arguments['source']

    if(int(arguments['destination']) >= 1 or int(arguments['destination']) <= 198):
        loc_validate += 1
        dest = arguments['destination']

    if(loc_validate == 2):
        payload = {"table":"Rides","columns":["*"],\
        "where": "Source='" + src + "' AND " + "Destination='" + dest}
        # print(payload)
        req = requests.post("http://0.0.0.0:80/api/v1/db/read", json = {"query": payload})
        if(req.status_code == 401):
            return jsonify({}), 204

            
        result = json.loads(req.text)
        # Compare current Date and time    
        now = datetime.datetime.now()
        # return jsonify({"here":result})
        for i in list(result.keys()):
            check_time = str(result[i][4]).split(" ")
            date = check_time[0].split("-")
            time = check_time[1].split(":")
            # datetime(year, month, day, hour, minute, second, microsecond)
            x = datetime.datetime(int(date[0]), int(date[1]), int(date[2]),int(time[0]), int(time[1]), int(time[2]))
            # return jsonify({"here": x})
            if(x < now):
                del result[i]
 
        valid_user = list()
        for i in result.keys():
            #Verify user existence
            req = requests.get('http://52.71.191.12/api/v1/users')
            users = list(json.loads(req.text))
            # return jsonify({"hi":users[1]}), 200
            valid = 0
            for j in range(len(users)):
                if (str(result[i][1]) == str(users[j])):
                    valid = 1
                    break
            # return jsonify({"hi":"pass"}), 200
            # valid = 1
            if(valid == 1):
                valid_user.append(i)
            else:
                return jsonify({}),400
        valid_ride = list()

        for i in valid_user:
            temp = dict()
            # print(result[i][4])
            result[i][4], dummy = format(str(result[i][4]).split(" "))
            # print(result[i][4])
            temp["rideId"] = result[i][0]
            temp["username"] = result[i][1]
            temp["timestamp"] = result[i][4]
            valid_ride.append(temp)
        # print(valid_ride)
        return jsonify(valid_ride), 200
    else:
        return jsonify({}), 400


#List Details of a Particular ID.
@app.route("/api/v1/rides/<rideId>", methods=["GET"])
def ride_details(rideId):
    app.config["http_count2"] += 1
    try:
        payload = {"table":"Rides","columns":["*"],\
            "where": "Ride_Id = '" + str(rideId)}
        req = requests.post("http://0.0.0.0:80/api/v1/db/read", json = {"query": payload})
        if(req.status_code == 401):
            return jsonify({}), 204
        result1 = json.loads(req.text)
        payload = {"table":"Ride_Shared","columns":["*"],\
            "where": "Ride_Id = '" + str(rideId)}
        req = requests.post("http://0.0.0.0:80/api/v1/db/read", json = {"query": payload})
        # print(result1)
        ride_info = dict() 
        temp = list()
        result2 = dict()
        if(req.text != ""):
            result2 = json.loads(req.text)
            for i in result2.keys():
                temp.append(result2[i][1])
        
        index = list(result1.keys())
        index = str(index[0])
        ride_info["rideId"] = result1[index][0] 
        ride_info["created_by"] = result1[index][1]
        ride_info["users"] = temp
        result1[index][4], dummy = format(str(result1[index][4]).split(" "))
        ride_info["timestamp"] = result1[index][4]
        ride_info["source"] = result1[index][2]
        ride_info["destination"] = result1[index][3]
        return jsonify(ride_info), 200
    except:
        return jsonify({}),405


#Join An existing ride.
@app.route("/api/v1/rides/<rideId>", methods=["POST"])
def join_ride(rideId):
    #Structure {"user":{"username":"Aishwarya"}}
    app.config["http_count2"] += 1
    join_user = dict(request.get_json())
    payload = {"table":"Rides","columns":["*"],\
        "where":"Ride_Id = '" + str(rideId)}
    req = requests.post("http://0.0.0.0:80/api/v1/db/read", json = {"query": payload})
    
    if(req.text != ""):
        result = json.loads(req.text)
        for i in result.keys():
            if (str(join_user["username"]) == str(result[i][1])):
                return jsonify({}), 400;
        # return jsonify({"hello1":req.text}), 200
        #Verify user existence
        req = requests.get('http://52.71.191.12/api/v1/users')
        users = list(json.loads(req.text))
        valid = 0
        for i in range(len(users)):
            if (users[i] == str(join_user["username"])):
                valid = 1
                break

        if(valid  == 1):
            payload = {"insert": [str(rideId),str(join_user["username"])],\
                    "columns":["Ride_Id","User_Name"],"table":"Ride_Shared"}
            req = requests.put("http://0.0.0.0:80/api/v1/db/write", json = {"query": payload})
            if(req.status_code == 201):
                return jsonify({}), 200
            else:
                return jsonify({}), 400
        else:
            return jsonify({}), 400
    else:
        return jsonify({}), 204
            

#Delete a Ride.
@app.route("/api/v1/rides/<rideId>", methods=["DELETE"])
def delete_ride(rideId):
    app.config["http_count2"] += 1
    try:
        payload = {"table":"Ride_Shared","columns":["*"],\
            "where": "Ride_Id = '" + str(rideId)}
        req = requests.post("http://0.0.0.0:80/api/v1/db/read", json = {"query": payload})
        # print(payload)
        if(req.text != ""):
            deleteSql = "DELETE FROM Ride_Shared WHERE Ride_Id = '" + str(rideId) + "';"
            cursor.execute(deleteSql)
            # print(deleteSql)
            connection.commit()

        payload = {"table":"Rides","columns":["*"],\
        "where":"Ride_Id = '" + str(rideId)}
        req = requests.post("http://0.0.0.0:80/api/v1/db/read", json = {"query": payload})
        if(req.status_code in [400,401]):
            return jsonify({}), 400
        else:
            try:
                deleteSql = "DELETE FROM Rides WHERE Ride_Id = '" + str(rideId) + "';"
                cursor.execute(deleteSql)
                connection.commit()
                return jsonify({}), 200
            except:
                return jsonify({}), 400
    except:
        return jsonify({}), 400
        

# Format the Date and Time in Required Format    
def format(date_and_time):
    # print(date_and_time)
    # date_and_time = list(date_and_time.split(":"))
    date = list(date_and_time[0].split("-"))
    time = list(date_and_time[1].split("-"))
    if(len(time) == 1):
        time = list(date_and_time[1].split(":"))
    date_and_time = ""

    for i in range(len(date)-1,-1,-1): #Making Time and Date in Format
        date_and_time = date_and_time + str(date[i]) + "-"
    date_and_time = date_and_time[0:len(date_and_time)-1] + ":"
    for i in range(len(time)-1,-1,-1):
        date_and_time = date_and_time + str(time[i]) + "-"
    date_and_time = date_and_time[0:len(date_and_time)-1]

    return date_and_time, random.randint(0, 9999999999)


# Write to DB
@app.route("/api/v1/db/write", methods=["PUT"])
def db_write():
    # print("I am in Write DB")
    req = request.get_json()["query"]
    query = "INSERT INTO " + req["table"] + " ("
    for i in req["columns"]:
        query = query + i + ","
    query = query[0:len(query)-1] + ") VALUES("
    for i in req["insert"]:
        query = query + "'" + str(i) + "',"
    query = query[0:len(query)-1] + ");"
    try:
        # print(query) 
        cursor.execute(query)
        connection.commit()
        return jsonify({"noerror":query}), 201
    except Exception as ex:
        # print(ex.args)
        return jsonify({"error":query}), 400


# Read to DB
@app.route("/api/v1/db/read", methods=["POST"])
def db_read():
    req = request.get_json()["query"]
    query = ""
    if(req["where"] == "NULL"):
        query = "SELECT * FROM " + req["table"] + " ;"
    else:
        query = "SELECT * FROM " + req["table"] +" WHERE " + req["where"] + "';"
    try: 
        # print(query)
        cursor.execute(query)
        rows = cursor.fetchall()
        data = dict()
        index = 1
        for r in rows:
            temp = list()
            for i in r:
                temp.append(str(i))
            data[index] = temp
            index += 1
        
        if (len(rows) != 0):
            return jsonify(data), 201
        else:
            return jsonify({"error":query}), 401
    except:
        return "", 400


# Clear DB
@app.route("/api/v1/db/clear", methods=["POST"])
def clear_db():
    try:
        deleteSql = "DELETE FROM Rides;"
        cursor.execute(deleteSql)
        connection.commit()
        deleteSql = "DELETE FROM Ride_Shared;"
        cursor.execute(deleteSql)
        connection.commit()
        return jsonify({}), 200
    except:
        return jsonify({}), 400
        

# For Counting the Total Number of Http request made.
@app.route("/api/v1/_count",methods=["GET"])
def count_http():
    try:
        return json.dumps([app.config["http_count2"]]), 200
    except:
        return {}, 405


# For Reseting Http request counter.
@app.route("/api/v1/_count", methods=["DELETE"])
def reset_http():
    try:
        app.config["http_count2"] = 0
        return {}, 200
    except:
        return {}, 405


# To Get Total Number of Rides
@app.route("/api/v1/rides/count", methods=["GET"])
def count_total_rides():
    app.config["http_count2"] += 1
    payload = {"table":"Rides","columns":["*"],\
    "where": "NULL"}
    # print(payload)
    req = requests.post("http://0.0.0.0:80/api/v1/db/read", json = {"query": payload})
    if(req.status_code == 401):
        return json.dumps([0]), 200       
    result = json.loads(req.text)
    return json.dumps([len(list(result.keys()))]), 200


if __name__ == '__main__':

    app.debug = True
    app.config["http_count2"] = 0
    app.run(host="0.0.0.0", port='80', debug=True)