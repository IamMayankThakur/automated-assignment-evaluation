from flask import Flask, render_template, jsonify, request, abort, Response
from flask_sqlalchemy import SQLAlchemy
from collections import defaultdict
import requests
import json
import datetime
import os
# from enum import Enum, unique

# CC_0225_0283

LOAD_BALANCER_IP = os.environ['LOAD_BALANCER_IP']
RIDES_EC2_IP = os.environ['RIDES_EC2_IP']
USERS_EC2_IP = os.environ['USERS_EC2_IP']

application = Flask(__name__)
application.config.from_object('configuration.DevelopmentConfig')
application.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(application)

from RideShare_DB import Ride, User_Ride, HTTP_Req_Count

def DPSdateconverttostring(datetimeobj):
    year = datetimeobj.year
    month = datetimeobj.month
    day = datetimeobj.day
    hour = datetimeobj.hour
    minute = datetimeobj.minute
    second = datetimeobj.second
    return str(day)+"-"+str(month)+"-"+str(year)+":"+str(second)+"-"+str(minute)+"-"+str(hour)

def DPSdateconvertstringtodate(datetimestring):
    dsplitt = datetimestring.split(':')
    date = [int(splitval) for splitval in dsplitt[0].split('-')]
    time = [int(splitval) for splitval in dsplitt[1].split('-')]
    
    day = date[0]
    month = date[1]
    year = date[2]
    
    hours = time[2]
    minutes = time[1]
    seconds = time[0]

    return datetime.datetime(year=year, month=month, day=day, hour=hours, minute=minutes,second=seconds)

@application.route('/', methods=["get"])
def fallbackmain():	
    return Response({"Connection - Success"},status=200, mimetype='application/json')

@application.route('/api/v1/rides/fallback', methods=["get"])
def fallback():	
    return Response({"Congrats it's a success -> Ride Instance"},status=200, mimetype='application/json')

@application.route('/api/v1/db/write', methods=["POST"])
def db_write():	
    # Delete or insert
    case_no = request.get_json()['case']
    table_name = request.get_json()['table_name']

    # Insert
    if (case_no == 1):
        
        flag = 1
            
        if table_name == 'ride':
            created_by = request.get_json()['created_by']
            source = request.get_json()['source']
            destination = request.get_json()['destination']
            start_time = DPSdateconvertstringtodate(request.get_json()['timestamp'])

            if(start_time >= datetime.datetime.now()):
                record = Ride(created_by, source, destination, start_time)

            else:
                flag = 0

        elif table_name == 'http_req_count':
            flag = 2
            add_or_reset_or_init = request.get_json()['add_or_reset_or_init']
            record = HTTP_Req_Count.query.first()
            if add_or_reset_or_init == 1:
                record.counter = record.counter + 1
            elif add_or_reset_or_init == 2:
                record.counter = 0
            else:
                record = HTTP_Req_Count(0)
                flag = 1

        else:
            u_ride_id = request.get_json()['u_ride_id']
            u_user_name = request.get_json()['u_user_name']
            
            record = Ride.query.filter(Ride.ride_id == u_ride_id)
            
            try:
                for i in record:
                    if((i.retjson()['start_time']) >= datetime.datetime.now()):
                        flag = 1
                        
                    else:
                        flag = 0

                record =  User_Ride(u_ride_id, u_user_name)

            except:
                flag = 0

        if case_no == 1 and flag != 0:
            if flag == 1:

                try:
                    db.session.add(record)
                    db.session.commit()
                    flag = 1

                except:
                    flag = 0

            if flag == 2:

                try:
                    db.session.commit()
                    flag = 1

                except:
                    flag = 0

    
    else:
        db_delete = request.get_json()['db_delete']
        
        if table_name == 'ride' and db_delete == 0:
            record = Ride.query.get(str(request.get_json()['ride_id']))

        elif table_name == 'ride' and db_delete==1:
            record = Ride.query.all()

        elif table_name=='user_ride' and db_delete==1:
            record = User_Ride.query.all()

        try:
            if(type(record)==type(list())):
                for i in record:
                    db.session.delete(i)
                db.session.commit()

            else:
                db.session.delete(record)
                db.session.commit()
            flag = 1

        except:
            flag = 0

    if flag == 1:
        return "OK"

    else:
        return "NOTOK"


@application.route('/api/v1/db/read', methods=["POST"])
def db_read():
    table_name = request.get_json()['table_name']

    if table_name == 'ride':
        if request.get_json()['ridesordetails'] == 1:
            source_name = request.get_json()['source']
            dest_name = request.get_json()['destination']
            retquery = Ride.query.filter(Ride.source == source_name, Ride.destination == dest_name, Ride.start_time >= datetime.datetime.now())
            retval = defaultdict(list)
            counter = 0

            for i in retquery:
                store = i.retjson()
                store['start_time'] = DPSdateconverttostring(store['start_time'])
                retval[counter].append(store)
                counter += 1
            
            return retval
        

        else:
            ride_id = request.get_json()['ride_id']
            retquery = Ride.query.filter_by(ride_id=ride_id)
            retval = defaultdict(list)
            counter = 0

            for i in retquery:
                store = i.retjson()
                store['start_time'] = DPSdateconverttostring(store['start_time'])
                retval[counter].append(store)
                counter += 1

            return retval

    elif table_name == 'http_req_count':
        retquery = HTTP_Req_Count.query.first()
        if retquery == None:
            retval = "None"
        else:
            retval = retquery.retjson()

    elif table_name == 'ride_count':
        retquery = Ride.query.all()
        retval = defaultdict(int)
        retval[0] = len(retquery)

    else:
        ride_id = request.get_json()['u_ride_id']
        retquery = Ride.query.filter_by(ride_id=ride_id)
        counter = 0
        retval = dict()

        for i in retquery:
            retval = (i.retjson())
            counter += 1
        
        if(len(retval)):
            retval['start_time'] = DPSdateconverttostring(retval['start_time'])
            retval['users'] = list()

            usersquery = User_Ride.query.filter_by(u_ride_id=ride_id)

            for i in usersquery:
                retval['users'].append(i.retjson()['u_user_name'])

    return retval

# Clear DB
@application.route('/api/v1/db/clear', methods=["POST"])
def db_clear():
    try:
        json_data = {
            "table_name": "ride",
            "case": 2,
            "db_delete": 1
        }

        dbtemp = requests.post('http://0.0.0.0:9998/api/v1/db/write', json = json_data)

        if dbtemp.text == "OK":
            return Response(status=200, mimetype='application/json')

        else:
            return Response(status=400, mimetype='application/json')

    except:
        return Response(status=400, mimetype='application/json')

    try:
        json_data = {
            "table_name": "user_ride",
            "case": 2,
            "db_delete": 1
        }

        dbtemp = requests.post('http://0.0.0.0:9998/api/v1/db/write', json = json_data)

        if dbtemp.text == "OK":
            return Response(status=200, mimetype='application/json')

        else:
            return Response(status=400, mimetype='application/json')

    except:
        return Response(status=400, mimetype='application/json')


# List upcoming rides:
@application.route('/api/v1/rides', methods=["GET"])
def list_upcoming_rides():

    dbcount = requests.post('http://0.0.0.0:9998/api/v1/count_incr')
    source = request.args.get('source')
    destination = request.args.get('destination')

    if int(source) <= 198 and int(source) >= 1 and int(destination) <= 198 and int(destination) >= 1:
        rides = list()

        json_data = {
            "table_name": "ride",
            "source" : source,
            "destination" : destination,
            "ridesordetails" : 1
        }
        
        dbtemp = requests.post('http://0.0.0.0:9998/api/v1/db/read', json = json_data)

        for ride in dbtemp.json().values():
            if ride[0]['source'] == source and ride[0]['destination'] == destination:
                newride = dict()
                newride["rideId"] = ride[0]['ride_id']
                newride["username"] = ride[0]['created_by']
                newride["timestamp"] = ride[0]['start_time']
                rides.append(newride)

        if len(rides) == 0:
            return Response(status=204, mimetype='application/json')
        
        else:
            return jsonify(rides), 200

    else:
        return Response(status=400, mimetype='application/json')


# Create ride:
@application.route("/api/v1/rides", methods = ["POST"])
def create_ride():

    dbcount = requests.post('http://0.0.0.0:9998/api/v1/count_incr')
    global LOAD_BALANCER_IP
    global RIDES_EC2_IP
    global USERS_EC2_IP

    try:
        if int(request.get_json()['source']) <= 198 and int(request.get_json()['source']) >= 1 and int(request.get_json()['destination']) <= 198 and int(request.get_json()['destination']) >= 1:
            new_ride = {
                "table_name": "ride",
                "created_by": request.get_json()['created_by'],
                "source": request.get_json()['source'],
                "destination": request.get_json()['destination'],
                "timestamp" : request.get_json()['timestamp'],
                "case": 1
            }

            session = requests.Session()
            session.trust_env = False
            session.headers.update({"Origin": "https://"+RIDES_EC2_IP})
            session.headers.update({"Access-Control-Allow-Origin":"*"})
            session.headers.update({"Access-Control-Allow-Methods":"POST, GET, OPTIONS"})
            session.headers.update({"Access-Control-Max-Age":"1000"})
            session.headers.update({"Access-Control-Allow-Headers":"*"})
            dbtemp2 = session.get("http://"+LOAD_BALANCER_IP+"/api/v1/users")

            if(request.get_json()['created_by'] in dbtemp2.json()):
                dbtemp = requests.post("http://0.0.0.0:9998/api/v1/db/write", json=new_ride)

                if dbtemp.text == "OK":
                    return Response(status=201, mimetype='application/json')

                else:
                    return Response({"Wrong timestamp"},status=400, mimetype='application/json')

            else:
                return Response({"Username does not exist"}, status=400, mimetype='application/json')    

        else:
            return Response({"Our services for the source/destination will be available soon"}, status=400, mimetype='application/json')   

    except:
        return Response({"Please try again later"},status=400, mimetype='application/json')


# Delete a ride:
@application.route("/api/v1/rides/<rideID>", methods=["DELETE"])
def delete_ride(rideID):

    dbcount = requests.post('http://0.0.0.0:9998/api/v1/count_incr')
    try:
        rideID = int(rideID)
    
    except:
        return Response(status=400, mimetype='application/json')

    try:
        json_data = {
            "table_name": "ride",
            "ride_id": rideID,
            "case" : 2,
            "db_delete": 0
        }

        dbtemp = requests.post('http://0.0.0.0:9998/api/v1/db/write', json = json_data)

        if dbtemp.text == "OK":
            return Response(status=200, mimetype='application/json')

        else:
            return Response(status=400, mimetype='application/json')

    except:
        return Response(status=400, mimetype='application/json')


# Join existing ride:
@application.route("/api/v1/rides/<rideID>", methods=["POST"])
def join_existing_ride(rideID):
    
    dbcount = requests.post('http://0.0.0.0:9998/api/v1/count_incr')

    json_request_params = {
        "table_name": "ride",
        "ride_id": rideID,
        "ridesordetails" : 2
    }
    
    dbtemp = requests.post("http://0.0.0.0:9998/api/v1/db/read", json=json_request_params)
    
    if len(dbtemp.json()) == 0:
        return Response(status=400, mimetype='application/json')

    else:
        user_name = request.get_json()["username"]
        
        json_request_params = {
            "table_name": "user",
            "user_name": user_name
        }
        
        session = requests.Session()
        session.trust_env = False
        session.headers.update({"Origin": RIDES_EC2_IP})
        session.headers.update({"Access-Control-Allow-Origin":"*"})
        session.headers.update({"Access-Control-Allow-Methods":"POST, GET, OPTIONS"})
        session.headers.update({"Access-Control-Max-Age":"1000"})
        session.headers.update({"Access-Control-Allow-Headers":"*"})
        dbtemp2 = session.get("http://"+LOAD_BALANCER_IP+"/api/v1/users")

        if(user_name in dbtemp2.json()):
            new_join = dict()
            new_join["table_name"] = "user_ride"
            new_join["u_ride_id"] = rideID
            new_join['u_user_name'] = user_name
            new_join["case"] = 1
            
            dbtemp3 = requests.post("http://0.0.0.0:9998/api/v1/db/write", json=new_join)
            
            if dbtemp3.text == "OK":
                return Response(status=200, mimetype='application/json')
                
            else:
                return Response(status=400, mimetype='application/json')
            
        else:
            return Response(status=400, mimetype='application/json')


# List details of a ride:
@application.route('/api/v1/rides/<rideId>', methods=["GET"])
def list_ride_details(rideId):

    dbcount = requests.post('http://0.0.0.0:9998/api/v1/count_incr')
    
    json_data = {
        "table_name": "user_ride",
        "u_ride_id": rideId
    }

    dbtemp = requests.post("http://0.0.0.0:9998/api/v1/db/read", json=json_data)

    if(len(dbtemp.json())):
        printformat = dict()
        printformat["rideId"] = dbtemp.json()['ride_id']
        printformat["Created_by"] = dbtemp.json()['created_by']
        printformat["users"] = dbtemp.json()['users']
        printformat["Timestamp"] = dbtemp.json()['start_time']
        printformat["source"] = dbtemp.json()['source']
        printformat["destination"] = dbtemp.json()['destination']
        return jsonify(printformat), 200

    else:
        return Response(status=400, mimetype='application/json')


#HTTP requests increment counter
@application.route('/api/v1/count_incr', methods=["POST"])
def count_incr():

    try:
        tempinit = requests.get('http://0.0.0.0:9998/api/v1/_count')
        
        json_data = {
            "table_name": "http_req_count",
            "case" : 1,
            "add_or_reset_or_init" : 1
        }

        dbtemp = requests.post('http://0.0.0.0:9998/api/v1/db/write', json = json_data)

        if dbtemp.text == "OK":
            return Response(status=200, mimetype='application/json')

        else:
            return Response(status=400, mimetype='application/json')

    except:
        return Response(status=400, mimetype='application/json')

# reset HTTP requests counter
@application.route('/api/v1/_count', methods=["DELETE"])
def del_count():

    try:
        tempinit = requests.get('http://0.0.0.0:9998/api/v1/_count')

        json_data = {
            "table_name": "http_req_count",
            "case" : 1,
            "add_or_reset_or_init" : 2
        }

        dbtemp = requests.post('http://0.0.0.0:9998/api/v1/db/write', json = json_data)

        if dbtemp.text == "OK":
            return Response(status=200, mimetype='application/json')

        else:
            return Response(status=400, mimetype='application/json')

    except:
        return Response(status=400, mimetype='application/json')

# display count
@application.route('/api/v1/_count', methods=["GET"])
def list_count():
    try:
        json_data = {
            "table_name": "http_req_count"
        }

        dbtemp = requests.post('http://0.0.0.0:9998/api/v1/db/read', json=json_data)
        
        if(dbtemp.text == "None"):
            json_data = {
                "table_name": "http_req_count",
                "case" : 1,
                "add_or_reset_or_init" : 3
            }
            dbtemp = requests.post('http://0.0.0.0:9998/api/v1/db/write', json=json_data)

            json_data = {
                "table_name": "http_req_count"
            }

            dbtemp = requests.post('http://0.0.0.0:9998/api/v1/db/read', json=json_data)

        retvaltemp = dbtemp.json()['counter']
        retval = list()
        retval.append(retvaltemp)
        return jsonify(retval), 200
                
    except:
        return Response(status=400, mimetype='application/json')
        
#display number of rides
@application.route('/api/v1/rides/count', methods=["GET"])
def list_rides_count():
    try:
        json_data = {
            "table_name": "ride_count"
        }

        dbtemp = requests.post('http://0.0.0.0:9998/api/v1/db/read', json=json_data)
        
        retvaltemp = dbtemp.json()
        
        retval = list()
        retval.append(retvaltemp['0'])
        return jsonify(retval), 200
            
    except:
        return Response(status=400, mimetype='application/json')

# ------------------------------------------------------------------------------------------------------------------------------------------
# ------------------------------------------------------------------------------------------------------------------------------------------

if __name__ == '__main__':	
	application.debug=True
	application.run()
