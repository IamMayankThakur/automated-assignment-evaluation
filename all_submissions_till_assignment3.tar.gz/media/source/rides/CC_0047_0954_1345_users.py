import flask
from flask import *
from flask import Flask
from flaskext.mysql import MySQL
import mysql.connector
import json
import requests
import re
import csv

counter = [0]
read_api = "http://127.0.0.1:5000/api/v1/db/read"
write_api = "http://127.0.0.1:5000/api/v1/db/write"

app = Flask(__name__)
conn = mysql.connector.connect(
  host="db",
  user="user",
  database="ride",
  password="password",
  
  port="3306"
)


cur =conn.cursor(buffered=True)
cur.execute("create table if not exists ride_info (ride_id int primary key auto_increment,created_by varchar(500),source varchar(500),destination varchar(500),timestamp varchar(500),riders varchar(6000))")
cur.execute("create table if not exists users (username varchar(600) primary key,password varchar(40))")

with open('AreaNameEnum.csv', mode='r') as infile:
    reader = csv.reader(infile)
    mydict = {rows[0]:rows[1] for rows in reader}

@app.before_request
def count_up():
	if request.path not in ('/','/api/v1/_count','/api/v1/db/read','/api/v1/db/write'):
		counter[0] = counter[0]+1

# Starting In Serial Order to Code The API

#API No.1 Add username and password
@app.route('/api/v1/users', methods = ["PUT"])
def add_user():
    """
    201: Created 
    400: Bad Request
    405: Method Not Allowed
    500: Internal Server Error
    """
    username = flask.request.json["username"]
    password = flask.request.json["password"]
    r=requests.post(url = read_api, json = {})
    resp = r.text
    resp=json.loads(resp)
    for i in resp:  #user already exists
        if(i[0] == username):
            return jsonify({}),400

    if not re.match("^[a-fA-F0-9]{40}$",password): #Password Not Hashed
        return '',400 

    data = {"insert":[username,password],"columns":["username","password"],"type":"create"}

    try:
        r=requests.post(url = write_api, json = data)
        return jsonify({}),201
    except:
        return '',500

#API No.2 Delete an existing user
@app.route('/api/v1/users/<username>', methods = ["DELETE"])
def delete_user(username):
    """
    200 : OK 
    400 : Bad Request
    405 : Method Not Allowed
    """
    r=requests.post(url = read_api, json = {})
    resp = r.text
    resp=json.loads(resp)
    print(resp)
    for i in resp:  #user exists
        if(i[0] == username):
            data = {"insert":username,"columns":"username","type":"delete"}
            r=requests.post(url = write_api, json = data)
            return jsonify({}),200 #User deleted Successfully
    return '',400 #User Not Present


#API No. 8 Write Database

@app.route('/api/v1/db/write', methods = ["POST"])
def write_to_db():
    insert = flask.request.json["insert"]
    columns = flask.request.json["columns"]
    if (flask.request.json["type"] == "create"):
        cur.execute("INSERT INTO users"+" ("+columns[0]+","+columns[1]+" )"+ " values (%s, %s)", (insert[0], insert[1]))
        conn.commit()
        return "success"

    elif (flask.request.json["type"] == "delete"):
        #print("DELETE FROM users WHERE username="+insert)
        cur.execute("DELETE FROM users WHERE username="+'\''+insert+'\'')
        conn.commit()
        return "success"
    else:
        abort(405)

#API No.9 Read Database

@app.route('/api/v1/db/read', methods = ["POST"])
def read_to_db():
	cur.execute("SELECT username FROM users")
	conn.commit()
	data = cur.fetchall()
	return jsonify(data)

#API No. 10 List all users

@app.route('/api/v1/users', methods = ["GET"])
def list_users():
    if(flask.request.method == "GET"):
        table = "users"
        cur.execute("SELECT username FROM "+table)
        conn.commit()
        data = cur.fetchall()
        res = []
        for i in data:
            res.append(i[0])
        data = jsonify(res)
        if (data == ''):
            return '',204
        else:
            return data,200
    else:
        return '',405

#API No. 11 Clear Database

@app.route('/api/v1/db/clear', methods = ["POST"])
def clear_db():
    cur.execute("SELECT * FROM users")
    conn.commit()
    data_users = cur.fetchall()
    cur.execute("SELECT * FROM ride_info")
    conn.commit()
    data_ride = cur.fetchall()
    if (data_users == [] and data_ride == []):
    	return '',400
    try:
        cur.execute("DELETE FROM ride_info")
        conn.commit()
        cur.execute("DELETE FROM users")
        conn.commit()
        return jsonify({}),200
    except:
        return '',500

#API No. 12 Count
@app.route('/api/v1/_count', methods = ["GET"])
def Count():
    try:
        return jsonify(counter),200
    except:
        return '',500


#API No. 13 ResetCount
@app.route('/api/v1/_count', methods = ["DELETE"])
def clear_count():
    try:
        counter[0] = 0
        return jsonify({}),200
    except:
        return '',500

if __name__ == '__main__':
    app.run(host="0.0.0.0",debug = True)
