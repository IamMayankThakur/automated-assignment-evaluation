from flask import Flask, render_template,\
jsonify,request,abort
import string, logging
import psycopg2
import pandas
import requests
from datetime import datetime
import json
def make_connection():
	#connection =-1
	try:
	    connection = psycopg2.connect(user = "postgres",
	                                  password = "postgres",
	                                  host = "rides_db",
	                                  port = "5432",
	                                  database = "cc_a1")
	    print("DEBUG: ", connection)
	    cursor = connection.cursor()

	except (Exception, psycopg2.Error) as error :
	    print ("Error while connecting to PostgreSQL", error)
	    abort(405)
	finally:
		return connection

app=Flask(__name__)

def create_tables():
	con = make_connection()
	cur = con.cursor()
	cur.execute("CREATE TABLE IF NOT EXISTS rides (ride_id int PRIMARY KEY NOT NULL, created_by varchar NOT NULL,timestamp varchar(19) NOT NULL, source int NOT NULL, dest int NOT NULL, other_users varchar NOT NULL);")
	cur.execute("CREATE TABLE IF NOT EXISTS user_ride(created_by varchar NOT NULL , ride_id int PRIMARY KEY NOT NULL);")
	#cur.execute("CREATE TABLE IF NOT EXISTS users(username varchar PRIMARY KEY NOT NULL, password varchar(40));")
	con.commit()
	cur.close()
	con.close()

def locExists(num):
	colnames = ['AreaNo', 'AreaName']
	data = pandas.read_csv('AreaNameEnum.csv', names=colnames)
	areas = data.AreaNo.tolist()
	if(num not in areas):
		return 0
	else:
		return 1

def update_count():
        f = open("total_req", "r")
        req_count= f.read()
        req_count= int(req_count.strip())
        req_count+=1
        f.close()
        w = open("total_req", "w")
        w.write(str(req_count))
        w.close()

@app.route("/api/v1/rides", methods=["POST"])
def create_ride():
	update_count()
	create_tables()
	username = request.get_json()["created_by"]
	timestamp = request.get_json()["timestamp"]


	#checking if timestamp is valid or not
	try:
		ts = datetime.strptime(timestamp,  "%d-%m-%Y:%S-%M-%H")
	except Exception as e:
		print("Incorrect format: ",e)
		abort(400)

	src = request.get_json()["source"]
	dst = request.get_json()["destination"]
	src = str(src).strip()
	dst = str(dst).strip()
	#check if user exists in table
	read_req = {"table": "users", "where" :"username='"+username+"'"}
	resp = requests.post(url ="http://34.236.49.252:80/api/v1/db/read", json = read_req)
	resp = resp.text
	resp = json.loads(resp)
	#non-existing user can't create a ride
	if(len(resp)==0):
		print("User doesn't exist")
		abort(400)

	#if source or dst is invalid, raise error
	elif(not(locExists(src)) or not(locExists(dst))):
		print("Area doesn't exist")
		abort(400)
	elif(src == dst):
		print("src = dst")
		abort(400)
	else:
		#persistent storage of ride_id
		#reading from DB each time and updating is too cumbersome
		f = open("ride_id.txt", "r")
		ride_id= f.read()
		ride_id = int(ride_id.strip())
		ride_id+=1
		f.close()
		w = open("ride_id.txt", "w")
		w.write(str(ride_id))
		w.close()

		#Creating request to insert into user_ride table
		insert_user_ride = {"insert": [username,ride_id], "table": "user_ride"}
		insert(insert_user_ride)

		#Creating request to insert into rides table
		insert_ride = {"insert": [ride_id, username, timestamp, src, dst, username], "table": "rides"}
		insert(insert_ride)
		return '',201


@app.route("/api/v1/rides",methods=["GET"])
def ride_listing():
	update_count()
	create_tables()
	src = request.args.get('source')
	dst = request.args.get('destination')
	
	if(src == dst):
		print("src=dst")
		abort(400)
	#if source or dst is invalid, raise error
	if(not(locExists(src)) or not(locExists(dst))):
		print("Area doesn't exist")
		abort(400)
	where_clause = "rides.source = "+src +"AND rides.dest = "+dst
	ride_listing_q = {"table": "rides", "where" :where_clause}
	#print(src,dst)
	listing = read(ride_listing_q)
	print(listing)
	if listing==0:
		return jsonify([]),204
		#abort(400)
	else:
		master =[]
		#print(listing)
		for rec in listing:
			slave ={}
			ts = datetime.strptime(rec[2],  "%d-%m-%Y:%S-%M-%H")
			today = datetime.today()
			if(ts > today):
				slave["rideId"] = rec[0]
				slave["username"] = rec[1]
				slave["timestamp"] = rec[2]
				master.append(slave)
			else:
				continue

		return jsonify(master), 200


@app.route('/api/v1/rides/<rideId>',methods=["GET"])
def ride_deets(rideId):
	update_count()
	create_tables()
	#Creating request with rideId
	ride_Id = int(rideId)
	print(ride_Id)
	ride_deets_q = {"table": "rides", "where":"rides.ride_id="+str(ride_Id)}
	deets = read(ride_deets_q)

	if(deets ==0):
		print("Ride Id doesnt exist")
		return '',204
		#abort(400)

	users = deets[0][5]
	user_list = users.split(",")
	for i in range (0,len(user_list)):
		if(user_list[i]== ''):
			del user_list[i]
	print(user_list)
	master = {"rideId" : deets[0][0],"Created_by" : deets[0][1], "users": user_list, "Timestamp: ": deets[0][2], 
	"source": int(deets[0][3]), "destination": int(deets[0][4])}
	return jsonify(master)


@app.route('/api/v1/rides/<rideId>',methods=["POST"])
def join_ride(rideId):
	update_count()
	create_tables()
	username = request.get_json()["username"]
	ride_Id = int(rideId)
	ride_deets_q = {"table": "rides", "where":"rides.ride_id="+str(ride_Id)}
	deets = read(ride_deets_q)

	#rideId doesn't exist
	if(deets ==0):
		print("Ride Id doesnt exist")
		return '',204
		#abort(400) #double check

	#First check if specified user exists or not
	read_req = {"table": "users", "where" :"username='"+username+"'"}
	resp = requests.post(url ="http://34.236.49.252:80/api/v1/db/read", json = read_req)
	resp = resp.text
	resp = json.loads(resp)
	if(len(resp)==0):
		print("Can't add user because he doesnt exist")
		abort(400)

	users = deets[0][5]
	created_by = deets[0][1]
	timestamp = deets[0][2]
	src = deets[0][3]
	dst = deets[0][4]
	if(username in users.split(',')):
		print("Same user can't join ride twice")
		abort(400)


	#finally do the honours
	users = users + username
	try:
		#first delete ride
		del_ride = "DELETE FROM rides WHERE ride_id = %s"
		connection = make_connection()
		cursor = connection.cursor()
		cursor.execute(del_ride, (ride_Id,))
		connection.commit()
		cursor.close()
		connection.close()
		#insert row again with new appended user
		insert_ride = {"insert": [ride_Id, created_by, timestamp, src, dst, users], "table": "rides"}
		insert(insert_ride)
		return '',200
	except (Exception, psycopg2.Error) as error:
		print("Error in Delete operation", error)
		abort(405) #not sure about this
@app.route("/api/v1/_count", methods=["GET"])
def req_count():
	f = open("total_req", "r")
	req_count= f.read()
	req_count = int(req_count.strip())
	f.close()
	l=[]
	l.append(req_count)
	return jsonify(l),200

@app.route("/api/v1/_count", methods=["DELETE"])
def reset_count():
	w = open("total_req", "w")
	w.write('0')
	w.close()
	return '',200


@app.route('/api/v1/rides/<rideId>',methods=["DELETE"])
def delete_ride(rideId):
	ride_Id = int(rideId)
	ride_deets_q = {"table": "rides", "where":"rides.ride_id="+str(ride_Id)}
	deets = read(ride_deets_q)

	#rideId doesn't exist
	if(deets ==0):
		print("Ride Id doesnt exist")
		abort(400) #double check

	try:
		#first delete ride
		del_ride1 = "DELETE FROM rides WHERE ride_id = %s"
		del_ride2 = "DELETE FROM user_ride WHERE ride_id = %s"
		connection = make_connection()
		cursor = connection.cursor()
		cursor.execute(del_ride1, (ride_Id,))
		cursor.execute(del_ride2, (ride_Id,))
		connection.commit()

		cursor.close()
		connection.close()
		return '',200

	except (Exception, psycopg2.Error) as error:
		print("Error in Delete operation", error)
		abort(405) #not sure about this


@app.route("/api/v1/db/write", methods=["POST"])
def insert(req):
	table= req["table"]
	connection = make_connection()
	cursor = connection.cursor()
	try:
		if(table == "user_ride"):
			print("HERE")
			username = req["insert"][0]
			ride_id = int(req["insert"][1])
			insert_user_ride = "INSERT INTO user_ride (created_by, ride_id) VALUES (%s,%s)"
			record = (username, ride_id)
			cursor.execute(insert_user_ride, record)
			connection.commit()

			#Logging message
			count = cursor.rowcount
			print (count, "Record inserted successfully into user_ride table")

		elif(table == "rides"):
			#for table rides
			ride_id = req["insert"][0]
			created_by = req["insert"][1]
			ts = req["insert"][2]
			src = int(req["insert"][3])
			dst = int(req["insert"][4])
			other_user = req["insert"][5]

			print(ride_id,created_by, ts, src, dst, other_user)
			check_ride_req= {"table": "rides", "where" :"ride_id='"+str(ride_id)+"'"}
			resp = read(check_ride_req)
			print("Resp: ", resp)
			if(resp == 0):
				insert_ride = "INSERT INTO rides (ride_id, created_by, timestamp, source, dest, other_users) VALUES (%s,%s,%s,%s,%s,%s)"
				record = (ride_id, created_by, ts, src, dst, other_user+',')
				cursor.execute(insert_ride, record)
				connection.commit()
			else:
				others = resp[0][5]
				others = others + other_user +','
				insert_ride = "INSERT INTO rides (ride_id, created_by, timestamp, source, dest, other_users) VALUES (%s,%s,%s,%s,%s,%s)"
				record = (ride_id, created_by, ts, src, dst, others)
		else:
			abort(405)

	except(Exception, psycopg2.Error) as error:
		if(connection):
			print("Failed to insert record", error)
			abort(405)
	finally:
		if(connection and cursor):
			cursor.close()
			connection.close()	



@app.route("/api/v1/db/read", methods=["POST"])
def read(req):
	connection = make_connection()
	cursor = connection.cursor()
	try:
		table= req["table"]
		ret = -1

		
		where = req["where"]
		q = "SELECT * FROM "+ table+" WHERE " + where
		cursor.execute(q)
		rec = cursor.fetchall()
		cursor.close()
		connection.close()
		print("table = ", table,"Rec: ",rec)
		if(len(rec)==0):
			print("Record Doesn't exist")
			return 0
		else:
			return rec

	except(Exception, psycopg2.Error) as error:
		if(connection):
			print("Failed to read record", error)
			abort(405)
	finally:
		if(connection and cursor):
			cursor.close()
			connection.close()
@app.route("/api/v1/db/clear", methods=["POST"])
def clear_db():
	try:
		#del1 = "DELETE FROM users"
		del2 = "DELETE FROM rides"
		del3 = "DELETE FROM user_ride"
		connection = make_connection()
		cursor3 = connection.cursor()
		


		cursor3.execute(del2)
		connection.commit()


		cursor3.execute(del3)
		connection.commit()


		cursor3.close()
		connection.close()
		return '',200
	except (Exception, psycopg2.Error) as error:
		print("Error in Delete operation", error)

if __name__ == '__main__':
	app.debug=True
	app.run(host='0.0.0.0', debug=True, port=80)
	app.run()