from flask import Flask, render_template, request, abort
import json
import pandas as pd
from datetime import datetime
from pymongo import MongoClient
import re
import requests

"""LOCAL TESINTG"""
# client = MongoClient('localhost', 27017)
# now = datetime.now()
# current_time = now
# # db init
# db = client.testdb  # connecting to the database
# collection_users = db.users  # connecting to the collection users
# collection_rides = db.rides  # connecting to the collection users


"""GLOBAL TESINTG"""
users_client = MongoClient("mongodb://users_mongodb:9996/")
rides_client = MongoClient("mongodb://rides_mongodb:9997/")

now = datetime.now()
current_time = now
# current_time = now.strftime("%d-%m-%Y:%S-%M-%H") #use this to get time

# db init
users_db = users_client.users_db  # connecting to the users database
collection_users = users_db.users  # connecting to the collection users

rides_db = rides_client.rides_db  # connecting to the rides database
collection_rides = rides_db.rides  # connecting to the collection users


app = Flask(__name__)

"""

    Note: Whenever there is a read/write/delete operation: just call read() or write() or delete() in the 
    following format :

    READ FORMAT
    >> api_data =
    {
    “table”: “collectionsname”,
    “columns”: [“attributenames",], -------> set this as None if u want all the attributes
    “where”: {"attribute":"value”} ----> set this as {} if u want all the rides
    }
    >> read_db(api_data)

    OR

    WRITE FORMAT
    >> api_data = 
    {
    “insert” : <data>,  -----> data will be either a users or rides dictionary with the respective attribute values you want to insert/update
    “table” : “collections_into_which_you_wanna_insert”
    "status" : "delete"/"update"/"insert" -----> depending on whether it is a delete operation or update.
    }
    >> write_db(api_data)

"""

# data structures
# just an instance. this will keep getting overwritten.
users_data = {
    "username": None,
    "password": None,
    "user_status": None  # valid/invalid
}

rides_data = {
    "rideId": None,  # shreya/drasti I need to have a word about this with you
    "created_by": None,
    "timestamp": None,  # NOT current_time , defined at the top.
    "source": None,
    "destination": None,
    "riders": [],  # will be a list to which you need to append to.
    "ride_status": None  # upcomming/completed/deleted
}

# def refresh_database():
#     #here we just get all the records in the rides db and then update it.

#     api_data = {
#     "table": "rides",
#     "columns": None,
#     "where": {"ride_status":"upcoming"} #valid/invalid username checking will happen in the readdb service.
#     }
#     # data_retrieved = read_db(api_data)
#     URL = "http://127.0.0.1:8000/api/v1/db/read"
#     data_retrieved = json.loads(requests.post(URL,json=json.dumps(api_data)).content)

#     collection_handler = collection_rides
#     # data_retrieved  = collection_handler.find({"ride_status":"upcoming"},{"_id":0})
#     try:
#         for i in data_retrieved:
#             temp_time = datetime.strptime(i["timestamp"],r"%d-%m-%Y:%S-%M-%H")
#             print("[INFO]:TEMP TIME IS ===",temp_time)
#             if(temp_time < current_time):
#                 # i["ride_status"] = "completed"
#                 # newvalues = { "$set": i }
#                 # collection_handler.update_one({"rideId": i["rideId"]}, newvalues)
#                 #replacing it with API calls
#                 api_data = {
#                     "insert" : {"rideId" : i["rideId"],"ride_status":"completed"},
#                     "table" : "rides",
#                     "status": "update"
#                 }

#                 URL = "http://127.0.0.1:8000/api/v1/db/write"
#                 requests.post(URL,json=json.dumps(api_data))

#     except Exception as e:
#         print(e)
#         pass


@app.route("/")
def main():
    return "Rides Container. Wonderful, it works."


# http requets APIs
@app.route("/api/v1/_count", methods=["GET"])
def returnCountOfRequests():
    # countRequests()
    # reading the config file to check which rideId to assign next
    try:
        filee = open("config.json", "r+")
        data_read = json.loads(filee.read())
        filee.close()
        return_data = list()
        return_data.append(data_read["httpRequests"])
        return(json.dumps(return_data))
    except:
        abort(405)
        return "error opening the configuration file, this message is just for testing purposes"


def countRequests():
    # reading the config file to check which rideId to assign next
    try:
        filee = open("config.json", "r+")
        data_read = json.loads(filee.read())
        data_read["httpRequests"] = data_read["httpRequests"] + 1
        filee.seek(0)
        filee.write(json.dumps(data_read))
        filee.truncate()
        filee.close()
    except:
        abort(405)
        return "error opening the configuration file, this message is just for testing purposes"


@app.route("/api/v1/_count", methods=["DELETE"])
def deleteCountOfRequests():
    # countRequests()
    # reading the config file to check which rideId to assign next
    try:
        filee = open("config.json", "r+")
        data_read = json.loads(filee.read())
        data_read["httpRequests"] = 0
        filee.seek(0)
        filee.write(json.dumps(data_read))
        filee.truncate()
        filee.close()
        return {}, 200
    except:
        abort(405)
        return "error opening the configuration file, this message is just for testing purposes"


# "rides" collections functions
@app.route("/api/v1/rides/count", methods=["GET"])
def getCountRides():
    # countRequests()
    print("[INFO]:GET NUMBER OF RIDES FUNCTION EXECUTED")
    api_data = {
        "table": "rides",
        "columns": None,
        # valid/invalid username checking will happen in the readdb service.
        "where": {}
    }
    # data_retrieved = read_db(api_data)
    URL = "http://127.0.0.1:8000/api/v1/db/read"
    data_retrieved = json.loads(requests.post(
        URL, json=json.dumps(api_data)).content)
    ridesCount = list()
    ridesCount.append(len(data_retrieved))
    return json.dumps(ridesCount), 200


@app.route("/api/v1/rides", methods=["PUT"])
def error():
    countRequests()
    abort(405)

@app.route("/api/v1/rides", methods=["POST"])
def create_ride():
    countRequests()
    print("[INFO]:CREATE RIDE FUNCTION EXECUTED")
    # refresh database: converting upcoming to completed for rides whose timestamp is less than current timestamp
    refresh_database()

    # GOING TO ASSUME , SOURCE AND DESTINATION ARE STRING(NUMBERS)
    df = pd.read_csv("AreaNameEnum.csv")
    try:
        data = request.get_json()
        created_by = request.get_json()["created_by"]
        timestamp = request.get_json()["timestamp"]
        source = request.get_json()["source"]
        destination = request.get_json()["destination"]
    except:
        abort(400)

    if not (re.match("^([0-2][0-9]|(3)[0-1])(-)(((0)[0-9])|((1)[0-2]))(-)\d{4}(:)\d{2}(-)\d{2}(-)\d{2}$", timestamp)):
        abort(400)

    try:
        timestamp_obj = datetime.strptime(timestamp, "%d-%m-%Y:%S-%M-%H")
    except:
        abort(400)

    if(timestamp_obj < current_time):
        abort(400)

    # ASSUMING SOURCE AND DESTINATION ARE STRING(INT)
    # #replace source and destination with their respective numbers
    try:
        source_number = df.loc[df["Area No"] == int(source), "Area No"].iloc[0]
        destination_number = df.loc[df["Area No"]
                                    == int(destination), "Area No"].iloc[0]
    except:
        abort(400)

    if(source == destination):
        abort(400)

    api_data = {
        "table": "users",
        "columns": None,
        "where": {"username": created_by}
    }

    # URL = "http://127.0.0.1:8000/api/v1/db/read"
    # returned_value = json.loads(requests.post(URL,json=json.dumps(api_data)).content)
    # if(len(returned_value)==0):
    #     #just returning while checking
    #     abort(400)
    #     return "username doesn't exist"

    # MAKING THE API CALL TO GET ALL USERS
    URL = "http://cloudcomputing-745475681.us-east-1.elb.amazonaws.com/api/v1/users"
    headers = {"Origin": "52.86.159.3"}
    object_returned = json.loads(requests.get(URL, headers=headers).content)
    if(created_by not in object_returned):
        abort(400)

    # reading the config file to check which rideId to assign next
    try:
        filee = open("config.json", "r+")
        data_read = json.loads(filee.read())
        data_read["rideId"] = data_read["rideId"] + 1
        filee.seek(0)
        filee.write(json.dumps(data_read))
        filee.truncate()
        filee.close()
    except:
        abort(400)
        return "error opening the configuration file, this message is just for testing purposes"

    rides_data = {
        # this needs to be autoincremented and it will be as it is read from the configuration file
        "rideId": data_read["rideId"],
        "created_by": created_by,  # remember to fix

        "timestamp": timestamp,  # defined at the top.
        "source": source,
        "destination": destination,
        # will be a list to which you need to append to.
        "riders": [created_by],
        "ride_status": "upcoming"
    }

    api_data = {
        "insert": rides_data,
        "table": "rides",
        "status": "insert"
    }

    URL = "http://127.0.0.1:8000/api/v1/db/write"
    requests.post(URL, json=json.dumps(api_data))

    return {}, 201


@app.route("/api/v1/rides", methods=["GET"])
def list_allrides():
    countRequests()
    print("[INFO]:LIST ALL RIDES FUNCTION EXECUTED")
    try:
        source = request.args.get('source')
        destination = request.args.get('destination')
    except:
        abort(400)

    # refresh database: converting upcoming to completed for rides whose timestamp is less than current timestamp
    refresh_database()

    df = pd.read_csv("AreaNameEnum.csv")

    # ASSUMING SOURCE AND DESTINATION ARE STRING(INT)
    # #replace source and destination with their respective numbers
    try:
        source_number = df.loc[df["Area No"] == int(source), "Area No"].iloc[0]
        destination_number = df.loc[df["Area No"]
                                    == int(destination), "Area No"].iloc[0]
    except:
        # return "WRONG ADDRESS"
        abort(400)

    api_data = {
        "table": "rides",
        "columns": None,
        "where": {"source": source,
                  "destination": destination
                  }
    }

    URL = "http://127.0.0.1:8000/api/v1/db/read"
    data_retrieved = json.loads(requests.post(
        URL, json=json.dumps(api_data)).content)
    for i in data_retrieved:
        i.pop("ride_status")  # we do not need to display that
        i.pop("source")
        i.pop("destination")
        i.pop("riders")
        i["username"] = i.pop("created_by")

    cpy_data = list(data_retrieved)
    if(len(cpy_data) == 0):
        return "", 204
    else:
        return json.dumps(data_retrieved), 200


@app.route("/api/v1/rides/<int:rideId>", methods=["GET"])
def list_specefic(rideId=None):
    countRequests()
    print("[INFO]:LIST SPECIFIC RIDE FUNCTION EXECUTED")

    # refresh database: converting upcoming to completed for rides whose timestamp is less than current timestamp
    refresh_database()

    if(rideId == None):
        abort(400)  # means data was not sent properly

    # assuming an alpha-numeric rideId, hence string
    api_data = {
        "table": "rides",
        "columns": None,
        "where": {"rideId": rideId}
    }

    URL = "http://127.0.0.1:8000/api/v1/db/read"
    data_retrieved = json.loads(requests.post(
        URL, json=json.dumps(api_data)).content)
    if(len(data_retrieved) == 0):
        abort(400)
        return "rideId doesn't exist"

    # hopefully this list conversion workds properly
    cpy_data = list(data_retrieved)
    if(len(cpy_data) == 0):
        return "", 204
    else:
        # of the form {} ; returning just the 0th element as that will be the only dictionary
        return json.dumps(data_retrieved[0]), 200


@app.route("/api/v1/rides/<int:rideId>", methods=["POST"])
def join_existing(rideId=None):
    countRequests()
    print("[INFO]:JOIN EXISTING RIDE FUNCTION EXECUTED")
    if(rideId == None):
        abort(400)
    try:
        username = request.get_json()["username"]
    except:
        abort(400)

    refresh_database()

    # first we need to check if this username is a valid username or not
    api_data = {
        "table": "users",
        "columns": None,
        "where": {"username": username}
    }

    URL = "http://127.0.0.1:8000/api/v1/db/read"
    data_retrieved = json.loads(requests.post(
        URL, json=json.dumps(api_data)).content)
    if(len(data_retrieved) == 0):
        abort(400)
        return "username doesn't exist"

    """uncomment the following lines at the end"""
    # elif(len(data_retrieved)>1):
    # possibly some kind of data corruption in the users collection
    # uncomment it all at the end
    # abort(500)

    # now we need to check if the rideId exists
    api_data = {
        "table": "rides",
        "columns": None,
        "where": {"rideId": rideId}
    }

    URL = "http://127.0.0.1:8000/api/v1/db/read"
    data_retrieved = json.loads(requests.post(
        URL, json=json.dumps(api_data)).content)
    if(len(data_retrieved) == 0):
        abort(400)
        return "rideId doesn't exist"

    # assuming all the checks are done and everyhting is valid, lets proceed with the update

    api_data = {
        # rideId cannot be updated, but will be used to find that specefic document
        "insert": {"rideId": rideId, "riders": username},
        "table": "rides",
        "status": "update"
    }

    URL = "http://127.0.0.1:8000/api/v1/db/write"
    requests.post(URL, json=json.dumps(api_data))
    return {}, 200


@app.route("/api/v1/rides/<int:rideId>", methods=["DELETE"])
def delete_ride(rideId=None):
    countRequests()
    print("[INFO]:DELETE RIDE FUNCTION EXECUTED")
    if(rideId == None):
        abort(400)

    refresh_database()

    # now we need to check if the rideId exists
    api_data = {
        "table": "rides",
        "columns": None,
        "where": {"rideId": rideId}
    }
    URL = "http://127.0.0.1:8000/api/v1/db/read"
    data_retrieved = json.loads(requests.post(
        URL, json=json.dumps(api_data)).content)

    if(len(data_retrieved) == 0):
        # return "rideId doesn't exist"
        abort(400)

    api_data = {
        # rideId will be used to delete that document
        "insert": {"rideId": rideId},
        "table": "rides",
        "status": "delete"
    }

    URL = "http://127.0.0.1:8000/api/v1/db/write"
    requests.post(URL, json=json.dumps(api_data))
    # return "deletion done"
    # if(write_db(api_data)):
    return {}, 200


"""
NOte:

1.Ishwar will code the read_db and write_db functions. Just pick a function, discuss on the group
and code your part. Call the read_db and write_db functions properly.

2.read_db() will always return a list of user/rides dictionaries. It can be a single mongoDB document in the form
[{}] or many matching documents of the form [{},{},{},{}]

3. Do not fuck up the write operations. Set the _status variables properly.

4. Return the dictionaries properly from your functions. call
>> return json.dumps(your_return_dictionary)

5. Don't be a dumbass by sharing this template with others. #obviously

6. Write proper comments. 

"""
@app.route("/api/v1/db/read", methods=["POST"])
def read_db():
    print("[INFO]:READ DB FUNCTION EXECUTED")
    """
    READ FORMAT
    >> api_data =
    {
    “table”: “collectionsname”,
    “columns”: [“attributenames",], -------> set this as None if u want all the attributes
    “where”: {"attribute"="value”} ----> set this as None if u want all the rides
    }
    so this is the incomming data ; for now let's just code assuming columns=None and we return all values
    """
    try:
        dictionary_data = {}
        print("IN THE READ DB FUNCTION", request.get_json())
        dictionary_data["table"] = json.loads(request.get_json())["table"]
        print(dictionary_data["table"])
        dictionary_data["columns"] = json.loads(request.get_json())["columns"]
        print(dictionary_data["columns"])
        dictionary_data["where"] = json.loads(request.get_json())["where"]
        print(dictionary_data["where"])

    except:
        abort(500)
        pass

    # first we need to figure out which collection we need to append to
    # defining a collection handler
    if(dictionary_data["table"] == "users"):
        collection_handler = collection_users
        doc = "user_status"
        document_status = "valid"
    elif(dictionary_data["table"] == "rides"):
        collection_handler = collection_rides
        doc = "ride_status"
        document_status = "upcoming"

    # if(dictionary_data["columns"]==None): #getting all the attributes
    print("[INFO]: CONSTRAINT CHECKING", dictionary_data["where"])
    dictionary_data["where"][doc] = document_status
    print("WHERE STATUS: ", dictionary_data["where"])
    data_retrieved = collection_handler.find(
        dictionary_data["where"], {"_id": 0})
    return json.dumps(list(data_retrieved))  # [{}] format


@app.route("/api/v1/db/write", methods=["POST"])
def write_db():
    print("[INFO]:WRITE DB FUNCTION EXECUTED")
    """
    recieved
    api_data = {
            "insert" : rides_data,
            "table" : "rides",
            "status": "insert"
        } incomming data format , where rides_data is the record we need to insert
    """
    # first we need to figure out which collection we need to append to
    # defining a collection handler
    try:
        dictionary_data = {}
        print("IN THE READ DB FUNCTION", request.get_json())
        dictionary_data["insert"] = json.loads(request.get_json())["insert"]
        print(dictionary_data["insert"])
        dictionary_data["table"] = json.loads(request.get_json())["table"]
        print(dictionary_data["table"])
        dictionary_data["status"] = json.loads(request.get_json())["status"]
        print(dictionary_data["status"])

    except:
        abort(500)
        pass

    if(dictionary_data["table"] == "users"):
        collection_handler = collection_users
    elif(dictionary_data["table"] == "rides"):
        collection_handler = collection_rides

    # now we need to check the status and see what kind of write is being requested for
    write_type = dictionary_data["status"]

    if write_type == "insert":
        collection_handler.insert_one(dictionary_data["insert"])

    elif write_type == "update":

        # {"rideId" : rideId, "riders":username}
        temp = dictionary_data["insert"]
        print("[INFO]:UPDATE FUNCTION")
        myquery = {"rideId": temp["rideId"]}
        # using myquery, lets first get the record of that particular rideId
        # we need to set api_data again
        api_data = {
            "table": "rides",
            "columns": None,
            "where": {"rideId": temp["rideId"]}
        }

        URL = "http://127.0.0.1:8000/api/v1/db/read"
        retrieved_record = json.loads(requests.post(
            URL, json=json.dumps(api_data)).content)

        if(len(retrieved_record) != 1):  # should recieve only one unique row
            abort(500)
        else:
            # coz the return is in the form of a list
            retrieved_record = retrieved_record[0]
            # now lets update this retrieved record with the new values
            # the following part is hardcoded. #need to fix this in future iterations.
            for key in temp.keys():
                if(key != "rideId" and key != "riders"):
                    # replacing all the old values with the new values #need a for loop to replace every key value pair
                    retrieved_record[key] = temp[key]
                elif(key == "riders"):
                    retrieved_record[key].append(temp[key])
                    retrieved_record[key] = list(set(retrieved_record[key]))
            # once this is done, we need to write "retireved_record" back into the mongo db
            newvalues = {"$set": retrieved_record}
            # find the document with myquery and update it with the newvalues
            collection_handler.update_one(myquery, newvalues)

    elif write_type == "delete":
        print("[INFO]:UPDATE FUNCTION")
        # here we need to find that particular record and not delete it, but just set the rides status or the user status to deleted/invalid
        if(dictionary_data["table"] == "users"):
            document_status = "invlaid"
            set_table = "users"
        else:  # if it is rides
            document_status = "deleted"
            set_table = "rides"

        # {"rideId" : rideId} or ("username":username)
        temp = dictionary_data["insert"]
        myquery = temp

        api_data = {
            "table": set_table,
            "columns": None,
            "where": temp
        }
        URL = "http://127.0.0.1:8000/api/v1/db/read"
        retrieved_record = json.loads(requests.post(
            URL, json=json.dumps(api_data)).content)

        if(len(retrieved_record) != 1):
            abort(500)
        else:
            retrieved_record = retrieved_record[0]
            # coz the return is in the form of a list
            # now lets update this retrieved record with the new values
            # set_table[-1] = ride/user + "_status"
            newvalues = {"$set": {set_table[:-1]+"_status": document_status}}
            # find the document with myquery and update it with the newvalues
            collection_handler.update_one(myquery, newvalues)

    return True


@app.route("/api/v1/db/clear", methods=["POST"])
def clear_db():
    countRequests()
    rides_client.drop_database("rides_db")
    return {}, 200


if __name__ == "__main__":
    app.run(host='0.0.0.0', debug=True, port=8000)
