import os
import time
import json
import requests
import re
import csv
import logging
from flask import Flask, request, jsonify, redirect, url_for, Response
from pymongo import MongoClient
from random import randint
from datetime import datetime

app = Flask(__name__)
username = os.environ.get("MONGO_INITDB_ROOT_USERNAME")
password = os.environ.get("MONGO_INITDB_ROOT_PASSWORD")
client = MongoClient(
    "mongodb://mongodb2:27017",
    username=username,
    password=password
)
db = client.testdb

#@cross_origin()
def db_api(key, database, collection, mode):
    key_string = json.dumps(key)
    if database == "rides":
        if collection == "rides":
            if mode == "read":
                json_string = {'query' : key_string, 'database' : database, 'collection' : collection}
                jstring = json.dumps(json_string)
                r = requests.post("http://52.86.121.173/api/v1/db/read/", json=jstring)
                return r
            else:
                json_string = {'query' : key_string, 'database' : database, 'collection' : collection, "mode" : mode}
                jstring = json.dumps(json_string)
                r = requests.post("http://52.86.121.173/api/v1/db/write/", json=jstring)
                return r
        elif collection == "id":
            if mode == "read":
                json_string = {'query' : key_string, 'database' : database, 'collection' : collection}
                jstring = json.dumps(json_string)
                r = requests.post("http://52.86.121.173/api/v1/db/read/", json=jstring)
                return r
            else:
                json_string = {'query' : key_string, 'database' : database, 'collection' : collection, "mode" : mode}
                jstring = json.dumps(json_string)
                #return str(jstring)
                r = requests.post("http://52.86.121.173/api/v1/db/write/", json=jstring)
                return r
    elif database == "count":
        if mode == "read":
            json_string = {'query' : key_string, 'database' : database, 'collection' : collection}
            jstring = json.dumps(json_string)
            r = requests.post("http://52.86.121.173/api/v1/db/read/", json=jstring)
            return r
        else:
            json_string = {'query' : key_string, 'database' : database, 'collection' : collection, "mode" : mode}
            jstring = json.dumps(json_string)
            r = requests.post("http://52.86.121.173/api/v1/db/write/", json=jstring)
            return r
    else:
        r = requests.get("http://rideshare-499100528.us-east-1.elb.amazonaws.com/api/v1/users", headers={'Origin': '52.86.121.173'})
        try:
            app.logger.debug(str(r.request.headers))
        except Exception as ee:
            pass
            #app.logger.debug(str(ee))
        return r


def count_ini():
    dbnames = client.list_database_names()
    if 'count' not in dbnames:
        cn = client.count.count.count_documents({})
        if cn == 0:
            db_api({'name':'count','count':'0'},"count","count","insert")
            return "201"
    return "400"


def req_count():
    count_ini()
    r = db_api({'name': 'count'},"count","count","read")
    try:
        count = int(r.text)
    except:
        count = 0
    count += 1
    r2 = db_api({'count' : str(count)},"count","count","update")
    return "200"


@app.route("/api/v1/rides/<rideId>", methods=['HEAD','PUT','CONNECT','OPTIONS','TRACE','PATCH'])
def add_user_to_ride_fallback(rideId):
    req_count()
    return Response("", status="405", mimetype="application/json")
#Function to add user to a ride.
@app.route("/api/v1/rides/<rideId>", methods=['POST'])
def add_user_to_ride(rideId):
    req_count()
    try:
        try:
            username = request.json["username"]
        except:
            return Response("", status="405", mimetype="application/json")

        u = db_api({},"users","users","read")

        if username in u.json():
            r = db_api({'rideId': int(rideId)},"rides","rides","read")

            if r.text == "400":
                return Response("", status="400", mimetype="application/json")

            else:
                ur = db_api({'rideId': int(rideId), "username": username},"rides","rides","update")
                if ur.text == "400":
                    return Response("", status="400", mimetype="application/json")
                return Response("{}", status="200", mimetype="application/json")
        
        else:
            return Response("", status="400", mimetype="application/json")
        
    except:
        return Response("", status="500", mimetype="application/json")


@app.route("/api/v1/rides", methods=['HEAD','DELETE','PUT','CONNECT','OPTIONS','TRACE','PATCH'])
def create_ride_fallback():
    req_count()
    return Response("", status="405", mimetype="application/json")
#Function to create a new ride.
@app.route("/api/v1/rides", methods=['POST'])
def create_ride():
    req_count()
    re = db_api({'name':'rideId','rideId':'1000'},"rides","id","insert")
    #return str(re)
    r = db_api({'name': 'rideId'},"rides","id","read")
    rideId = int(r.text)
    try:
        try:
            username = request.json["created_by"]
            timestamp = request.json["timestamp"]
            try:
                time.strptime(timestamp,"%d-%m-%Y:%S-%M-%H")
                #comment
                timestamp2 = str(datetime.now().replace(microsecond=0))
                t1 = datetime.strptime(timestamp, "%d-%m-%Y:%S-%M-%H")
                t2 = datetime.strptime(timestamp2, "%Y-%m-%d %H:%M:%S")
                if(t2>t1):
                    return Response ("",status=400, mimetype="application/json")
                #comment
            except:
                return Response ("",status=400, mimetype="application/json")
            source = request.json["source"]
            destination = request.json["destination"]
            if source == destination:
                return Response ("",status=400, mimetype="application/json")
            csv_data = []
            c1 = []
            try:
                with open('AreaNameEnum.csv', 'r') as f:
                  reader = csv.reader(f)
                  csv_data = list(reader)
                for ij in csv_data:
                    c1.append(int(ij[0]))
            except:
                return Response("", status="500", mimetype="application/json")

            if(int(source) in c1 and int(destination) in c1):
                pass
            else:
                return Response("", status="400", mimetype="application/json")
                
        except:
            return Response("", status="400", mimetype="application/json")
        u = db_api({},"users","users","read")
        #return(str(u.data))
        ##print(str(u.json()), file=sys.stderr)
        if username not in u.json():
            return Response("", status="400", mimetype="application/json")
        else:
            timestamp = int(datetime.strptime(timestamp, "%d-%m-%Y:%S-%M-%H").timestamp())
            insert = {'rideId' : int(rideId),'created_by' : username, 'users' : [], 'timestamp' : timestamp, 'source' : source, 'destination' : destination}
            try:
                r = db_api(insert,"rides","rides","insert")
                if r.json():
                    rideId += 1
                    r2 = db_api({'rideId' : str(rideId)},"rides","id","update")
                    if r2.text == "201":
                        return Response("{}", status="201", mimetype="application/json")
                    else:
                        return Response("", status="500", mimetype="application/json")                    
            except:
                return Response("", status="500", mimetype="application/json")        
    except:
        return Response("", status="500", mimetype="application/json")

@app.route("/api/v1/rides", methods=['HEAD','DELETE','PUT','CONNECT','OPTIONS','TRACE','PATCH'])
def show_rides_fallback():
    req_count()
    return Response("", status="405", mimetype="application/json")
#Function to show rides for a given source and destination.
@app.route("/api/v1/rides", methods=['GET'])
def show_rides():
    req_count()
    try:
        
        try:
            source = request.args['source']
            destination = request.args['destination']
        except:
            try:
                if(request.get_json()):
                    return Response("", status="405", mimetype="application/json")
            except:
                pass
            return Response("", status="400", mimetype="application/json")

        csv_data = []
        c1 = []
        try:
            with open('AreaNameEnum.csv', 'r') as f:
              reader = csv.reader(f)
              csv_data = list(reader)
            for ij in csv_data:
                c1.append(int(ij[0]))
        except:
            return Response("", status="500", mimetype="application/json")
        
        source = source.replace('"',"")
        destination = destination.replace('"',"")

        if(int(source) in c1 and int(destination) in c1):
            ride = db_api({'source' : source, 'destination' : destination, "timestamp": {"$gt": int(datetime.now().timestamp())}},"rides","rides","read")
        else:
            return Response("", status="400", mimetype="application/json")
            

        if ride.text == "400":
            return Response("", status="204", mimetype="application/json")
        return Response(ride.content, status="200", mimetype="application/json")
        
    except:
        return Response("", status="500", mimetype="application/json")


@app.route("/api/v1/rides/<rideId>", methods=['HEAD','PUT','CONNECT','OPTIONS','TRACE','PATCH'])
def ride_details_fallback(rideId):
    req_count()
    return Response("", status="405", mimetype="application/json")
#Function to list details of a given ride.
@app.route("/api/v1/rides/<rideId>", methods=['GET'])
def ride_details(rideId):
    req_count()
    try:

        r = db_api({'rideId': int(rideId)},"rides","rides","read")

        if r.text == "400":
            return Response("", status="204", mimetype="application/json")
            
        else:
            return Response(r.content, status="200", mimetype="application/json")
                    
    except:
        return Response("", status="500", mimetype="application/json")


@app.route("/api/v1/rides/<rideId>", methods=['GET','HEAD','POST','PUT','CONNECT','OPTIONS','TRACE','PATCH'])
def delete_ride_fallback(rideId):
    req_count()
    return Response("", status="405", mimetype="application/json")
#Function to delete rides.
@app.route("/api/v1/rides/<rideId>", methods=['DELETE'])
def delete_ride(rideId):
    req_count()
    try:
        r = db_api({'rideId': int(rideId)},"rides","rides","read")
        if r.text != "400":
            db_api({'rideId': int(rideId)},"rides","rides","delete")
            return Response("{}", status="200", mimetype="application/json")
        else:
            return Response("", status="405", mimetype="application/json")        
    except:
        return Response("", status="500", mimetype="application/json")

#Function to write to the DB.
@app.route("/api/v1/db/write/", methods=['POST'])
def write_db():
    r_db = client.rides
    r_col = r_db.rides
    ridesIdcol = r_db.id

    u_db = client.users
    u_col = u_db.users

    c_db = client.count
    c_count = c_db.count

    try:

        try:
            ins = request.json
            insert_data = json.loads(ins)

            query = json.loads(insert_data["query"])
            collection = insert_data["collection"]
            database = insert_data["database"]
            mode = insert_data["mode"]

        except:
            return Response("", status="400", mimetype="application/json")
        ##print(mode, database)
        if mode == "insert":
            if database == "rides":
                if collection == "rides":
                    ride_id = r_col.insert(query)
                    find = r_col.find_one({'_id' : ride_id})
                    output = {'created_by' : find['created_by'], 'rideId' : find['rideId'], 'users' : find['users'], 'timestamp' : find['timestamp'], 'source' : find['source'], 'destination' : find['destination']}
                    return jsonify({'result' : output})

                else:
                    if collection == "id":
                        i = ridesIdcol.find_one({'name': 'rideId'})
                        if i:
                            return "200"
                        else:
                            ridesIdcol.insert(query)
                            return "200"
            
            elif database == "users":
                user_id = u_col.insert(query)
                new_user = u_col.find_one({'_id' : user_id})
                output = {'username' : new_user['username'], 'password' : new_user['password']}
                return jsonify(output)
            
            elif database == "count":
                count_id = c_count.insert(query)
                ###print(count_id)
                return "201"

        elif mode == "update":
            
            if database == "rides":

                if collection == "rides":
                    ur = r_col.find_one({'rideId':query['rideId']})
                    if query['username'] in ur['users']:
                        return "400"
                    r_col.find_one_and_update({'rideId' : query['rideId']},{"$push": {"users": query['username']}})
                    return Response("", status="200", mimetype="application/json")
                
                else:
                    ridesIdcol.find_one_and_update({'name': 'rideId'},{"$set": {"rideId": str(query['rideId'])}})
                    return "201"

            elif database == "users":
                u_col.find_one_and_delete({'username' : query['username']})
                return "200"

            elif database == "count":
                c_count.find_one_and_update({'name': 'count'},{"$set": {"count": str(query['count'])}})
                return "201"    

        else:
            r_col.find_one_and_delete({'rideId' : query['rideId']})
            return "200"
    except:
        return Response("Service Unavailable", status="500", mimetype="application/json")

#Function to read from the DB.
@app.route("/api/v1/db/read/", methods=['POST'])
def read_db():
    r_db = client.rides
    r_col = r_db.rides
    ridesIdcol = r_db.id

    u_db = client.users
    u_col = u_db.users

    c_db = client.count
    c_count = c_db.count

    try:
    #if 1:
        try:
            read = request.json
            read_data = json.loads(read)

            query = json.loads(read_data['query'])
            collection = read_data["collection"]
            database = read_data["database"]

        except:
            return "400"

        if database == "rides":
            if collection == "rides":
                if 'rideId' in query:
                    find = r_col.find_one(query)
                    if find:
                        output = {'created_by' : find['created_by'], 'rideId' : find['rideId'], 'users' : find['users'], 'timestamp' : find['timestamp'], 'source' : find['source'], 'destination' : find['destination']}
                        output['timestamp'] = datetime.fromtimestamp(output['timestamp']).strftime("%d-%m-%Y:%S-%M-%H")
                        return jsonify(output)
                    else:
                        return "400"
                else:
                    ride = list(r_col.find(query))
                    output = []
                    for r in ride:
                        out = {"rideId":r['rideId'], "timestamp":r['timestamp'], "created_by":r['created_by']}
                        output.append(out)
                    if output:
                        for r_ in output: r_['timestamp'] = datetime.fromtimestamp(r_['timestamp']).strftime("%d-%m-%Y:%S-%M-%H")
                        return jsonify(output)
                    else:
                        return "400"

            elif collection == "id":
                    
                find = ridesIdcol.find_one(query)
                if find:
                    return find['rideId']
                else:
                    return "400"
            
        elif database == "users":
            if query:
                find = u_col.find_one(query)
                if find:
                    output = {'username' : find['username'], 'password' : find['password']}
                    return jsonify(output)
                else:
                    return "400"        
            else:
                find = u_col.find(query)
                output = []
                if find:
                    for i in find:
                        ###print(i)
                        out = i['username']
                        output.append(out)
                    return jsonify(output)
                return "400"  

        elif database == "count":
            find = c_count.find_one()
            ##print(find['count'])
            if find:
                ##print("lol")
                return find['count']
            else:
                return "400"
        
    except Exception as ert:
        ##print(str(ert))
        return Response("", status="500", mimetype="application/json")


#Function to clear the DB.#200 400 405
@app.route("/api/v1/db/clear", methods=['POST'])
def drop_db():
    try:
        client.drop_database("rides")
        client.drop_database("id")
        return Response("{}", status="200", mimetype="application/json")
    except:
        return Response("", status="400", mimetype="application/json")


@app.route("/api/v1/_count", methods=['GET'])
def get_count():
    try:
        count_ini()
        r = db_api({'name': 'count'},"count","count","read")
        try:
            r = int(r.text)
        except:
            r = 0
    except Exception as e:
        return Response("", status="400", mimetype="application/json")

    r = "["+str(r)+"]"

    return Response(r, status="200", mimetype="application/json")


@app.route("/api/v1/_count", methods=['DELETE'])
def clear_count():
    try:
        count_ini()
        r = db_api({'count' : "0"},"count","count","update")
    except:
        return Response("", status="400", mimetype="application/json")

    return Response("", status="200", mimetype="application/json")


@app.route("/api/v1/rides/count", methods=['HEAD','DELETE','POST','PUT','CONNECT','OPTIONS','TRACE','PATCH'])
def count_rides_fallback():
    req_count()
    return Response("", status="405", mimetype="application/json")
@app.route("/api/v1/rides/count", methods=['GET'])
def count_rides():
    req_count()
    try:
        r = db_api({},"rides","rides","read")
        if r.text != "400":
            item_dict = json.loads(r.content)
            res = len(item_dict)
            res = "["+str(res)+"]"
            return Response(res, status="200", mimetype="application/json")
        else:
            return Response("", status="400", mimetype="application/json")        
    except:
        return Response("", status="500", mimetype="application/json")



#@app.before_first_request
#def before_first_request_func():
#    #print("[Init]")


if __name__ == "__main__":
    app.run(host="0.0.0.0", debug=True, port=81)
else:
    gunicorn_logger = logging.getLogger('gunicorn.error')
    app.logger.handlers = gunicorn_logger.handlers
    app.logger.setLevel(gunicorn_logger.level)
    app.logger.debug('this will show in the log')
