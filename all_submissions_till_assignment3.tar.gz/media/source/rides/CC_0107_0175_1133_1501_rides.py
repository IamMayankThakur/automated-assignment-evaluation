#!/usr/bin/python
# -*- coding: utf-8 -*-
import ast
import csv
import datetime
import flask
import json
import pymongo
import random
import requests

app = flask.Flask(__name__)

def increaseCount(response):
    if "/api/v1/rides" in flask._request_ctx_stack.top.request.url and response.status_code in (200, 201, 204, 400, 405):
            d = dict()
            d["flag"] = "w"
            d["table"] = "counter"
            d["column"] = ["dummy"]
            d["data"] = [""]
            requests.post(url=rides_write_url, json=d)
    return response

app.after_request(increaseCount)

locations = list()
with open("AreaNameEnum.csv") as csvfile:
    reader = csv.reader(csvfile, delimiter=",")
    next(reader)
    for row in reader:
        locations.append(int(row[0]))

rides_database = pymongo.MongoClient("mongodb://rides-mongo:27017/")["rides"]

rides_ip = requests.get("https://checkip.amazonaws.com").text[:-1]
rides_write_url = "http://rides:5000/api/v1/db/write"
rides_read_url = "http://rides:5000/api/v1/db/read"


# API 3

@app.route("/api/v1/rides", methods=["POST"])
def createRide():
    try:
        body = flask.request.get_json()
        timestamp, created_by, source, destination = body["timestamp"], body["created_by"], int(body["source"]), int(body["destination"])
    except:
        return flask.Response("Invalid request format!", status=400)
    try:
        datetime.datetime.strptime(timestamp, "%d-%m-%Y:%S-%M-%H")
    except:
        return flask.Response("Invalid timestamp!", status=400)
    if source not in locations or destination not in locations or source == destination:
        return flask.Response("Invalid source or destination!", status=400)
    users_list_response = requests.get(url="http://RideShareLB-465441621.us-east-1.elb.amazonaws.com/api/v1/users", headers={"Origin": rides_ip})
    if users_list_response.status_code == 204 or created_by not in ast.literal_eval(users_list_response.text):
        return flask.Response("User doesn't exist!", status=400)
    d = dict()
    d["table"] = "rides"
    d["column"] = ["ride_id"]
    while True:
        new_ride_id = random.randint(1,100000)
        d["data"] = [new_ride_id]
        if len(ast.literal_eval(requests.post(url=rides_read_url, json=d).text)) == 0:
            break
    d["column"] = ["ride_id", "timestamp", "created_by", "source", "destination"]
    d["data"] = [new_ride_id, timestamp, created_by, source, destination]
    d["flag"] = "w"
    requests.post(url=rides_write_url, json=d)
    d["table"] = "users_rides"
    d["column"] = ["username", "ride_id"]
    d["data"] = [created_by, new_ride_id]
    d = requests.post(url=rides_write_url, json=d)
    return flask.Response("{}", status=201, mimetype="application/json")


# API 4

@app.route("/api/v1/rides", methods=["GET"])
def upcomingRides():
    try:
        source = int(flask.request.args.get("source", None))
        destination = int(flask.request.args.get("destination", None))
    except:
        return flask.Response("Invalid request format!", status=400)
    if source not in locations or destination not in locations or source == destination:
        return flask.Response("Invalid source or destination!", status=400)
    d = dict()
    d["column"] = ["source", "destination"]
    d["data"] = [source, destination]
    d["table"] = "rides"
    l = requests.post(url=rides_read_url, json=d)
    if len(ast.literal_eval(l.text)) == 0:
        return flask.Response(status=204)
    l = ast.literal_eval(l.text)
    filtered_list = list()
    for row in l:
        ride_time = datetime.datetime.strptime(row["timestamp"], "%d-%m-%Y:%S-%M-%H")
        current_time = datetime.datetime.now()
        if ride_time > current_time:
            filtered_list.append({"rideId": row["ride_id"],
                                  "username": row["created_by"],
                                  "timestamp": row["timestamp"]})
    if len(filtered_list) == 0:
        return flask.Response(status=204)
    return flask.Response(json.dumps(filtered_list), status=200, mimetype="application/json")


# API 5

@app.route("/api/v1/rides/<rideId>", methods=["GET"])
def getRideDetails(rideId):
    d = dict()
    d["column"] = ["ride_id"]
    try:
        ride_id = int(rideId)
    except ValueError:
        return flask.Response("Invalid ride ID!", status=400)
    d["data"] = [ride_id]
    d["table"] = "rides"
    details = ast.literal_eval(requests.post(url=rides_read_url, json=d).text)
    if len(details) == 0:
        return flask.Response(status=204)
    d["column"] = ["ride_id"]
    d["data"] = [ride_id]
    d["table"] = "users_rides"
    users = [_["username"] for _ in ast.literal_eval(requests.post(url=rides_read_url, json=d).text)]
    users.remove(details[0]["created_by"])
    response = str({
        "rideId": ride_id,
        "created_by": details[0]["created_by"],
        "users": users,
        "timestamp": details[0]["timestamp"],
        "source": details[0]["source"],
        "destination": details[0]["destination"],
        })
    return flask.Response(json.dumps(response), status=200, mimetype="application/json")


# API 6

@app.route("/api/v1/rides/<rideId>", methods=["POST"])
def joinRide(rideId):
    d = dict()
    d["column"] = ["ride_id"]
    try:
        ride_id = int(rideId)
    except ValueError:
        return flask.Response("Invalid ride ID!", status=400)
    d["data"] = [ride_id]
    d["table"] = "rides"
    ride_details = ast.literal_eval(requests.post(url=rides_read_url, json=d).text)
    if len(ride_details) == 0:
        return flask.Response("Ride doesn't exist", status=400)
    timestamp = ride_details[0]["timestamp"]
    ride_time = datetime.datetime.strptime(timestamp, "%d-%m-%Y:%S-%M-%H")
    current_time = datetime.datetime.now()
    if ride_time < current_time:
        return flask.Response("The ride has already started!", status=400)
    try:
        username = flask.request.get_json()["username"]
    except:
        return flask.Response("Invalid request format!", status=400)
    if ride_details[0]["created_by"] == username:
        return flask.Response("User cannot join their own ride!", status=400)
    users_list_response = requests.get(url="http://RideShareLB-465441621.us-east-1.elb.amazonaws.com/api/v1/users", headers={"Origin": rides_ip})
    if users_list_response.status_code == 204 or username not in ast.literal_eval(users_list_response.text):
        return flask.Response("User doesn't exist!", status=400)
    d["column"] = ["username", "ride_id"]
    d["data"] = [username, ride_id]
    d["table"] = "users_rides"
    if ast.literal_eval(requests.post(url=rides_read_url, json=d).text):
        return flask.Response("User has already joined the ride!", status=400)
    d["flag"] = "w"
    requests.post(url=rides_write_url, json=d)
    return flask.Response("{}", status=200, mimetype="application/json")


# API 7

@app.route("/api/v1/rides/<rideId>", methods=["DELETE"])
def deleteRide(rideId):
    d = dict()
    d["table"] = "rides"
    d["column"] = ["ride_id"]
    try:
        ride_id = int(rideId)
    except ValueError:
        return flask.Response("Invalid ride ID!", status=400)
    d["data"] = [ride_id]
    if len(ast.literal_eval(requests.post(url=rides_read_url, json=d).text)) == 0:
        return flask.Response("Ride doesn't exist!", status=400)
    d["flag"] = "d"
    requests.post(url=rides_write_url, json=d)
    d["table"] = "users_rides"
    requests.post(url=rides_write_url, json=d)
    return flask.Response("{}", status=200, mimetype="application/json")


# API 8

@app.route("/api/v1/db/write", methods=["POST"])
def writeToDatabase():
    body = flask.request.get_json()
    flag, table, column, data = body["flag"], rides_database[body["table"]], body["column"], body["data"]
    d = dict()
    for i in range(len(data)):
        d[column[i]] = data[i]
    if flag == "w":
        table.insert_one(d)
    elif flag == "d":
        table.remove(d)
    else:
        return flask.Response("Invalid flag! how??", status=400)
    return flask.Response("{}", status=200, mimetype="application/json")


# API 9

@app.route("/api/v1/db/read", methods=["POST"])
def readFromDatabase():
    body = flask.request.get_json()
    table, column, data = rides_database[body["table"]], body["column"], body["data"]
    d = dict()
    if data != [""]:
        for i in range(len(data)):
            d[column[i]] = data[i]
    l = [_ for _ in table.find(d, {"_id": False})]
    if l:
        return flask.jsonify(l)
    return flask.Response("{}", status=200, mimetype="application/json")


# API 10

@app.route("/api/v1/db/clear", methods=["POST"])
def clearDatabase():
    rides_database.drop_collection("rides")
    rides_database.drop_collection("users_rides")
    return flask.Response("{}", status=200, mimetype="application/json")


# API 11

@app.route("/api/v1/_count", methods=["GET", "DELETE"])
def counter():
    d = dict()
    d["table"] = "counter"
    d["column"] = ["dummy"]
    d["data"] = [""]
    if flask.request.method == "GET":
        return flask.Response(json.dumps([len(ast.literal_eval(requests.post(url=rides_read_url, json=d).text))]), status=200, mimetype="application/json")
    else:
        d["flag"] = "d"
        requests.post(url=rides_write_url, json=d)
        return flask.Response("{}", status=200, mimetype="application/json")


# API 12

@app.route("/api/v1/rides/count", methods=["GET"])
def countRides():
    d = dict()
    d["table"] = "rides"
    d["column"] = ["ride_id"]
    d["data"] = [""]
    return flask.Response(json.dumps([len(ast.literal_eval(requests.post(url=rides_read_url, json=d).text))]), status=200, mimetype="application/json")


# API 0

@app.route("/api/v1/db/clean_rides/<username>", methods=["DELETE"])
def cleanDeletedUser(username):
    d = dict()
    d["table"] = "rides"
    d["column"] = ["created_by"]
    d["data"] = [username]
    d["flag"] = "d"
    requests.post(url=rides_write_url, json=d)
    d["table"] = "users_rides"
    d["column"] = ["username"]
    requests.post(url=rides_write_url, json=d)
    return flask.Response("{}", status=200, mimetype="application/json")


# API Healthcheck

@app.route("/api/v1/healthcheck", methods=["GET"])
def healthCheck():
    return flask.Response("{}", status=200)
