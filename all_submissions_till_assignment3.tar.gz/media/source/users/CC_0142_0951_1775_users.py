import datetime
import json
import re
import time

import psycopg2
import requests
from flask import Flask, Response, jsonify, request
from psycopg2 import sql

from src import app

# Fill in this
POSTGRES_USER = "postgres"
POSTGRES_PASSWD = "docker"
POSTGRES_DB = "users_db"
POSTGRES_HOST = "users_db"

def increment_request_count():
    try:
        connection = psycopg2.connect(user=POSTGRES_USER,
                                      password=POSTGRES_PASSWD,
                                      host=POSTGRES_HOST,
                                      port="5432",
                                      database=POSTGRES_DB)

        cursor = connection.cursor()
        # TODO: Check if the table is already empty
        # TODO: Set the table name
        query = sql.SQL("UPDATE request_log SET count = count + 1;")

        cursor.execute(query.as_string(connection))
        connection.commit()

    except Exception as err:
        print(err)
        return Response(status=400)
    finally:
        if connection:
            cursor.close()
            connection.close()

@app.errorhandler(405)
def method_not_allowed(error):
    increment_request_count()
    return Response(status=405)


@app.route("/", methods=['GET'])
def hello():
    return "Hello From Users!"


#Functions implementing API routes
#Add user
#@t.include
@app.route('/api/v1/users', methods=['PUT', 'GET'])
def add_user():
    increment_request_count()
    if request.method == 'PUT':
        req_data = request.get_json()
        uname = req_data.get("username")
        passwd = req_data.get("password")

        # Check for valid username and password fields
        if uname == "" or passwd == "":
            return Response(status=400)
        else:
            regex = re.compile(r'^[a-fA-F0-9]{40}$')
            # Check for valid SHA1 hash
            if regex.match(passwd):
                r = requests.post(
                    "http://localhost:5000/api/v1/db/write",
                    json={
                        "insert": {
                            "uname": uname,
                            "passwd": passwd
                        },
                        "table": "users"
                    })
                if(r.status_code==200):
                     return Response(status=201)
                else:
                     return Response(status=400)
            else:
                return Response(status=400)
    elif request.method == 'GET':
        increment_request_count()
        # TODO Complete this request
        r = requests.post(
            "http://localhost:5000/api/v1/db/read",
            json={
                "delete": 0,
                "table": "users",
                "columns": ["uname"],
                "where": ["uname LIKE '{}'".format("%")]
            })
        users = r.json().get("uname")
        if(users):
          return jsonify(users)
        else:
          return Response(status=204)
# Remove user
@app.route('/api/v1/users/<uname>', methods=['DELETE'])
def del_user(uname):
    increment_request_count()
    r1 = requests.post(
        "http://localhost:5000/api/v1/db/read",
        json={
            "delete": 0,
            "table": "users",
            "columns": ["uname"],
            "where": ["uname='{}'".format(uname)]
        })

    if(r1.json().get("count")==0):
        return Response(status=400)
    else:
        r2 = requests.post(
            "http://localhost:5000/api/v1/db/read",
            json={
                "delete": 1,
                "table": "users",
                "columns": ["uname"],
                "where": ["uname='{}'".format(uname)]
            }
        )

        r3 = requests.get(
            "http://52.44.97.53:80/api/v1/rides/delrides/"+uname,
            json = {},
            headers = {"Content-type":"text/json","Origin":"http://52.4.225.49"}
        )
        return Response(status=r2.status_code)

# Write to db
@app.route('/api/v1/db/write', methods=['POST'])
def write_db():
    """
        POST request data format -

        {
            "insert" : {
                "col_name":value
                .
                .
                .
            },
            "table" : "<table_name>"
        }

    """
    req_data = request.get_json()

    table = req_data.get("table")

    insert = req_data.get("insert")
    columnNames = insert.keys()
    columnValues = insert.values()

    insertColumns = ""
    insertValues = ""

    for i in columnNames:
        insertColumns += i + ","

    for i in columnValues:
        insertValues += "'{}'".format(str(i)) + ","

    insertColumns = insertColumns[0:-1]
    insertValues = insertValues[0:-1]

    try:
        connection = psycopg2.connect(user=POSTGRES_USER,
                                      password=POSTGRES_PASSWD,
                                      host=POSTGRES_HOST,
                                      port="5432",
                                      database=POSTGRES_DB)

        cursor = connection.cursor()

        # Perform SQL validation to prevent SQL injection
        query = sql.SQL("INSERT" +
                        " INTO " + table + "(" + insertColumns + ")" +
                        " VALUES " + "(" + insertValues + ");"
                        )

        cursor.execute(query.as_string(connection))
        connection.commit()
        count = cursor.rowcount

        if count != 0:
            result = {}
            result["status"] = 201
            return json.dumps(result)
        else:
            result = {}
            result["status"] = 201
            return json.dumps(result)

    except Exception as err:
        print(err)
        return Response(status=400)
    finally:
        if connection:
            cursor.close()
            connection.close()

    return Response(status=201)


# Read from db
@app.route('/api/v1/db/read', methods=['POST'])
def read_db():
    """
        POST request data format -

        {
            "delete" : 1 or 0,
            "table" : "<table_name>",
            "columns" : ["<col_name>", ],
            "where" : "["<col_name='value'>",]
        }
    """

    req_data = request.get_json()

    delete = req_data.get("delete")

    if delete == 0:

        table = req_data.get("table")
        columns = req_data.get("columns")
        where = req_data.get("where")

        select_clause = ""
        for i in columns:
            select_clause += i + ","

        where_clause = ""
        for i in where:
            where_clause += i + " AND "

        select_clause = select_clause[0:-1]
        where_clause = where_clause[0:-5]

        count = 0
        try:
            connection = psycopg2.connect(user=POSTGRES_USER,
                                          password=POSTGRES_PASSWD,
                                          host=POSTGRES_HOST,
                                          port="5432",
                                          database=POSTGRES_DB)

            cursor = connection.cursor()

            query = sql.SQL("SELECT " + select_clause
                            + " FROM " + table
                            + " WHERE " + where_clause + ";"
                            )

            cursor.execute(query.as_string(connection))

            count = cursor.rowcount

            if count != 0:
                """
                    The query result is non empty.
                    Create a dictionary with key = <column_name> and
                    corresponding value is an array of values returned
                    by the query for that column.

                    Return a json response along with the dictionary and the count.
                """
                reqNumberOfColumns = len(columns)

                # Maps every required column to its index from the query result
                colNameIndexMap = {}
                column = 0
                for d in cursor.description:
                    colNameIndexMap[d[0]] = column
                    column = column + 1

                result = {}
                result["count"] = count
                result["status"] = 200

                # Add column name : [values, ] to the dictionary for every required column
                for i in range(count):
                    row = cursor.fetchone()
                    if i == 0:
                        for j in range(reqNumberOfColumns):
                            result[columns[j]] = [
                                row[colNameIndexMap[columns[j]]]]
                    else:
                        for j in range(reqNumberOfColumns):
                            result[columns[j]].append(
                                row[colNameIndexMap[columns[j]]])

                cursor.close()
                return json.dumps(result, default=str)
            else:
                result = {}
                result["count"] = 0
                result["status"] = 400
                return json.dumps(result)

        except Exception as err:
            print(err)
            return Response(status=400)
        finally:
            if connection:
                cursor.close()
                connection.close()
            else:
                return Response(status=400)
    else:
        try:
            connection = psycopg2.connect(user=POSTGRES_USER,
                                          password=POSTGRES_PASSWD,
                                          host=POSTGRES_HOST,
                                          port="5432",
                                          database=POSTGRES_DB)

            cursor = connection.cursor()

            table = req_data.get("table")
            where = req_data.get("where")

            where_clause = ""
            for i in where:
                where_clause += i + " AND "

            where_clause = where_clause[0:-5]

            query = sql.SQL("DELETE "
                            + " FROM " + table
                            + " WHERE " + where_clause + ";"
                            )

            cursor.execute(query.as_string(connection))
            connection.commit()
            count = cursor.rowcount

            return Response(status=200)

        except Exception:
            return Response(status=400)
        finally:
            if connection:
                cursor.close()
                connection.close()
            else:
                return Response(status=400)

def reset_request_count():
    try:
        connection = psycopg2.connect(user=POSTGRES_USER,
                                      password=POSTGRES_PASSWD,
                                      host=POSTGRES_HOST,
                                      port="5432",
                                      database=POSTGRES_DB)

        cursor = connection.cursor()
        # TODO: Check if the table is already empty
        # TODO: Set the table name
        query = sql.SQL("UPDATE request_log SET count = 0;")

        cursor.execute(query.as_string(connection))
        connection.commit()
    except Exception as err:
        print(err)
        return Response(status=400)
    finally:
        if connection:
            cursor.close()
            connection.close()

# Clear db
@app.route('/api/v1/db/clear', methods=['POST'])
def clear_db():
    """
        Delete all the rows from the table
    """
    try:
        connection = psycopg2.connect(user=POSTGRES_USER,
                                      password=POSTGRES_PASSWD,
                                      host=POSTGRES_HOST,
                                      port="5432",
                                      database=POSTGRES_DB)

        cursor = connection.cursor()
        # TODO: Check if the table is already empty
        # TODO: Set the table name
        query = sql.SQL("DELETE FROM users;")

        cursor.execute(query.as_string(connection))
        connection.commit()

    except Exception as err:
        print(err)
        return Response(status=400)
    finally:
        if connection:
            cursor.close()
            connection.close()

    return Response(status=200)
#@t.include
@app.route('/api/v1/_count', methods=['GET','DELETE'])
def http_requests():
    if(request.method == 'GET'):
      try:
        connection = psycopg2.connect(user=POSTGRES_USER,
                                      password=POSTGRES_PASSWD,
                                      host=POSTGRES_HOST,
                                      port="5432",
                                      database=POSTGRES_DB)

        cursor = connection.cursor()
        # TODO: Check if the table is already empty
        # TODO: Set the table name
        query = sql.SQL("SELECT count FROM request_log;")
        cursor.execute(query.as_string(connection))
        res = cursor.fetchone()
        connection.commit()
        return jsonify(res[0])
      except Exception as err:
        print(err)
        return Response(status=400)
      finally:
        if connection:
            cursor.close()
            connection.close()
    elif(request.method == 'DELETE'):
      reset_request_count()
      return jsonify(0)
