#!/usr/bin/python
# -*- coding: utf-8 -*-
import ast
import flask
import json
import pymongo
import re
import requests

app = flask.Flask(__name__)

def increaseCount(response):
    if "/api/v1/users" in flask._request_ctx_stack.top.request.url and response.status_code in (200, 201, 204, 400, 405):
            d = dict()
            d["flag"] = "w"
            d["table"] = "counter"
            d["column"] = ["dummy"]
            d["data"] = [""]
            requests.post(url=users_write_url, json=d)
    return response

app.after_request(increaseCount)

users_database = pymongo.MongoClient("mongodb://users-mongo:27017/")["users"]

users_write_url = "http://users:5000/api/v1/db/write"
users_read_url = "http://users:5000/api/v1/db/read"


# API 1

@app.route("/api/v1/users", methods=["PUT", "GET"])
def user():
    if flask.request.method == "PUT":
        try:
            username = flask.request.get_json()["username"]
            password = flask.request.get_json()["password"].lower()
        except:
            return flask.Response("Invalid request format!", status=400)
        d = dict()
        d["table"] = "users"
        d["column"] = ["username"]
        d["data"] = [username]
        if len(ast.literal_eval(requests.post(url=users_read_url, json=d).text)) != 0:
            return flask.Response("Username already exists!", status=400)
        if not re.search("^[a-fA-F0-9]{40}$", password):
            return flask.Response("Invalid Password: not in SHA-1 format", status=400)
        d["column"] = ["username", "password"]
        d["data"] = [username, password]
        d["flag"] = "w"
        requests.post(url=users_write_url, json=d)
        return flask.Response("{}", status=201, mimetype="application/json")
        return flask.Response("Username already exists!", status=400)
    else:
        d = dict()
        d['table'] = "users"
        d["column"] = ["username"]
        d["data"] = [""]
        l = requests.post(url=users_read_url, json=d)
        if len(ast.literal_eval(l.text)) == 0:
            return flask.Response(status=204)
        return flask.Response(json.dumps([_["username"] for _ in ast.literal_eval(l.text)]), status=200, mimetype="application/json")


# API 2

@app.route("/api/v1/users/<name>", methods=["DELETE"])
def removeUser(name):
    d = dict()
    d["table"] = "users"
    d["column"] = ["username"]
    d["data"] = [name]
    if len(ast.literal_eval(requests.post(url=users_read_url, json=d).text)) == 0:
        return flask.Response("User doesn't exist!", status=400)
    d["flag"] = "d"
    requests.post(url=users_write_url, json=d)
    requests.delete(url="http://RideShareLB-465441621.us-east-1.elb.amazonaws.com/api/v1/db/clean_rides/"+name)
    return flask.Response("{}", status=200, mimetype="application/json")


# API 8

@app.route("/api/v1/db/write", methods=["POST"])
def writeToDatabase():
    body = flask.request.get_json()
    flag, table, column, data = body["flag"], users_database[body["table"]], body["column"], body["data"]
    d = dict()
    for i in range(len(data)):
        d[column[i]] = data[i]
    if flag == "w":
        table.insert_one(d)
    elif flag == "d":
        table.remove(d)
    else:
        return flask.Response("Invalid flag! how??", status=400)
    return flask.Response("{}", status=200, mimetype="application/json")


# API 9

@app.route("/api/v1/db/read", methods=["POST"])
def readFromDatabase():
    body = flask.request.get_json()
    table, column, data = users_database[body["table"]], body["column"], body["data"]
    d = dict()
    if data != [""]:
        for i in range(len(data)):
            d[column[i]] = data[i]
    l = [_ for _ in table.find(d, {"_id": False})]
    if l:
        return flask.jsonify(l)
    return flask.Response("{}", status=200, mimetype="application/json")


# API 10

@app.route("/api/v1/db/clear", methods=["POST"])
def clearDatabase():
    users_database.drop_collection("users")
    return flask.Response("{}", status=200, mimetype="application/json")


# API 11

@app.route("/api/v1/_count", methods=["GET", "DELETE"])
def counter():
    d = dict()
    d["table"] = "counter"
    d["column"] = ["dummy"]
    d["data"] = [""]
    if flask.request.method == "GET":
        return flask.Response(json.dumps([len(ast.literal_eval(requests.post(url=users_read_url, json=d).text))]), status=200, mimetype="application/json")
    else:
        d["flag"] = "d"
        requests.post(url=users_write_url, json=d)
        return flask.Response("{}", status=200, mimetype="application/json")


# API Healthcheck

@app.route("/api/v1/healthcheck", methods=["GET"])
def healthCheck():
    return flask.Response("{}", status=200)
