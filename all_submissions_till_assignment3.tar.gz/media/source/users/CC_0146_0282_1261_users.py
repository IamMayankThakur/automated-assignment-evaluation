
import random
import sqlite3  
import requests
import json
import ast
from datetime import datetime
from flask import Flask, render_template,\
jsonify,request,abort, Response
global req_count
req_count=0


app=Flask(__name__)
@app.route('/api/v1/users/hello/<name>')
def hello_world(name):	
	return "Hello from users, %s !" % name
def incr_ct():
    global req_count
    req_count+=1



@app.before_request
def incr_ct_before():
    if request.path not in ('/', '/api/v1/db/write','/api/v1/db/read','/api/v1/_count','/api/v1/db/clear'):
        incr_ct()

@app.route("/api/v1/_count", methods=["GET"])
def get_ct():
    if request.method != "GET":  
        return('', 405)
    final=[]
    final.append(req_count)
    return(jsonify(final), 200)

@app.route("/api/v1/_count", methods=["DELETE"])
def del_ct():
    if request.method != "DELETE":  
        return('', 405)
    global req_count
    req_count=0
    return(jsonify({}),200)
import string
def is_hex(s):
     hex_digits = set(string.hexdigits)
     return all(c in hex_digits for c in s)
#1 Adding  new user to db-DONE.
@app.route('/api/v1/users', methods=["PUT"]) #ENCODING- 201, 400, 405
def add_new_user():
    if request.method != "PUT":  
        return('', 405)
    username = request.get_json()["username"]  
    password = request.get_json()["password"]
    password=password.upper()
    if(len(str(password))!=40 or is_hex(str(password))==False):
        return('Invalid Password', 400)
    user = {}
    password=password.lower()
    user["table"] = "users"
    user["columns"] = ["name","pwd"]
    user["where"] = "name='"+username+"'"
    r = json.dumps(user)
    loaded_r = json.loads(r)
    headers = {'content-type': 'application/json'}
    req_resp=requests.post("http://50.17.124.155:80/api/v1/db/read",data = r, headers = headers)
    temp=str(req_resp.text)
    temp=json.loads(temp)
    if(bool(temp)==True): #EMPTY DICTIONARY
        return('User already exists', 400)
    else:
        add_user = {}
        add_user_j = {}
        add_user["insert"] = [str(username),str(password)]
        add_user["column"] = ["name","pwd"]
        add_user["table"] = "users"
        r = json.dumps(add_user)
        loaded_r = json.loads(r)
        headers = {'content-type': 'application/json'}
        req_resp=requests.post("http://50.17.124.155:80/api/v1/db/write",data = r, headers = headers)
        return('', 201) #successful create


#2- Removing a particular user- DONE.
@app.route("/api/v1/users/<name>",methods = ["DELETE"])  
def removeuser(name):
    if request.method != "DELETE":  
        return('', 405)
    user = {}
    user["table"] = "users"
    user["columns"] = ["name","pwd"]
    user["where"] = "name='"+name+"'"
    r = json.dumps(user)
    loaded_r = json.loads(r)
    headers = {'content-type': 'application/json'}
    req_resp=requests.post("http://50.17.124.155:80/api/v1/db/read",data = r, headers = headers)
    temp=str(req_resp.text)
    temp=json.loads(temp)
    if(bool(temp)==False): #EMPTY DICTIONARY
        return('Username Not Found', 400)
    else:
        con = sqlite3.connect("user.db") 
        cur = con.cursor()
        command2="delete from users where name =" +"'" + str(name) + "'"
 
        cur.execute(command2) 
        con.commit()
        con.close()
        return('', 200)

#LIST ALL THE USERS
@app.route('/api/v1/users')
def list_all_users():
    if request.method != "GET":  
        return('', 405)
    user = {}
    user["table"] = "users"
    user["columns"] = ["name","pwd"]
    user["where"] = "exists(select 1)"
    r = json.dumps(user)
    loaded_r = json.loads(r)
    headers = {'content-type': 'application/json'}
    req_resp=requests.post("http://50.17.124.155:80/api/v1/db/read",data = r, headers = headers)
    temp=str(req_resp.text)
    temp=json.loads(temp)
    if(bool(temp)==False):
        return("No users", 204)
    new=[]
    for i in temp:
        new.append(temp[i]["username"])
    return(jsonify(new), 200)


#CLEARING USER DB
@app.route('/api/v1/db/clear', methods=["POST"] )
def clear_db_users():
    if request.method != "POST":  
        return('', 405)
    user = {}
    user["table"] = "users"
    user["columns"] = ["name","pwd"]
    user["where"] = "exists(select 1)"
    r = json.dumps(user)
    loaded_r = json.loads(r)
    headers = {'content-type': 'application/json'}
    req_resp=requests.post("http://50.17.124.155:80/api/v1/db/read",data = r, headers = headers)
    temp=str(req_resp.text)
    temp=json.loads(temp)
    if(bool(temp)==False):
        return("No users", 400)
    else:
        con = sqlite3.connect("user.db") 
        cur = con.cursor()     
        command="delete from users"  
        cur.execute(command)  
        con.commit()
        con.close()
        return('', 200)
#8- reading from a db
@app.route("/api/v1/db/read",methods = ["POST"])  
def view():  
    con = sqlite3.connect("user.db") 
    table = request.get_json()["table"]  
    columns = request.get_json()["columns"]
    string=""
    for i in columns:
        string+=", "+i
    string=string[1::]
    whr = request.get_json()["where"]   
    cur = con.cursor() 
    command="select "+string+" from "+table+" where "+whr  
    cur.execute(command)  

    final={}
    rows = cur.fetchall() 
    if(table=="rides"):
        for i in range(len(rows)):
            final[i]={
                "rideId":str(rows[i][0]),
                "username":str(rows[i][1]),
                "timestamp":str(rows[i][2]),
                "src":str(rows[i][3]),
                "dest":str(rows[i][4]),
                "created_by":str(rows[i][5])
            }
    elif(table=="users"):
        for i in range(len(rows)):
            final[i]={
                "username":str(rows[i][0]),
                "password":str(rows[i][1]),
            }
    return(final)
    #return(command)



#9-writing into db
@app.route("/api/v1/db/write",methods = ["POST"])  
def write(): 
    con = sqlite3.connect("user.db") 
    table = request.get_json()["table"]
    column = request.get_json()["column"]
    insert = request.get_json()["insert"]
    #[u'username', u'source', u'destination', u'1001', u'DD-MM-YYYY:SS-MM-HH']
    cur = con.cursor()  
    finalstr=''
    stringcol=""
    stringinsert=""
    for i in column:
        stringcol+=", "+str(i)
    stringcol=stringcol[1::] 
    for i in insert:
        stringinsert+=", "+"'"+str(i)+"'"
    stringinsert=stringinsert[1::]   
    command="insert into "+ table+" "+"("+stringcol+")"+" values "+"("+stringinsert+")"
    cur.execute(command)  
    con.commit()   
    con.close()
    return('', 200)
if __name__ == '__main__':	
	app.debug=True
	app.run(host='0.0.0.0',debug=True)
