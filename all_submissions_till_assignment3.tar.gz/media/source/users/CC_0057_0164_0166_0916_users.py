import sqlite3
from flask import Flask, render_template, jsonify, request, abort, url_for, Response
from flask_restful import Resource, Api
import json
import requests
from datetime import datetime
import csv

app = Flask(__name__)
api = Api(app)



def convertTime(timestamp):
    return datetime.strptime(timestamp, "%d-%m-%Y:%S-%M-%H")



def is_hex(s):
    try:
        int(s, 16)
        return True
    except ValueError:
        return False






class Dummy(Resource):
    def get(self):
        return Response('Hello World', status = 200, mimetype='application/jsons')






class API_Access_Monitor(Resource):
    def post(self):
        try:
            f = open('api_count.txt', 'r+')
            s = f.readline()
            s = int(s)
            s += 1
            f.truncate(0)
            f.seek(0)
            f.write(str(s))
            f.close()
            code = 200
        except:
            code = 405

        return Response('{}', status=code, mimetype='application/json')



    def get(self):
        try:
            f = open('api_count.txt', 'r+')
            s = f.readline()
            s = int(s)
            api_count = [s]
            f.close()
            ret = json.dumps(api_count)
            code = 200
        except:
            ret = '{}'
            code = 405

        return Response(ret, status=code, mimetype='application/json')



    def delete(self):
        try:
            f = open('api_count.txt', 'r+')
            s = 0
            f.truncate(0)
            f.seek(0)
            f.write(str(s))
            f.close()
            code = 200
        except:
            code = 405

        return Response('{}', status=code, mimetype='application/json')






class DatabaseClear(Resource):
    def post(self):
        code = 200
        
        try:
            with sqlite3.connect("users_database.db") as con:
                con.execute("PRAGMA foreign_keys = 1")
                cur = con.cursor()
                cur.execute("DELETE FROM users")
                con.commit()
        
        except:
            try:
                con.rollback()
            except:
                pass
            code = 400
        
        finally:
            try:
                con.close()
            except:
                pass
            return Response('{}', status=code, mimetype='application/json')     






class DatabaseWrite(Resource):
    def post(self):
        jobj = request.get_json()
        temp = json.loads(jobj)
        
        try:
            data = temp['data']
            table = temp['table']
            method = temp['method']
        except:
            return Response('{}', status=400, mimetype='application/json')
                
        if table == 'users':
            if method == 'PUT':
                username = data['username']
                password = data['password']
                try:
                    with sqlite3.connect("users_database.db") as con:
                        con.execute("PRAGMA foreign_keys = 1")
                        cur = con.cursor()
                        cur.execute("INSERT INTO "+table+" (username, password) \
                            VALUES (?,?)", (username, password))
                        con.commit()
                        code = 201
                
                except:
                    try:
                        con.rollback()
                    except:
                        pass
                    code = 400
                
                finally:
                    try:
                        con.close()
                    except:
                        pass
                    return Response('{}', status=code, mimetype='application/json')
                
            elif method == 'DELETE':
                username = data['username']
                try:
                    with sqlite3.connect("users_database.db") as con:
                        con.execute("PRAGMA foreign_keys = 1")
                        cur = con.cursor()
                        jdict = {
                            "table": "users",
                            "columns": ["username"],
                            "where": " username = '" + username + "'"
                        }
                        jobject = json.dumps(jdict)
                        response = requests.post('http://users/api/v1/db/read', json=jobject)
                        code = response.status_code
                        
                        if code == 200:
                            command = "DELETE FROM "+table+" WHERE username = '" + username + "'"
                            cur.execute(command)
                            con.commit()
                            rides_jdict = {
                                "table": "rides",
                                "columns": ["ride_id", "created_by", "users"],
                                "where": ""
                            }
                            rides_jobject = json.dumps(rides_jdict)
                            rides_response = requests.post('http://assignment3-420730437.us-east-1.elb.amazonaws.com:80/api/v1/rides/oogabooga', json=rides_jobject)
                            rides_code = rides_response.status_code
                            
                            if rides_code ==200:
                                rides_ret = rides_response.json()
                                del_rides = []
                                for i in range(len(rides_ret['rows'])):
                                    if rides_ret['rows'][i][1] == username:
                                        ride_id = rides_ret['rows'][i][0]
                                        temp_response = requests.delete('http://assignment3-420730437.us-east-1.elb.amazonaws.com:80/api/v1/rides/'+ride_id)
                                        del_rides.append(i)

                                    else:
                                        temp = rides_ret['rows'][i][2].split(',')
                                        try:
                                            temp.remove(username)
                                        except:
                                            pass
                                        rides_ret['rows'][i][2] = ','.join(temp)

                                for i in del_rides:
                                    rides_ret['rows'].pop(i)

                                for rec in rides_ret['rows']:
                                    ride_id = str(rec[0])
                                    users = rec[2]
                                    table = "rides"
                                    jdict2 = {
                                        "method": "POST",
                                        "data": {
                                            "ride_id": ride_id,
                                            "users": users,
                                        },
                                        "table": table
                                    }
                                    jobject = json.dumps(jdict2)
                                    response = requests.put('http://assignment3-420730437.us-east-1.elb.amazonaws.com:80/api/v1/rides/oogabooga', json=jobject)
                                
                            code = 200
                        else:
                            code = 400
                
                except:
                    try:
                        con.rollback()
                    except:
                        pass
                    code = 400
                
                finally:
                    try:
                        con.close()
                    except:
                        pass
                    return Response('{}', status=code, mimetype='application/json')






class DatabaseRead(Resource):
    def post(self):
        ret = ''
        jobj = request.get_json()
        temp = json.loads(jobj)
                
        try:
            table = temp['table']
            columns = temp['columns']
            where = temp['where']
        except:
            return Response('{}', status=400, mimetype='application/json')
        
        command = 'SELECT ' + ', '.join(columns) + ' FROM ' + table
        if len(where):
            command = command + ' WHERE ' + where
        
        try:
            with sqlite3.connect("users_database.db") as con:
                con.execute("PRAGMA foreign_keys = 1")
                cur = con.cursor()
                cur.execute(command)
                rows = cur.fetchall()
                if not len(rows):
                    code = 204
                    ret = ''
                else:
                    ret = {
                        "rows": rows
                    }
                    code = 200
                    ret = json.dumps(ret)
                con.commit()
        
        except:
            try:
                con.rollback()
            except:
                pass
            code = 400
        
        finally:
            try:
                con.close()
            except:
                pass
            return Response(ret, status=code, mimetype='application/json')






class Users(Resource):  
    def post(self):
        temp = requests.post('http://users/api/v1/_count')
        return Response('{}', status=400, mimetype='application/json')


    def get(self):
        temp = requests.post('http://users/api/v1/_count')

        jdict = {
            "table": "users",
            "columns": ["username"],
            "where": ""
        }
        jobject = json.dumps(jdict)
        response = requests.post('http://users/api/v1/db/read', json=jobject)
        code = response.status_code
        if code != 200:
            final_ret_jobject = '{}'
        else:
            ret = response.json()
            final_ret = []
            for i in ret['rows']:
                final_ret.append(i[0])
            final_ret_jobject = json.dumps(final_ret)
        return Response(final_ret_jobject, status=code, mimetype='application/json')
    
    
    
    def put(self):
        temp = requests.post('http://users/api/v1/_count')

        try:
            username = request.json['username']
            password = request.json['password']
        except:
            return Response('{}', status=400, mimetype='application/json')
        if not is_hex(password) or len(password) != 40:
            return Response('{}', status=400, mimetype='application/json')
        
        table = 'users'
        jdict = {
            "method": "PUT",
            "data": {
                "username": username,
                "password": password
            },
            "table": table
        }
        jobject = json.dumps(jdict)
        response = requests.post('http://users/api/v1/db/write', json=jobject)
        code = response.status_code
        return Response('{}', status=code, mimetype='application/json')
    
    
    
    def delete(self, username):
        temp = requests.post('http://users/api/v1/_count')

        if username == '':
            return Response('{}', status=400, mimetype='application/json')
        else:
            table = "users"
            jdict = {
                "method": "DELETE",
                "data": {
                    "username": username,
                },
                "table": table
            }
            jobject = json.dumps(jdict)
            response = requests.post('http://users/api/v1/db/write', json=jobject)
            code = response.status_code
        return Response('{}', status=code, mimetype='application/json')






api.add_resource(API_Access_Monitor, '/api/v1/_count')
api.add_resource(Users,
                 '/api/v1/users',
                 '/api/v1/users/<string:username>')
api.add_resource(DatabaseWrite, '/api/v1/db/write')
api.add_resource(DatabaseRead, '/api/v1/db/read')
api.add_resource(DatabaseClear, '/api/v1/db/clear')
api.add_resource(Dummy,'/')



if __name__ == '__main__':
    app.run(host='0.0.0.0', port='80', debug=True)
