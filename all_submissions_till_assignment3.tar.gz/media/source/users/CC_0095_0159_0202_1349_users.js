const express = require("express");
const router = express.Router();
const User = require("../../../models/User");
const Count = require("../../../models/Count");
const rp = require("request-promise-native");
const joiSchemas = require("../../../utils/Joi_schemas");
const Joi = require("@hapi/joi");
const config = require("config");

// @route PUT /api/v1/users
// @desc add a new user
router.all("/", async (req, res) => {
  // Check if correct HTTP method is used
  if (req.method === "PUT") {
    if (joiSchemas.joiValidate(joiSchemas.createUser, req.body)) {
      try {
        // Check if user already exist
        // Make read db call
        let user = await rp.post(config.get("DB_API_URI").READ, {
          json: {
            model: "User",
            parameters: {
              username: req.body.username
            }
          }
        });
        try {
          let counter = await Count.findOneAndUpdate({},{ $inc: {count:-1}},{
            new : true,
            upsert : true
          });
          console.log(counter.count);
        }
        catch(error)
        {
          console.log(error.message);
          res.status(500).json({ msg: "Server error" });
        }
        console.log(user);
        if (user.length != 0) {
          return res.status(400).json({ msg: "1" });
        }

        await rp.post(config.get("DB_API_URI").WRITE, {
          json: {
            model: "User",
            parameters: {
              username: req.body.username,
              password: req.body.password
            },
            op: "in"
          }
        });
        try {
          let counter = await Count.findOneAndUpdate({},{ $inc: {count:-1}},{
            new : true,
            upsert : true
          });
          console.log(counter.count);
        }
        catch(error)
        {
          console.log(error.message);
          res.status(500).json({ msg: "Server error" });
        }

        return res.status(201).json({});
      } catch (error) {
        console.log(error.message);
        return res.status(500).json({ msg: "Error occured" });
      }
    } else {
      //  remember to change
      return res.status(400).json({ msg: "2" });
      //bad request
    }
  } else if (req.method == "GET") {
    try {
      // Get all users
      let users = await rp.post(config.get("DB_API_URI").READ, {
        json: {
          model: "User",
          parameters: {}
        }
      });
      try {
        let counter = await Count.findOneAndUpdate({},{ $inc: {count:-1}},{
          new : true,
          upsert : true
        });
        console.log(counter.count);
      }
      catch(error)
      {
        console.log(error.message);
        res.status(500).json({ msg: "Server error" });
      }
      if (users.length === 0) {
        return res.status(204).send(users);
      }

      let usernames = [];
      for (let i = 0; i < users.length; i++) {
        usernames.push(users[i].username);
      }
      return res.status(200).send(usernames);
    } catch (error) {
      console.log(error.message);
      return res.status(500).json({ msg: "Error occured" });
    }
  } else {
    return res.status(405).json({});
    //method not allowed
  }
});

router.get("/all", async (req, res) => {
  // console.log(req.query);
  const val = await User.find();
  console.log(
    config.get("DB_API_URI").READ === "http://localhost:5000/api/v1/db/read"
  );
  return res.send(val);
});

// @route DELETE /api/v1/users/:username
// @desc Remove a user
router.all("/:username", async (req, res) => {
  if (req.method == "DELETE") {
    // Check if the user exist or not
    let user = await rp.post(config.get("DB_API_URI").READ, {
      json: {
        model: "User",
        parameters: {
          username: req.params.username
        }
      }
    });
    try {
      let counter = await Count.findOneAndUpdate({},{ $inc: {count:-1}},{
        new : true,
        upsert : true
      });
      console.log(counter.count);
    }
    catch(error)
    {
      console.log(error.message);
      res.status(500).json({ msg: "Server error" });
    }
    if (user.length == 0) {
      return res.status(400).json({ msg: "1" });
    }

    await rp.post(config.get("DB_API_URI").WRITE, {
      json: {
        model: "User",
        parameters: {
          username: req.params.username
        },
        op: "del"
      }
    });
    try {
      let counter = await Count.findOneAndUpdate({},{ $inc: {count:-1}},{
        new : true,
        upsert : true
      });
      console.log(counter.count);
    }
    catch(error)
    {
      console.log(error.message);
      res.status(500).json({ msg: "Server error" });
    }
    return res.status(200).json({});
  } else {
    return res.status(405).json({});
  }
});

module.exports = router;
