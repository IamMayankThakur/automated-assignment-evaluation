const User = require('../../models/User');
// const Counter = require('../../models/Counter');
// var incCounter = require('../../middleware/counter').incCounter;

var globalC = 0;

module.exports = (app) => {
    app.use('/api/v1/users', (req, res, next)=>{
        console.log("Incremented. Inside use.");
        globalC += 1;
        next();
    });

  // API: 1
  app.put('/api/v1/users', (req, res) => {
    var username = req.body.username;
    var password = req.body.password;
    if (!username) {
        return res.status(400).send({
            success: false,
            message: 'Error: username cannot be blank.'
        });
    }
    if (!password) {
        return res.status(400).send({
            success: false,
            message: 'Error: password cannot be blank.'
        });
    }
    if (password.length != 40) {
        return res.status(400).send({
            success: false,
            message: 'Error: password is not 40 chars long.'
        });
    }

    // Deduplication flow
    User.find({
        username: username
    }, (err, previousUsers) => {
        if(err){
            console.log(err.message);
            return res.status(500).send({
                success: false,
                message: "Error: Server error.",
                error: err.message,
            });
    }
        else if (previousUsers.length > 0) {
            return res.status(400).send({
                success: false,
                message: 'Error: User already exists.'
            });
        }
        // Save the new user
        const newUser = new User();

        newUser.username = username;
        newUser.password = password;

        newUser.save((err) => {
            if (err) {
                console.log(err.message);
                return res.status(500).send({
                    success: false,
                    message: 'Error: Server error.',
                    error: err.message
                });
            }
            console.log(newUser._id + " added to DB. Username is " + newUser.username);
            return res.status(201).send({});
                // return res.status(200).send({
                //     success: true,
                //     message: 'User signed up.'
                // });
            
        });
    });
  });

  // API: 2
  app.delete('/api/v1/users/:username', (req, res) => {
    var username = req.params.username;
    if (!username) {
        return res.status(400).send({
            success: false,
            message: "Error: username not recieved."
        });
    }
    User.findOneAndDelete({
        username : username
        }, (err, user) => {
        if (err) {
            console.log(err.message);
            return res.status(500).send({
                success: false,
                message: 'Error: Server error.',
                error: err.message
            });
        }
        if (!user) {
            return res.status(400).send({
                success: false,
                message: 'Error: User not found.'
            });
        }

        return res.status(200).send({});
        // return res.status(200).send({
        //     success: true,
        //     message: "User " + user._id + " successfully deleted."
        // });
        });
    });

    // API 10: All users
    app.get('/api/v1/users', (req, res) => {
        User.find({},'username', (err, all_users) => {
            if (err) {
                console.log(err.message)
                return res.status(500).send({
                    success: false,
                    message: 'Error: Server error.',
                    error: err.message
                });
            }
            console.log(all_users);
            if(all_users.length==0){
                return res.status(204).send({
                    success: false,
                    message: 'Error: No users exist.'
                  });
            }

            var user_array=[];
            for(var i = 0; i < all_users.length; i++){
                user_array.push(
                  all_users[i].username
                );
            }
            console.log("Returned all users.");
            return res.status(200).send(user_array);
         });
         
    });

    //API X: Return count
    app.get('/api/v1/_count/', (req, res) => {
        console.log("Incrementing.");
        res.status(200).send([globalC]);
    });

    //API X+1: Delete or reset count
    app.delete('/api/v1/_count/', (req, res) => {
        console.log("Reset.");
        globalC = 0;
        return res.status(200).send({});    
    });

};
