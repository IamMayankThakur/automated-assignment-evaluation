from flask import Flask, request, flash, url_for, redirect, render_template, jsonify, request, abort
from flask_sqlalchemy import SQLAlchemy
import csv
from sqlalchemy import create_engine
import datetime
import requests
from sqlalchemy import func

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///UserDB.sqlite'

db = SQLAlchemy(app)
engine = create_engine(app.config['SQLALCHEMY_DATABASE_URI'])


class table_user(db.Model):
    __tablename__ = 'table_user'
    email = db.Column(db.String(120),
                      unique=True,
                      nullable=False,
                      primary_key=True)
    pwd = db.Column(db.String(80), nullable=False)

    def __init__(self, email, pwd):
        self.email = email
        self.pwd = pwd

class table_count(db.Model):
    __tablename__ = 'table_count'
    count = db.Column(db.Integer, primary_key=True)
    
    def __init__(self, count):
        self.count = count
        print("Initilized count")

db.create_all()

#------------------- end count stuff ----------------------------
try:
    print("Initializing now")
    exec_str = "INSERT INTO table_count(count) VALUES (0)"
    engine.execute(exec_str)
except:
    db.session.rollback()


@app.route('/api/v1/_count', methods = ['GET'])
def read_count():
    if request.method != 'GET':
        return {}, 405
    
    print("Reading the count table")
    count_obj = table_count.query.all()

    for i in count_obj:
        print(i.count)
        return jsonify([i.count]), 200
    return "error", 404

@app.route('/api/v1/_count', methods = ['DELETE'])
def reset_count():
    if request.method != 'DELETE':
        return {}, 405
    
    print("Resetting the count table")
    count_obj = table_count.query.all()
    print("count_obj",count_obj)
    for i in count_obj:
        print("Before ", i.count)
        i.count = 0
        db.session.commit()
        return {}, 200
    return "error", 404


@app.route('/api/v1/db/increment_count', methods = ['GET'])   
def increment_count():
    print("Inside increment count")
    if request.method != 'GET':
        return {}, 405

    count_obj = table_count.query.all()
    print("count_obj",count_obj)
    for i in count_obj:
        print("---- old count ---- ", i.count)
        i.count = i.count + 1
        db.session.commit()
        return jsonify([i.count]), 200
    return "error", 404

#------------------- end count stuff ----------------------------

@app.route('/api/v1/db/write', methods = ['POST'])
def writedb():
    data = request.get_json()

    if data['operation']=="insert":
        if data['table']=="user":
            user = table_user(data['email'], data['pwd'])
            db.session.add(user)
            db.session.commit()
            return "user_success"

    if data['operation']=="delete":
        if data['element']=="user":
            val = data['value']
            users = table_user.query.filter_by(email=val).all()
            for user in users:
                db.session.delete(user)
            db.session.commit()
            return "user_deleted"

    if data['operation']=="update":
        if data['table']=="user":
            u_id = data["id"]
            val = data["pwd"]
            user = table_user.query.filter_by(email=u_id).first()
            user.pwd = val
            db.session.commit()
            return "user_updated"
    
    return "failure",400


@app.route('/api/v1/db/read', methods=['POST'])
def read():

    data = request.get_json()

    col = data["column"]
    val = data["value"]
    catalog = {}
    catalog['output'] = []

    if data['table'] == "user":
        if col == "email":
            information = table_user.query.filter_by(email=val).all()
        if col == "pwd":
            information = table_user.query.filter_by(pwd=val).all()
        for i in information:
            op = {}
            op['email'] = i.email
            op['pwd'] = i.pwd
            catalog['output'].append(op)
        print('length',len(catalog['output']))
        if len(catalog['output']):
            return jsonify(catalog),200
        else:
            return {},204

    return {},400

        
@app.route("/api/v1/users/<name>",methods=["DELETE"])
def delete_user(name):
    count_url = 'http://users:80/api/v1/db/increment_count'
    count_resp = requests.get(count_url)
    count_r = count_resp.json()
    print("Increased count to -----> ", count_r[0])
    
    if request.method != 'DELETE':
        return {}, 405

    write_url = 'http://127.0.0.1:5000/api/v1/db/write'

    list_users_url = 'http://RideShare-1310550014.us-east-1.elb.amazonaws.com/api/v1/users' #########################other container's IP######################

    #check if user doesn't exist
    list_users_resp = requests.get(list_users_url)
    list_users_r = list_users_resp.json()

    if (name not in list_users_r):
        print("User doesn't exist")
        return {}, 400
    
    param2 = {"operation":"delete", "element": "user", "value":name}
    r2 = requests.post(write_url, json=param2)

    return {}, r2.status_code



@app.route("/api/v1/users",methods=["PUT"])
def add_user():
    count_url = 'http://users:80/api/v1/db/increment_count'
    count_resp = requests.get(count_url)
    count_r = count_resp.json()
    print("Increased count to -----> ", count_r[0])

    if request.method != 'PUT':
        return {}, 405
    
    user = request.get_json()["username"]
    pwd = request.get_json()["password"]
    
    write_ur1 = 'http://users:80/api/v1/db/write'

    list_users_url = 'http://RideShare-1310550014.us-east-1.elb.amazonaws.com/api/v1/users' #########################other container's IP######################

    #check if user doesn't exist
    r1 = requests.get(list_users_url)
    
    if (r1.status_code == 204):
        #No users exist
        #so can create user
        if len(pwd) != 40:
            print("length is not correct")
            return {}, 400
        try:
            sha_int = int(pwd, 16)
        except ValueError:
            print("not hexa")
            return {}, 400
        param2 = {"operation":"insert", "table": "user", "email":user, "pwd":pwd}

        r2 = requests.post(write_ur1, json=param2)
        if r2.status_code == 200:
            return {}, 201
        else:
            return {}, r2.status_code
    
    response1 = r1.json()
    print("The response is  = ", response1)
    
    if (user in response1):
        print("User already exists")
        return {}, 400
    
    #other users exist but not of the same name
    if len(pwd) != 40:
        print("length is not correct")
        return {}, 400
    try:
        sha_int = int(pwd, 16)
    except ValueError:
        print("not hexa")
        return {}, 400

    param2 = {"operation":"insert", "table": "user", "email":user, "pwd":pwd}
    r2 = requests.post(write_ur1, json=param2)
    if r2.status_code == 200:
        return {}, 201
    else:
        return {}, r2.status_code
 

@app.route('/api/v1/db/read_all_users', methods=['POST'])
def read_all_users():
    #internal api .... not to be counted
    #print("In reading all users")
    catalog = {}
    catalog['output'] = []
    
    information = table_user.query.all()
    for i in information:
        #print("\tThe entry in result is :", i)
        catalog['output'].append(i.email)
    print('length',len(catalog['output']))
    if len(catalog['output']):
        return jsonify(catalog),200
    else:
        return {}, 204
    return {}, 400

@app.route("/api/v1/users",methods=["GET"])
def list_all_users():
    count_url = 'http://users:80/api/v1/db/increment_count'
    count_resp = requests.get(count_url)
    count_r = count_resp.json()
    print("Increased count to -----> ", count_r[0])

    if request.method != 'GET':
        return {},405

    url = 'http://users:80/api/v1/db/read_all_users'
    r1 = requests.post(url)
    if (r1.status_code == 204):
        print("Empty table")
        return {}, 204

    response1 = r1.json()['output']
    return jsonify(response1), 200

@app.route('/api/v1/db/clear', methods = ['POST'])
def cleardb():
    #should this be counted???
    count_url = 'http://users:80/api/v1/db/increment_count'
    count_resp = requests.get(count_url)
    count_r = count_resp.json()
    print("Increased count to -----> ", count_r[0])

    ride_users = table_ride_user_map.query.all()
    users = table_user.query.all()
    rides = table_ride.query.all()
    for user in users:
        db.session.delete(user)
        db.session.commit()
    return "database cleared", 200
     
     
if __name__ == '__main__':
    #app.run(host='0.0.0.0')
    app.debug = True
    app.run()
