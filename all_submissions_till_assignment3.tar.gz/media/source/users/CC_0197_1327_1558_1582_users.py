import requests, json
from flask import Flask, jsonify
from flask import request
from flask_sqlalchemy import SQLAlchemy
import datetime

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///user.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS']=False
db = SQLAlchemy(app)


class User(db.Model):
	id = db.Column(db.Integer, primary_key=True)
	username = db.Column(db.String(80), unique=True, nullable=False)
	password = db.Column(db.String(40), nullable=False)



def check_passwd(passwd):
	if len(passwd) == 40:
		for i in passwd:
			if i not in "ABCDEF0123456789abcdef":
				return 0
		return 1
	return 0
	
#def check_date_time(timestamp):

	

@app.route('/api/v1/db/read',methods=['POST'])
def read_db():
	id=request.get_json()["id"]
	if(id==1):
		uname=request.get_json()["username"]
		if(User.query.filter_by(username=uname).first()):
			return jsonify({"value":"exist"})
		else:
			return jsonify({"value":"no"})

	if(id==2):
		uname=request.get_json()["username"]		
		if(User.query.filter_by(username=uname).first()):
			return jsonify({"value":"exist"})
		else:
			return jsonify({"value":"no"})

	
	if(id==6):
		rideid=request.get_json()["rideid"]
		print(rideid)
		if(Rides.query.filter_by(id=rideid).first()):
			print("hello")
			return jsonify({"value":"exist"})
		else:
			return jsonify({"value":"no"})
	if(id==7):
		l=[]
		for i in User.query.all():
			l.append(i.username)
		if(len(l)==0):
			return jsonify([]),204
		return jsonify(l),200	

@app.route('/api/v1/db/write',methods=['POST'])
def write_db():
	id=request.get_json()["id"]
	if(id==1):
		uname=request.get_json()["username"]
		pswd=request.get_json()["password"]
		add_new_user=User(username=uname,password=pswd)
		db.session.add(add_new_user)
		#print(add_new_user)
		db.session.commit()
		#print(add_new_user)
	if(id==2):
		uname=request.get_json()["username"]
		rm_user= User.query.filter_by(username=uname).first()
		db.session.delete(rm_user)
		db.session.commit()
		return {},200
	if(id==6):
		for i in User.query.all():
			db.session.delete(i)
		db.session.commit()
		return {},200
	return {}, 200


@app.route('/api/v1/users',methods=['PUT'])
def add_user():
	count+=1
	if request.method == 'PUT':
		uname=request.get_json()["username"]
		r=requests.post(url='http://0.0.0.0:8080/api/v1/db/read', json={"id":1,"username":uname})
		#print(r.text)
		r=json.loads(r.text)
		if(r["value"]=="no"):
			pswd=request.get_json()["password"]
			if(check_passwd(pswd)):
				#print("hello")
				new_data={"id":1,"username":uname,"password":pswd}
				r1=requests.post(url='http://0.0.0.0:8080/api/v1/db/write',json=new_data)
				if r1.status_code==200:
					return {},201
			else:
				return "invalid pwd",400
		return "user",400
	return "",405


@app.route('/api/v1/users/<username>',methods=['DELETE'])
def delete_user(username):
	count+=1
	if request.method == 'DELETE':
		r=requests.post(url='http://0.0.0.0:8080/api/v1/db/read', json={"id":2,"username":username})
		r=json.loads(r.text)
		if(r["value"]=="no"):
			return {},400
		else:
			r=requests.post(url='http://0.0.0.0:8080/api/v1/db/write', json={"id":2,"username":username})
			return {}, 200
	else:
		return {},405

@app.route('/api/v1/db/clear',methods=['POST'])
def clear_db():
	count+=1
	if request.method == 'POST':
		r=requests.post(url='http://0.0.0.0:8080/api/v1/db/write', json={"id":6})
		return {},200
	else:
		return {},405 

@app.route('/api/v1/users',methods=['GET'])
def list_users():
	count+=1
	if request.method == 'GET':
		r=requests.post(url='http://0.0.0.0:8080/api/v1/db/read', json={"id":7})	
		print(r)
		if(r.status_code==204):
			return [],204
		else:
			return jsonify(r.json()),r.status_code
	else:
		return {},405

@app.route('/api/v1/_count',methods=['GET','DELETE'])
def count():
	global count
	if request.method == 'GET':
		return [count],200
	elif request.method == 'DELETE':
		count=0
		return {},200
	else:
		return {},405

@app.route('/')
def hello_world():
	return 'Hello, World! From Users'

if __name__=="__main__":
	db.create_all()
	app.run(debug=True,host="0.0.0.0",port=8080)
