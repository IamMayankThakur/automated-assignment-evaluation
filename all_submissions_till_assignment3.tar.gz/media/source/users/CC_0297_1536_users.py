from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask import Flask,jsonify,request,Response
import requests
from sqlalchemy import func
from sqlalchemy.sql import select,text
from sqlalchemy import create_engine
from numpy import genfromtxt
import datetime
import re

app = Flask(__name__)
app.config['SQLALCHEMY_TRACK_MODIFICATIONS']=False
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.sqlite'
db = SQLAlchemy(app)

#User table
class User(db.Model):
    username = db.Column(db.String(), primary_key=True, nullable=False)
    password = db.Column(db.String(), nullable=False)

    def __init__(self,username,password):
        self.username=username
        self.password=password
        
#HTTP
class http(db.Model):
	col = db.Column(db.Integer, primary_key=True, nullable=False)	
	count = db.Column(db.String)
	
	def __init__(self,count):
	    self.count=count

#AreaNum table
class area(db.Model):
	num = db.Column(db.String(),primary_key=True,nullable=False)
	area = db.Column(db.String())
	
	def __init__(self,num,area):
	    self.num=num
	    self.area=area
	    
db.create_all()

def Load_Data(file_name):
    data = genfromtxt(file_name, delimiter=',', skip_header=1,converters={1: lambda s: str(s,'utf-8')})
    return data.tolist()
    
file_name = "AreaNameEnum.csv" 
data = Load_Data(file_name) 
try:
	for i in data:
	    record = area(i[0],i[1])
	    db.session.add(record)
	db.session.commit()
except:
    db.session.rollback()

@app.before_request
def before():
    path=request.path
    if path.startswith('/api/v1/users'):
        c={"flag":"add","insert":{"count":"1"},"table":"http"}
        requests.post("http://users:80/api/v1/db/write",json=c)

#add user
@app.route("/api/v1/users",methods=["PUT"])
def add_user():
	try:
		un=request.get_json()["username"]
		pa=request.get_json()["password"]
	except:
		return {},500 	
	re=requests.post("http://users:80/api/v1/db/read",json={"table":"User","columns":["username"],"where":"username="+"'"+un+"'"})
	if(re.json()):
		return {},405
	try:
		sha=int(pa,16)
	except ValueError:
		return Response("Password should be 40 characters", status=400,mimetype='application/text')
	if(len(pa)!=40):
		return Response("Password should be 40 characters", status=400,mimetype='application/text')		
	else:
		j={"flag":"add","insert":{"username":un,"password":pa},"table":"User"}
		requests.post("http://users:80/api/v1/db/write",json=j)
		return {},201

#remove user	
@app.route('/api/v1/users/<username>',methods=["DELETE"])
def remove_user(username):
	re=requests.post("http://users:80/api/v1/db/read",json={"table":"User","columns":["username"],"where":"username="+"'"+username+"'"})
	if(not re.json()):
		return "Username does not exist",400
	else:
		j={"flag":"delete","username":username,"table":"User"}
		requests.post("http://users:80/api/v1/db/write",json=j)
		j={"flag":"delete","username":username,"table":"Rides"}
		requests.post("http://users:80/api/v1/db/write",json=j)
		return {},200


		
#list users
@app.route("/api/v1/users")
def list_users():
	re=requests.post("http://users:80/api/v1/db/read",json={"table":"User","columns":["username"]})
	t=re.json()
	new=[]
	for i in t:
		new.append(i["username"])
	return jsonify(new),200
	
	
#total http
@app.route("/api/v1/_count")
def total_http():
	re=requests.post("http://users:80/api/v1/db/read",json={"table":"http","columns":["col"]})
	t=re.json()
	l=[]
	l.append(len(t))
	return jsonify(l),200
	
#reset http
@app.route("/api/v1/_count",methods=["DELETE"])
def reset():
	http.query.delete()
	db.session.commit()
	return {},200
	
#database clear
@app.route("/api/v1/db/clear",methods=["POST"])
def clear():
	User.query.delete()
	db.session.commit()
	return {},200


#database read
@app.route("/api/v1/db/read",methods=["POST"])
def read():
	k=request.get_json()["table"]
	j=request.get_json()["columns"]
	if(k=="User"):
		new=[]
		for i in j:
			new.append(text(i))
		try:
			t=request.get_json()["where"]	
			stmt = select(new).where(text(t)).select_from(text("User"))
			return (execute(stmt))
		except:		
			stmt = select(new).select_from(text("User"))
			return (execute(stmt))
	elif(k=="http"):
		new=[]
		for i in j:
			new.append(text(i))
		stmt = select(new).select_from(text("http"))
		return (execute(stmt))
			
			
def execute(stmt):
	rs=db.engine.execute(stmt)
	d,a={},[]
	for row in rs:
		for col,val in row.items():
			d={**d,**{col:val}}
		a.append(d)
	return jsonify(a)
		

#database write
@app.route("/api/v1/db/write",methods=["POST"])
def write():
	flag=request.get_json()["flag"]
	k=request.get_json()["table"]
	if(flag=="add"):
		j=request.get_json()["insert"]
		if(k=="User"):
			us = User(j["username"],j["password"])
			db.session.add(us)
		if(k=="http"):
			ht= http(j["count"])
			db.session.add(ht)
	elif(flag=="delete"):
		if(k=="User"):
			un=request.get_json()["username"]
			User.query.filter_by(username=un).delete()		
	db.session.commit()
	return {}

if __name__=="__main__":
	app.debug=True
	app.run(host='0.0.0.0',port=80)
