from flask import Flask,request,jsonify,make_response,session
from flask_sqlalchemy import SQLAlchemy
import requests
import json
import sys
import re
from constants import Places
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column, Integer, String,ForeignKey ,DateTime
import requests
from flask import Response
from sqlalchemy.orm import sessionmaker,scoped_session
from enum import Enum
from datetime import datetime
from multiprocessing import Value

counter = Value('i', 0)

app = Flask(__name__)
app.config['SQLALCHEMY_DATAdb.Model_URI'] = 'sqlite:///:user_mgmt:'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)
#counter= 0
@app.errorhandler(405)
def method_not_found(e):
	path = request.path
	if(path == "/api/v1/users"):
		counter.value+=1
		return jsonify({}),405
class users(db.Model):
    __tablename__ = 'users'
    username = Column(String, primary_key=True)
    password = Column(String(40))
    def __init__(self,username,password):
    	self.password = password
    	self.username = username

#Writing to Database
@app.route('/api/v1/db/write',methods=['POST'])
def write():
	data = request.get_json()
	method = data['type']
	#add_user
	if(method == 'PUT'):
		username = data['username']
		password = data['password']
		create_user= users(username,password)
		db.session.add(create_user)
		db.session.commit()
		return make_response("added" ,200)
	#Remove user
	elif(method == 'DELETE'):
		username = data['username']
		db.session.query(users).filter(users.username == username).delete()
		db.session.commit()
		return  make_response("deleted",200)


#Reading the Database
@app.route('/api/v1/db/read',methods = ['POST'])
def read():
	data = request.get_json()
	table = data['table']
	#User table
	if(table == 'users'):
		read_data = users.query.all()
		user_data= dict()
		user_data['username'] = []
		user_data['password'] = []
		for user in read_data:
			user_data['username'].append(user.username)
			user_data['password'].append(user.password)
		return user_data

#Clearing the database
@app.route('/api/v1/db/clear',methods = ['POST'])
def clear_db():
	if(request.method != 'POST'):
		return jsonify ({}),405
	
	db.session.query(users).delete()
	db.session.commit()
	return make_response("",200)


#Adding User
@app.route('/api/v1/users',methods=['PUT'])
def add_user():
	with counter.get_lock():
		counter.value+=1
	if(request.method!='PUT'):
		return jsonify( {}),405
	data = request.get_json()
	username = data['username']
	password = data['password']
	user_data = requests.post('http://127.0.0.1:80/api/v1/db/read',json={"table":"users"})
	user_data = user_data.json()
	pattern = re.compile(r'\b[0-9a-f]{40}\b')

	for i in range(len(user_data["username"])):
		if(username == user_data["username"][i] or not(re.match(pattern,password))):
			return jsonify({}),400
	write = requests.post('http://127.0.0.1:80/api/v1/db/write',json={"type":request.method,"username":username,"password":password})
	if(write):
		return jsonify({}),201
	else:
		return jsonify({}),500

#Remove User
@app.route('/api/v1/users/<username>',methods=['DELETE'])
def remove_user(username):
	with counter.get_lock():
		counter.value+=1
	if(request.method!='DELETE'):
		return jsonify( {}),405
	
	user_data = requests.post('http://127.0.0.1:80/api/v1/db/read',json={"table":"users"})
	user_data = user_data.json()
	
	for i in range(len(user_data["username"])):	
		if(username == user_data["username"][i]):
			
			write = requests.post('http://127.0.0.1:80/api/v1/db/write',json={"type":request.method,"username":username})
			return jsonify({}),200
	else:
		return jsonify({}),400


#Listall the users.
@app.route('/api/v1/users',methods=['GET'])
def list_users():
	with counter.get_lock():
		counter.value+=1
	if(request.method!='GET'):
		return jsonify({}),405
	user_data = requests.post('http://127.0.0.1:80/api/v1/db/read',json={"table":"users"})
	user_data = user_data.json()
	print(user_data)
	user_list = []
	for i in range(len(user_data['username'])):
		user_list.append(user_data['username'][i])
		print(type(user_list[0]),user_list[0])
	if(len(user_list)!=0):
		return jsonify(user_list),200
	else:
		return jsonify({}),204

#Get the count of HTTP requests
@app.route('/api/v1/_count',methods = ['GET'])
def count_requests():
	if(request.method!='GET'):
		return jsonify({}),405
    
	return jsonify([counter.value]),200

#Reset the Http requests counter
@app.route('/api/v1/_count',methods = ['DELETE'])
def reset_count():
	
	if(request.method!='DELETE'):
		return jsonify({}),405
	counter.value = 0
	return jsonify({}),200






if __name__ == '__main__':
	db.create_all()	
	app.debug=True
	app.run(host = '0.0.0.0',port=80)









