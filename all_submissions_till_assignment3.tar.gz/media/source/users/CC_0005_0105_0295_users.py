from flask import Flask,request, render_template,\
jsonify,request,abort
import string,requests
from flask import _request_ctx_stack
import MySQLdb
from constants import Area
import re 
from datetime import datetime
import datetime
import ast
import json



app=Flask(__name__)

#Function to check if password is valid
def isHex(password):
	return all(c in string.hexdigits for c in password)
methods1=["GET","DELETE"]
methods=["GET","PUT"]

#------------------1-------------------
@app.route("/api/v1/users",methods=["PUT"])

def add_user():

	f = open('httpcount.txt','r+')
	l = f.readlines()
	f.close()
	count = int(l[0])
	count=count+1
	f = open("httpcount.txt","w+")
	f.write(str(count))
	f.close()

	if(request.method not in methods):
		return("Method Not Allowed!!",405)
	username=request.get_json()["username"]
	password=request.get_json()["password"]
	#Read from db to check if username exists
	payload={'table':'usernames','columns':["username"],'where':'username='+"'"+username+"'"}
	r=requests.request("POST",'http://127.0.0.1:9000/api/v1/db/read',json=payload)
	catalog=json.loads(r.content.decode('utf8'))   
	#If username exists, abort
	if(len(catalog["data"])!=0):
        	abort(400,description="Bad Request")
	
	#If password doesn't match specs, abort
	if(len(password)<40 or isHex(password)!=True):
        	abort(400,description="Bad Request")

	#valid username and password, insert into database
	else:
		payload={'table':'usernames','insert':[username,password],'columns':["username","password"],'type':'INSERT'}
		r=requests.post('http://127.0.0.1:9000/api/v1/db/write',json=payload)
		return jsonify({}),201

#-------------------2------------------------
@app.route("/api/v1/users/<username>",methods=["DELETE"])

def remove_user(username):

	f = open('httpcount.txt','r+')
	l = f.readlines()
	f.close()
	count = int(l[0])
	count=count+1
	f = open("httpcount.txt","w+")
	f.write(str(count))
	f.close()

	if(request.method!="DELETE"):
		abort(405,description="Method Not Allowed")
	
	#Validating if username exists
	payload={'table':'usernames','columns':["username"],'where':'username='+"'"+username+"'"}
	r=requests.post('http://127.0.0.1:9000/api/v1/db/read',json=payload)
	catalog=r.json()

	#Invalid username
	if(len(catalog["data"])==0):
		abort(400,description="Bad Request")

	#Valid username hence delete
	payload={'table':'usernames','insert':[username],'columns':["username"],'type':'DELETE'}
	r=requests.post('http://127.0.0.1:9000/api/v1/db/write',json=payload)
	#Deleting usernames from other DB(ride) in Microservice2
	payload={'table':'ride','insert':[username],'columns':["created_by","users"],'type':'DELETE1'}
	r=requests.request("POST",'http://3.212.249.140:80/api/v1/db/write',json=payload)
	return jsonify({}),200

#------------New 1------------------
@app.route("/api/v1/users",methods=["GET"])

def list_users():

	f = open('httpcount.txt','r+')
	l = f.readlines()
	f.close()
	count = int(l[0])
	count=count+1
	f = open("httpcount.txt","w+")
	f.write(str(count))
	f.close()

	if(request.method not in methods):
		return("Method Not Allowed",405)
	#Read from db the users
	payload={'table':'usernames','columns':["username"],'where':''}
	r=requests.request("POST",'http://172.17.0.1:9000/api/v1/db/read',json=payload)
	catalog=r.json() 
	#If no users
	
	if(len(catalog["data"])==0):
        	return jsonify({}),204
	else:
		l1=[]
		for i in catalog['data']:
			l1.append(i[0])
		#Needed [] according to specifications
		return (jsonify(l1),200)

#-------Database connection-------------
def connection():
	
	conn = MySQLdb.connect(host='db_user',user = "root",passwd = "root",port = 3306,db = "assig2")
	c = conn.cursor()

	return c, conn

#----------New 2-----------------------

@app.route("/api/v1/db/clear",methods=["POST"])

def delete_db():


	c, conn = connection()
	tablename="usernames"
	sql = "DELETE" +" from " + tablename+";"
	c.execute(sql)
	conn.commit()
	return ("OK",200)

#-------------------8---------------------------
@app.route("/api/v1/db/write",methods=["POST"])

def write_db():

	#f = open('httpcount.txt','r+')
	#l = f.readlines()
	#f.close()
	#ount = int(l[0])
	#count=count+1
	#f = open("httpcount.txt","w+")
	#f.write(str(count))
	#f.close()

	
	c, conn = connection()
	tablename=request.get_json()["table"]
	data=request.get_json()["insert"]
	column=request.get_json()["columns"]
	type1 = request.get_json()["type"] #INSERT/DELETE/UPDATE

	col_string_1=""
	for i in column:#Columns to write to
		col_string_1=col_string_1+i+','
	col_string=col_string_1[:-1]

	val_string_1=""
	for i in data:#Data to write in corresponding columns
		val_string_1=val_string_1+"'"+i+"'"+','
	val_string=val_string_1[:-1]

	if(type1=="INSERT"):
			sql = "Insert into "+tablename+'('+col_string+')'+" values "+'('+val_string+');'
	elif(type1=="DELETE"):
			sql = "Delete from "+tablename+" Where "+column[0] +"=" +"'"+data[0]+"'"+";"
	
	c.execute(sql)
	conn.commit()
	
	return("OK",200)

#-------------------9------------------------
@app.route("/api/v1/db/read",methods=["POST"])

def read_db():

	#f = open('httpcount.txt','r+')
	#l = f.readlines()
	#f.close()
	#count = int(l[0])
	#count=count+1
	#f = open("httpcount.txt","w+")
	#f.write(str(count))
	#f.close()

	c, conn = connection()
	tablename=request.get_json()["table"]
	column_list=request.get_json()["columns"]
	condition = request.get_json()["where"]

	col_string_1=""
	for i in column_list:
		col_string_1=col_string_1+i+','
	col_string=col_string_1[:-1]
	
	if(len(condition)!=0):#If condition specified
		sql = "select " +col_string+" from " + tablename+" where "+str(condition)+";"

	else:#General select* query
		sql = "select " +col_string+" from " + tablename+";"
	
	c.execute(sql)
	conn.commit()
	return (jsonify(data=c.fetchall()),200)

#-------------------GET HTTP COUNT-------------------------------

@app.route("/api/v1/_count",methods=["GET"])

def get_count():
	if(request.method not in methods1):
		abort(405,"Method Not Allowed")
	f = open('httpcount.txt','r+')
	l = f.readlines()
	f.close()
	http_count = int(l[0])
	return (jsonify([http_count]))

#----------------RESET HTTP COUNT--------------------------
@app.route("/api/v1/_count",methods=["DELETE"])

def reset_count():
	if(request.method not in methods1):
		abort(405,"Method Not Allowed")
	f = open("httpcount.txt","w+")
	f.write('0')
	f.close()
	return jsonify({}),200
	
#----------------------------METHOD NPOT ALLOWED------------
@app.errorhandler(405)

def method_not_allowed(e):
	
	if(request.url.split('/')[5] in ["_count","db"]):
		return("Method Not Allowed",405)
	f = open('httpcount.txt','r+')
	l = f.readlines()
	f.close()
	count = int(l[0])
	count = count + 1
	f = open('httpcount.txt','w+')
	f.write(str(count))
	f.close()
	return ("Method Not Allowed",405)

#----------------------------MAIN-----------------------------
if __name__=='__main__':
	#f = open('httpcount.txt','w')
	#f.write(0)
	#f.close()
	app.debug=True
	app.run(host='0.0.0.0',port='9000')
	

