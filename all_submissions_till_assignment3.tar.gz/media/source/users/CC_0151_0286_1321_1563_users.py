from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy

import requests
import os
import sys

from datetime import datetime
import csv

basedir = os.path.abspath(os.path.dirname(__file__))

application = Flask(__name__)
application.config["DEBUG"] = True
application.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///" + \
    os.path.join(basedir, "db.sqlite")

db = SQLAlchemy(application)

db_write_url = "http://172.17.0.1:80/api/v1/db/write"
db_read_url = "http://172.17.0.1:80/api/v1/db/read"
db_clear_url = "http://172.17.0.1:80/api/v1/db/clear"

count = 0
method = ["GET","PUT","POST","HEAD"]

class User(db.Model):
    username = db.Column(db.Text(), primary_key=True,
                         nullable=False, autoincrement=False)
    password = db.Column(db.Text(), nullable=False)

@application.route("/api/v1/users/test")
def hello():
        return "In user"

@application.route("/api/v1/users",methods=method)
def add_user():
    global count
    count += 1

    if(request.method == "GET"):
        username = request.args.get('username')

        username_query_dict = {"method": "select",
                               "table": "user",
                               "columns": ["username"],
                               "values": []
                               }

        username_response = requests.post(
            db_read_url, json=username_query_dict).json()["results"]

        if(username_response == []):
            response_msg =[]
            status = 204
        else:
            response_msg = []
            for user in username_response:
                response_msg.append(user)
            status = 200
    elif(request.method=="PUT"):
        req_data = request.get_json()
        name = req_data["username"]
        pword = req_data["password"]

        if(name == ""):
            response_msg = "Blank username"
            status = 400
            print("blank username")
            return jsonify(response_msg, status)

        valid_token = {"A", "B", "C", "D", "E", "F", "0", "1", "2", "3", "4", "5", "6", "7",
                       "8", "9", "a", "b", "c", "d", "e", "f"}

        wcount = 0
        for i in pword:
            if i in valid_token:
                wcount = wcount + 1

        if(wcount == 40):

            insert_dict = {"method": "insert",
                           "columns": ["username", "password"],
                           "table": "user",
                           "values": [name, pword]
                           }

            query_dict = {"method": "select",
                          "columns": ["username"],
                          "table": "user",
                          "values": [name]
                          }

            response = requests.post(
                db_read_url, json=query_dict).json()["results"]
            if(response == []):
                res = requests.post(db_write_url, json=insert_dict)
                response_msg = {}
                status = 201
            else:
                print("user_exisits")
                response_msg = {}
                status = 400
        else:
            print("wrong pa")
            response_msg = {}
            status = 400
    else:
        response_msg={}
        status=405
    return jsonify(response_msg), status

@application.route("/api/v1/users/<name>",methods=method)
def remove_user(name):
    global count
    count += 1

    if(request.method != "DELETE"):
        return jsonify({}),405

    query_dict = {"method": "select",
                  "table": "user",
                  "columns": ["username"],
                  "values": [name]
                  }

    response = requests.post(db_read_url, json=query_dict).json()["results"]

    if response == []:
        response_msg = {'response': 'User not found'}
        status = 400
    else:
        delete_dict = {"method": "delete",
                       "table": "user",
                       "columns": ["username"],
                       "values": [name]
                       }

        requests.post(db_write_url, json=delete_dict)
        response_msg = {'response': 'User successfully Deleted'}
        status = 200

    return jsonify(response_msg), status


@application.route("/api/v1/db/write", methods=["POST"])
def db_write():
    data = request.get_json()

    if(data["method"] == "insert"):
        if(data["table"] == "user"):
            user = User(username=data["values"][0], password=data["values"][1])
            db.session.add(user)
            db.session.commit()
            response = {"response": "User inserted"}
            status = 201
        else:
            response = {"response": "Table Not Present"}
            status = 405

    elif(data["method"] == "delete"):
        if(data["table"] == "user"):
            user = User.query.filter_by(username=data["values"][0]).first()
            if(user is not None):
                db.session.delete(user)
                db.session.commit()
                response = {"response": "User deleted"}
                status = 200
            else:
                response = {"response": "User not present"}
                status = 405
        else:
            response = {"response": "Table Not Present"}
            status = 405

    else:
        response = {"response": "Method Not Supported"}
        status = 405

    return jsonify(response), status


@application.route("/api/v1/db/read", methods=["POST"])
def db_read():
    data = request.get_json()
    res = []
    status = 200
    if(data["method"] == "select"):
        if(data["table"] == "user"):
            if(data["values"]):
                user = User.query.filter_by(username=data["values"][0]).first()
                if(user):
                    res = [user.username, user.password]
            else:
                users = User.query.all()
                for user in users:
                    res.append(user.username)
            response = {"results": res}
        else:
            response = {"response": "Table Not Present"}
            status = 405

    else:
        response = {"response": "Method Not Supported"}
        status = 405

    return jsonify(response), status


@application.route("/api/v1/db/clear", methods=["POST"])
def db_clear():
    meta = db.metadata
    for table in reversed(meta.sorted_tables):
        db.session.execute(table.delete())
    db.session.commit()
    return jsonify("DB deleted."), 200


@application.route("/api/v1/_count", methods=["GET", "DELETE"])
def count_request():
    global count
    if(request.method == "GET"):
        response_msg = [count]
    else:
        count = 0
        response_msg = []
    return jsonify(response_msg), 200


if __name__ == "__main__":
    db.create_all()
    application.run(debug=True,port=80,host="0.0.0.0")
