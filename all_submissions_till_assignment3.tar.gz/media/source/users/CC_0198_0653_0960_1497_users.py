from flask import Flask, request, flash, url_for, redirect, render_template
from flask import Flask, render_template,\
jsonify,request,abort
from flask import Flask, Response
import string 
import pandas as pd
import csv
import re 
import json
import datetime
import ast
from sqlalchemy import create_engine,DateTime
from sqlalchemy.exc import IntegrityError
import requests
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///2.db'
db = SQLAlchemy(app)
engine = create_engine(app.config['SQLALCHEMY_DATABASE_URI'])



class users_det(db.Model):
   username = db.Column('username', db.String, primary_key = True)
   password = db.Column('password',db.String(10))

   def __init__(self, username,password):
        self.username = username
        self.password = password

class table_count(db.Model):
    __tablename__ = 'table_count'
    count = db.Column(db.Integer, primary_key=True)
    
    def __init__(self, count):
        self.count = count
        print("Initilized count")

db.create_all()


try:
    exec_str = "INSERT INTO table_count(count) VALUES (0)"
    engine.execute(exec_str)
except:
    db.session.rollback()

@app.route('/api/v1/_count', methods = ['GET'])
def read_count():
    if request.method != 'GET':
        return {}, 405
    
    count_obj = table_count.query.all()

    for i in count_obj:
        print(i.count)
        return jsonify([i.count]), 200
    return "error", 404

@app.route('/api/v1/_count', methods = ['DELETE'])
def reset_count():
    if request.method != 'DELETE':
        return {}, 405
    
    count_obj = table_count.query.all()
    print("count_obj",count_obj)
    for i in count_obj:
        print("Before ", i.count)
        i.count = 0
        db.session.commit()
        return {}, 200
    return "error", 404


@app.route('/api/v1/db/increment_count', methods = ['GET'])   
def increment_count():
    if request.method != 'GET':
        return {}, 405

    count_obj = table_count.query.all()
    print("count_obj",count_obj)
    for i in count_obj:
        print("---- old count ---- ", i.count)
        i.count = i.count + 1
        db.session.commit()
        return jsonify([i.count]), 200
    return "error", 404

@app.route("/api/v1/db/write",methods=["POST"])
def insert():
        from sqlalchemy.exc import IntegrityError
        table=request.get_json()["table"]
        insert=request.get_json()["insert"]
        column=request.get_json()["column"]
        print('user_ins',insert)
        if(request.json['type']=="del_user"):
                        if(users_det.query.filter_by(username=insert[0]).first()):
                                print("writing")
                                users_det.query.filter_by(username=insert[0]).delete()
                                db.session.commit()
                                return {},200
                        else:
                                return {},400
        elif(request.json['type']=="del_ride"):
                print('insert',insert)
                ride_details.query.filter_by(rideId=int(insert[0])).delete()
                                            
                db.session.commit()
                return {},200
        elif(request.json['type']=="clear"):
            execstr = 'DELETE from '+table
            print(execstr)
            engine.execute(execstr)
            db.session.commit()
            return {},200
        else:
                str1=''
                str2=''
                for i in range(len(column)):
                        str1=str1+'"'+str(insert[i])+'"'+','
                        str2=str2+str(column[i])+','
                str3 = str1.strip(',')
                str4 = str2.strip(',')
                if(column[0]=="users"):
                        execstr = 'UPDATE '+table+' SET users='+'"'+ insert[0] +'"'+' where rideId='+'"'+ insert[1] +'"'
                        print(execstr)
                        engine.execute(execstr)
                        db.session.commit()
                        return {},200
                else:
                        try:
                                execstr = 'INSERT INTO '+table+'('+str4+') VALUES'+'('+str3+')'
                                print(execstr)
                                engine.execute(execstr)
                                db.session.commit()
                                return {},201
                        except IntegrityError:
                                return {},400

        

@app.route("/api/v1/db/read",methods=["POST"])
def read():
        table=request.get_json()["table"]
        where=request.get_json()["where"]
        columns=request.get_json()["columns"]
        str1=''
        str2=''
        print(where)
        new_where=where.split('=')
        print('new where',new_where)
        if(len(new_where)>2):
                a=list()
                b=new_where[1].split("and ")
                a.append(new_where[0])
                print(len(b))
                for i in range(len(b)):
                        
                        if(i==0):
                                a.append(b[i].strip())
                        else:
                                a.append(b[i])
                a.append(new_where[2])
                print('a',a)
                new_where=a
        print('ab',new_where)       
        for i in range(len(columns)):
                str2=str2+str(columns[i])+','
        str4 = str2.strip(',')

        if(new_where[0]=="username"): 
            if(users_det.query.filter_by(username=new_where[1]).first()):
                execstr = 'SELECT '+str4+ ' FROM ' +table + ' WHERE '+new_where[0]+' = ' +'"'+ new_where[1] +'"'
                print(execstr)
                engine.execute(execstr)
                return {},200
            else:
                return {},400
        elif(new_where[0]=="password"):
            if(users_det.query.filter_by(password=new_where[1]).first()):
                execstr = 'SELECT '+str4+ ' FROM ' +table + ' WHERE '+new_where[0]+' = ' +'"'+ new_where[1] +'"'
                print(execstr)
                engine.execute(execstr)
                return {},200
            else:
                return {},400
        elif(where==''):
            execstr = 'SELECT '+str4+ ' FROM ' +table 
            print(execstr)
            l=db.engine.execute(execstr)
            d, a = {}, []
            for rowproxy in l:
                    for column, value in rowproxy.items():
                            d = {**d, **{column: value}}
                            print(d)
                    a.append(d)
            return jsonify(a)
                             
        return {},400

@app.route("/api/v1/users",methods=["PUT"])
def adduser():
        
        if request.method != 'PUT':
            requestss = requests.get('http://users:80/api/v1/db/increment_count')

            return {},405
        requestss = requests.get('http://users:80/api/v1/db/increment_count')
        user=request.get_json()["username"]
        pin=request.get_json()["password"]
        if(len(pin)==40 and re.findall("^[0-9a-fA-F]+$",pin)):
                response=requests.post('http://users:80/api/v1/db/write',json={"table":"users_det","column":["username","password"],"insert":[user,pin],"type":''})
                return {},response.status_code
        else:
                return {},400
               
@app.route("/api/v1/users/<string:name>",methods=["DELETE"])
def removeuser(name):
        requestss = requests.get('http://users:80/api/v1/db/increment_count')
        print(name)
        type="del_user"
        response=requests.post('http://users:80/api/v1/db/read',json={"table":"users_det","columns":["username","password"],"where":'username='+name})
        if(response.status_code == 200):
                resp=requests.post('http://users:80/api/v1/db/write',json={"table":"users_det","column":["username"],"insert":[name],"type":type})

                
                if(resp.status_code==400):
                        return {},400
                else:
                        return {},200
        else:
                return jsonify("user doesnt exist"),400

@app.route("/api/v1/users",methods=["GET"])
def listusers():
    requestss = requests.get('http://users:80/api/v1/db/increment_count')
    response=requests.post('http://users:80/api/v1/db/read',json={"table":"users_det","columns":["username"],"where":''})
    d, a = {}, []
    for i in response.json():
                    for column, value in i.items():
                            d = {**d, **{column: value}}
                            print(d)
                    a.append(d)
    if(len(a)>0):
            return jsonify(a),200
    else:
            return jsonify(a),204

@app.route("/api/v1/db/clear",methods=["POST"])  
def clear_db():
    requestss = requests.get('http://users:80/api/v1/db/increment_count')
    type="clear"
    response=requests.post('http://users:80/api/v1/db/read',json={"table":"users_det","columns":["username","password"],"where":''})
    d, a = {}, []
    for rowproxy in response.json():
            for column, value in rowproxy.items():
                    d = {**d, **{column: value}}
                    print(d)
            a.append(d)
    if(len(a)>0):
            res=requests.post('http://users:80/api/v1/db/write',json={"table":"users_det","column":[],"insert":[],"type":type})
            if(res.status_code==200):
                    return {},200

if __name__ == '__main__':  
    app.debug=True
    app.run(host="0.0.0.0",port=80)
