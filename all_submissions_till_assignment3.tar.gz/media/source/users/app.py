from flask import Flask, request, Response, session
from flask_sqlalchemy import SQLAlchemy
import requests as req
import json
import config
from datetime import datetime
from areas import area #dictionary with number to area name mapping
import re
import argparse

parser = argparse.ArgumentParser()
parser.add_argument("http_count")
args = parser.parse_args()
args.http_count = int(args.http_count)

app = Flask(__name__)
app.config.from_object(config.Config)
app.secret_key = config.Config.SECRET_KEY
db = SQLAlchemy(app)  # object to communicate with db

class User(db.Model):
	id = db.Column(db.Integer, primary_key=True)
	username = db.Column(db.String(80), nullable=False, unique=True)
	password = db.Column(db.String(40), nullable=False)

	def __repr__(self):
		return json.dumps({'username': self.username, 'password': self.password})

	def as_dict(self):
		return {c.name: getattr(self, c.name) for c in self.__table__.columns}
db.create_all()

def resolve_area(area_num):
	try:
		return area[int(area_num)]
	except:
		return False

def validate_date(date_text):
	try:
		datetime.strptime(date_text, '%d-%m-%Y:%S-%M-%H')
		return True
	except:
		return False

def isValidHash(text):
	return re.match(r"^([0-9a-fA-F]{40})$", text)

def write_to_db(write_params):
	return req.post(
		url=app.config['URL']+'/api/v1/db/write',
		data=json.dumps(write_params),
		headers={'Content-Type': 'application/json'}
	)

def read_from_db(read_params):
	return req.post(
		url=app.config['URL']+'/api/v1/db/read',
		data=json.dumps(read_params),
		headers={'Content-Type': 'application/json'}
	)


@app.route('/api/v1/users', methods=['PUT'])
def create_user():
	# Get the request body
	req_data = request.get_json()
	args.http_count += 1
	try:
		req_data['username']
		isValidHash(req_data['password'])
	except:
		return Response(status=400)
	if req_data['username'] != '' and isValidHash(req_data['password']):
		# send a post request to write into the DB with the username and password
		write_request_body = {
			'type': 'add',
			'table': 'user',
			'data': {
				'username': req_data['username'],
				'password': req_data['password']
			}
		}
		write_request = write_to_db(write_request_body)
		if write_request.status_code == 200:
			return Response(status=201)
		else:
			return Response(status=400)
	else:
		return Response(status=400)

# remove user
@app.route('/api/v1/users/<username>', methods=['DELETE'])
def remove_user(username):
	args.http_count += 1
	if username != '':
		# send a post request to delete the user from the DB
		delete_request_body = {
			'type': 'delete',
			'table': 'user',
			'data': {'username': username}
		}
		write_request = write_to_db(delete_request_body)
		if write_request.status_code == 200:
			return Response(status=200)
		else:
			return Response(status=400)
	else:
		return Response(status=405)

#list all users
@app.route('/api/v1/users', methods=['GET'])
def list_users():
	args.http_count += 1
	read_request_body = {
		'table' : 'user'
	}
	usernames_list_request = read_from_db(read_request_body)
	usernames_list = [user['username'] for user in json.loads(usernames_list_request.content)]
	return Response(json.dumps(usernames_list), status=200, mimetype='application/json')

#clear DB
@app.route('/api/v1/db/clear', methods=['POST'])
def clear_db():
	clear_db_body = {
		'type':'clear'
	}
	clear_request = write_to_db(clear_db_body)
	if clear_request.status_code == 200:
		clear_rides_db_request = req.post(url = app.config['RIDES_URL']+'/api/v1/db/clear')
		return Response(status=clear_rides_db_request.status_code)
	else:
		return Response(status=405)

#get total http requests made
@app.route('/api/v1/_count', methods=['GET'])
def get_count():
	return Response(json.dumps([args.http_count]), status=200)

#reset total http requests made
@app.route('/api/v1/_count', methods=['DELETE'])
def reset_count():
	args.http_count = 0
	return Response(status=200)

# write to db
@app.route('/api/v1/db/write', methods=['POST'])
def write_db():
	# Get the request body
	req_data = request.get_json()

	#If the operation is to clear the DB
	if req_data['type'] == 'clear':
		db.drop_all(bind=None)
		db.create_all()
		message = {"success": True, "message": "DB successfully deleted"}
		return Response(json.dumps(message), status = 200, mimetype = 'application/json')

	# Check if all the fields are present in the request body
	if 'type' not in req_data or 'table' not in req_data or 'data' not in req_data:
		message = {"success": False,
				   "message": "Please follow correct request body format"}
		return Response(json.dumps(message), status=400, mimetype='application/json')
	table_name = req_data['table']
	data = req_data['data']	
	# if the operation is to be performed on the user table
	if table_name.lower() != 'user':
		message = {"success": False,
				   "message": "No such table is present in the db"}
		return Response(json.dumps(message), status=400, mimetype='application/json')
	# if the operation is to add to user table
	if req_data['type'] == 'add':
		# check if user already exists in the table by the username
		if not User.query.filter_by(username=data['username']).first():
			# if not already present add a new user to the table
			new_user = User(
				username=data['username'], password=data['password'])
			db.session.add(new_user)
			db.session.commit()
			message = {"success": True,
						"message": "User successfully added"}
			return Response(json.dumps(message), status=200, mimetype='application/json')
		else:
			message = {"success": False, "message": "User already exists"}
			return Response(json.dumps(message), status=201, mimetype='application/json')
	# if the operation is to delete a user from the table
	elif req_data['type'] == 'delete':
		user = User.query.filter_by(username=data['username']).first()
		# check if user is already present in the table
		if user:
			read_request_body = {
				'table': 'ride',
				'wheres': {
					'created_by' : data['username'],
				}
			}
			rides_request=req.post(
				url=app.config['RIDES_URL']+'/api/v1/db/read',
				data=json.dumps(read_request_body),
				headers={'Content-Type': 'application/json', 'Origin':'ec2-34-229-223-83.compute-1.amazonaws.com'}
			)
			ride_detail = json.loads(rides_request.content)
			for ride in ride_detail:
				write_request_body = {
					'table': 'ride',
					'type': 'delete',
					'data': {'rideId': ride['id']},
					'cascade' : True
				}
				req.post(
					url=app.config['RIDES_URL']+'/api/v1/db/write',
					data=json.dumps(write_request_body),
					headers={'Content-Type': 'application/json', 'Origin':'ec2-34-229-223-83.compute-1.amazonaws.com'}
				)
			db.session.delete(user)
			db.session.commit()
			message = {"success": True,
						"message": "User successfully deleted"}
			return Response(json.dumps(message), status=200, mimetype='application/json')
		else:
			message = {"success": False, "message": "User not found"}
			return Response(json.dumps(message), status=400, mimetype='application/json')
	else:
		message = {"success": False, "message": "Write type unidentified"}
		return Response(json.dumps(message), status=500, mimetype='application/json')

# read from db
@app.route('/api/v1/db/read', methods=['POST'])
def read_db():
	# send { table : table_name, wheres : {attr1:attr1, attr2:attr2, ...} }
	req_data = request.get_json()
	table_name = req_data['table'].lower()
	try: 
		wheres = req_data['wheres']
	except:
		wheres = []
	tables = {'user': User}
	if table_name in tables:
		Table = tables[table_name]
	else:
		message = {"success": False,
				   "message": "No such table is present in the db"}
		return Response(json.dumps(message), status=400, mimetype='application/json')
	query = {}
	for attr in wheres:
		if attr in app.config['ATTRIBUTES'][table_name] or attr == 'id':
			query.update({str(attr): wheres[attr]})
	result = Table.query.filter_by(**query)
	# serialize the result into python dict
	try:
		result = [i.as_dict() for i in result]
		return Response(json.dumps(result), mimetype='application/json')
	except:
		return Response(json.dumps({}), mimetype='application/json')

@app.route('/api/v1/users', defaults={'u_path': ''}, methods=['POST', 'DELETE'])
@app.route('/api/v1/users/<path:u_path>', methods=['GET', 'POST', 'PUT', 'DELETE'])
def fallback(u_path):
	args.http_count+=1
	return Response(status = 200)
		
if __name__ == "__main__":
	app.run(debug=True,port=8000,host='0.0.0.0')
