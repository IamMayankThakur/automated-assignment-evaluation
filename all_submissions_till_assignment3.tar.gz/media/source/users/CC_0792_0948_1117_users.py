from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy 
from flask_marshmallow import Marshmallow
from sqlalchemy.orm.attributes import flag_modified
import os
from sqlalchemy import PickleType
import requests
import re
import sys
from datetime import datetime
from multiprocessing import Value

AreaEnum=list(range(1,199))
counter = Value('i', 0)

# Init app
app = Flask(__name__)
basedir = os.path.abspath(os.path.dirname(__file__))
# Database
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(basedir, 'db2.sqlite')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False 
# Init db
db = SQLAlchemy(app)
# Init ma
ma = Marshmallow(app)

# User Class/Model
class User(db.Model):
  userId = db.Column(db.Integer, primary_key=True)
  username = db.Column(db.String())
  password = db.Column(db.String())
 
  def __init__(self, username, password):
    self.username = username
    self.password = password

# User Schema
class UserSchema(ma.Schema):
  class Meta:
    fields = ('username', 'password')

# Init schema
user_schema = UserSchema()
users_schema = UserSchema(many=True)
db.create_all()

#1.Add user
@app.route('/api/v1/users', methods=['PUT'])
def add_user():
  with counter.get_lock():
    counter.value += 1

  if(request.method!= 'PUT'):
    return jsonify({}), 405
  username = request.json['username']
  password = request.json['password']
  pattern=re.compile(r'\b([0-9a-f]|[0-9A-F]){40}\b')
  dic={}
  dic["username"]=username
  dic["password"]=password
  dic["some"]="add_user"
  urlr=" http://52.45.67.99:80/api/v1/db/read"
  headers={'Content-type':'application/json','Accept':'text/plain'}
  r=requests.post(url=urlr,json=dic,headers=headers)
  result= r.text
  if((result=="None") and (re.search(pattern, password)) and len(username)!=0):
    urlw=" http://52.45.67.99:80/api/v1/db/write"
    w=requests.post(url=urlw,json=dic,headers=headers)
    return jsonify({}), 201
  else:
    return jsonify({}), 400

#2.Delete user
@app.route('/api/v1/users/<username>', methods=['DELETE'])
def remove_user(username):
  with counter.get_lock():
    counter.value += 1

  if(request.method!= 'DELETE'):
    return jsonify({}), 405
  dic={}
  dic["some"]="remove_user"
  dic["username"]=username
  urlr=" http://52.45.67.99:80/api/v1/db/read"
  headers={'Content-type':'application/json','Accept':'text/plain'}
  r=requests.post(url=urlr,json=dic,headers=headers)
  result = r.text
  if(result=="None"):
    return jsonify({}), 400
  else:
    urlw=" http://52.45.67.99:80/api/v1/db/write"
    w=requests.post(url=urlw,json=dic,headers=headers)
    return jsonify({}), 200

#3. List users
@app.route('/api/v1/users', methods=['GET'])
def list_users():
  with counter.get_lock():
    counter.value += 1

  if(request.method != 'GET'):
    return jsonify({}), 405
  dic={}
  dic["some"]="list_users"
  urlr=" http://52.45.67.99:80/api/v1/db/read"
  headers={'Content-type':'application/json','Accept':'text/plain'}
  r=requests.post(url=urlr,json=dic,headers=headers)
  result=r.json()
  if(not bool(result)):
    return jsonify({}), 204
  else:
    return jsonify(result), 200

#Clear db
@app.route('/api/v1/db/clear', methods=['POST'])
def clear():
  with counter.get_lock():
    counter.value += 1

  if(request.method!= 'POST'):
    return jsonify({}), 405
  dic={}
  dic["some"]="clear"
  urlr=" http://52.45.67.99:80/api/v1/db/read"
  headers={'Content-type':'application/json','Accept':'text/plain'}
  r=requests.post(url=urlr,json=dic,headers=headers)
  result = r.text
  if(result=="False"):
    return jsonify({}), 400
  else:
    urlw=" http://52.45.67.99:80/api/v1/db/write"
    w=requests.post(url=urlw,json=dic,headers=headers)
    return jsonify({}), 200

#total # of http reqs
@app.route('/api/v1/_count', methods=['GET'])
def total():
  if(request.method!='GET'):
    return jsonify({}), 405

  lis = []
  no = counter.value
  lis.append(no)
  return str(lis), 200

  
#delete http reqs
@app.route('/api/v1/_count', methods=['DELETE'])
def delete():
  if(request.method!='DELETE'):
    return jsonify({}), 405
  with counter.get_lock():
    counter.value = 0
  if(counter.value == 0):
    return jsonify({}), 200


#8.Write db
@app.route('/api/v1/db/write', methods=['POST'])
def write_db():
  content=request.json
  if(content["some"]=="add_user"):
    user=content["username"]
    pswd=content["password"]
    new_user=User(user, pswd)
    db.session.add(new_user)
    db.session.commit()
    return user_schema.jsonify(new_user)

  elif (content["some"]=="remove_user"):
    user1=content["username"]
    user = User.query.filter_by(username=user1).first()
    db.session.delete(user)
    db.session.commit()
    return content

  elif (content["some"]=="clear"):
    db.session.query(User).delete()
    #db.session.query(Ride).delete()
    db.session.commit()
    return content

#9.Read db
@app.route('/api/v1/db/read', methods=['POST'])
def read_db():
  content=request.json
  if(content["some"]=="add_user"):
    user1=content["username"]
    user = User.query.filter_by(username=user1).first()
    return str(user)

  elif (content["some"]=="remove_user"):
    content=request.json
    user1=content["username"]
    user = User.query.filter_by(username=user1).first()
    return str(user)

  elif (content["some"]=="list_users"):
    user = User.query.all()
    sk=str(user)
    all_users=[]
    x=map(int, re.findall(r'\d+',sk))
    z=list(x)
    if(len(z)==0):
      return user_schema.jsonify(user)
    else:
      for i in z:
        y=User.query.get(i)
        all_users.append(y.username)
      return jsonify(all_users)

  elif (content["some"]=="clear"):
    x = User.query.all()
    #y = Ride.query.all()
    if not x:
      return "False"
    else:
      return "True"

# Run Server
if __name__ == '__main__':
  app.run(host="0.0.0.0",port=80,debug=True)
