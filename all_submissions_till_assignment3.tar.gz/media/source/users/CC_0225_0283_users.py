import os
from flask import Flask, render_template, jsonify, request, abort, Response
from flask_sqlalchemy import SQLAlchemy
from collections import defaultdict
import requests
import json
import datetime
# from enum import Enum, unique

# CC_0225_0283
# 34.200.98.182
LOAD_BALANCER_IP = os.environ['LOAD_BALANCER_IP']
RIDES_EC2_IP = os.environ['RIDES_EC2_IP']
USERS_EC2_IP = os.environ['USERS_EC2_IP']

application = Flask(__name__)
application.config.from_object('configuration.DevelopmentConfig')
application.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(application)

from RideShare_DB import User, HTTP_Req_Count

@application.route('/', methods=["get"])
def fallbackmain():	
    return Response({"Connection - Success"},status=200, mimetype='application/json')

@application.route('/api/v1/users/fallback', methods=["get"])
def fallback():	
    return Response({"Congrats it's a success -> User Instance"},status=200, mimetype='application/json')


@application.route('/api/v1/db/write', methods=["POST"])
def db_write():	
    # Delete or insert
    case_no = request.get_json()['case']
    table_name = request.get_json()['table_name']

    # Insert
    if (case_no == 1):

        if table_name == 'user':
            flag = 1
            user_name = request.get_json()['user_name']
            password = request.get_json()['password']
            record = User(user_name, password)
        
        elif table_name == 'http_req_count':
            flag = 2
            add_or_reset_or_init = request.get_json()['add_or_reset_or_init']
            record = HTTP_Req_Count.query.first()
            if add_or_reset_or_init == 1:
                record.counter = record.counter + 1
            elif add_or_reset_or_init == 2:
                record.counter = 0
            else:
                record = HTTP_Req_Count(0)
                flag = 1
        
        else:        
            # Invalid case
            pass

        if case_no == 1 and flag != 0:
            if flag == 1:

                try:
                    db.session.add(record)
                    db.session.commit()
                    flag = 1

                except:
                    flag = 0

            if flag == 2:

                try:
                    db.session.commit()
                    flag = 1

                except:
                    flag = 0

    else:
        db_delete = request.get_json()['db_delete']

        if table_name == 'user' and db_delete == 0:
            record = User.query.get(str(request.get_json()['user_name']))
            
        elif table_name == 'user' and db_delete == 1:
            record = User.query.all()
        
        try:
            if(type(record)==type(list())):
                for i in record:
                    db.session.delete(i)
                db.session.commit()
            else:
                db.session.delete(record)
                db.session.commit()
            flag = 1

        except:
            flag = 0

    
    if flag == 1:
        return "OK"
    else:
        return "NOTOK"


@application.route('/api/v1/db/read', methods=["POST"])
def db_read():

    table_name = request.get_json()['table_name']

    if table_name == 'user':
        all_or_one = request.get_json()['all_or_one']
        
        if all_or_one == 1:
            uname = request.get_json()['user_name']
            retval = User.query.get(str(uname))

            if retval != None:
                retval = retval.retjson()
        
            else:
                retval = {}

        else:
            retquery = User.query.all()
            retval = defaultdict(list)
            counter = 0
            for i in retquery:
                store = i.retjson()
                retval[counter].append(store)
                counter += 1

    elif table_name == 'http_req_count':
        retquery = HTTP_Req_Count.query.first()
        if retquery == None:
            retval = "None"
        else:
            retval = retquery.retjson()

    return retval


# Clear DB
@application.route('/api/v1/db/clear', methods=["POST"])
def db_clear():

    try:
        json_data = {
            "table_name": "user",
            "db_delete": 1,
            "case" : 2
        }

        dbtemp = requests.post('http://0.0.0.0:9999/api/v1/db/write', json = json_data)

        if dbtemp.text == "OK":
            return Response(status=200, mimetype='application/json')

        else:
            return Response(status=400, mimetype='application/json')

    except:
        return Response(status=400, mimetype='application/json')

# Add user:
@application.route('/api/v1/users', methods=["PUT"])
def add_user():

    dbcount = requests.post('http://0.0.0.0:9999/api/v1/count_incr')

    try:
        username = request.get_json()["username"]	
        password = request.get_json()["password"]
        print("username and password -> ",username,password)

        json_data = {
            "table_name": "user",
            "all_or_one" : 1,
            "user_name" : username
        }

        dbtemp = requests.post('http://0.0.0.0:9999/api/v1/db/read', json=json_data)
        
        # Duplicate Username
        try:
            username == dbtemp.json()['user_name']
            print("USERNAME EXISTING ",username)
            return Response({"Username Already Exists"}, status=400, mimetype='application/json')
        
        except:
            if len(password) > 40 or len(password) < 40:
                return Response(status=400, mimetype='application/json')
            try:
                int(password, 16)
            except ValueError:
                return Response(status=400, mimetype='application/json')


        json_data = {
            "table_name": "user",
            "user_name" : username,
            "password" : password,
            "case": 1
        }

        dbtemp = requests.post('http://0.0.0.0:9999/api/v1/db/write', json = json_data)
        if dbtemp.text == "OK":
            return Response(status=201, mimetype='application/json')

        else:
            return Response(status=400, mimetype='application/json')
            
    except:
        return Response(status=400, mimetype='application/json')

# Remove user:
@application.route('/api/v1/users/<username>', methods=["DELETE"])
def del_user(username):

    dbcount = requests.post('http://0.0.0.0:9999/api/v1/count_incr')

    try:
        json_data = {
            "table_name": "user",
            "user_name": username,
            "db_delete": 0,
            "case" : 2
        }

        dbtemp = requests.post('http://0.0.0.0:9999/api/v1/db/write', json = json_data)

        if dbtemp.text == "OK":
            return Response(status=200, mimetype='application/json')

        else:
            return Response(status=400, mimetype='application/json')

    except:
        return Response(status=400, mimetype='application/json')

# List all users:
@application.route('/api/v1/users', methods=["GET"])
def list_all_users():

    print("Listing users")
    dbcount = requests.post('http://0.0.0.0:9999/api/v1/count_incr')

    try:
        json_data = {
            "table_name": "user",
            "all_or_one": 2
        }

        dbtemp = requests.post('http://0.0.0.0:9999/api/v1/db/read', json=json_data)
        
        retval = list()
        for user in dbtemp.json().values():
            retval.append(user[0]['user_name'])
        
        if len(retval) == 0:
            return Response(status=204, mimetype='application/json')
        
        else:
            return jsonify(retval), 200
            
    except:
        return Response(status=400, mimetype='application/json')


#HTTP requests increment counter
@application.route('/api/v1/count_incr', methods=["POST"])
def count_incr():

    try:
        tempinit = requests.get('http://0.0.0.0:9999/api/v1/_count')
        
        json_data = {
            "table_name": "http_req_count",
            "case" : 1,
            "add_or_reset_or_init" : 1
        }

        dbtemp = requests.post('http://0.0.0.0:9999/api/v1/db/write', json = json_data)

        if dbtemp.text == "OK":
            return Response(status=200, mimetype='application/json')

        else:
            return Response(status=400, mimetype='application/json')

    except:
        return Response(status=400, mimetype='application/json')

# reset HTTP requests counter
@application.route('/api/v1/_count', methods=["DELETE"])
def del_count():

    try:
        tempinit = requests.get('http://0.0.0.0:9999/api/v1/_count')

        json_data = {
            "table_name": "http_req_count",
            "case" : 1,
            "add_or_reset_or_init" : 2
        }

        dbtemp = requests.post('http://0.0.0.0:9999/api/v1/db/write', json = json_data)

        if dbtemp.text == "OK":
            return Response(status=200, mimetype='application/json')

        else:
            return Response(status=400, mimetype='application/json')

    except:
        return Response(status=400, mimetype='application/json')

# display count
@application.route('/api/v1/_count', methods=["GET"])
def list_count():
    try:
        json_data = {
            "table_name": "http_req_count"
        }

        dbtemp = requests.post('http://0.0.0.0:9999/api/v1/db/read', json=json_data)
        
        if(dbtemp.text == "None"):
            json_data = {
                "table_name": "http_req_count",
                "case" : 1,
                "add_or_reset_or_init" : 3
            }
            dbtemp = requests.post('http://0.0.0.0:9999/api/v1/db/write', json=json_data)

            json_data = {
                "table_name": "http_req_count"
            }

            dbtemp = requests.post('http://0.0.0.0:9999/api/v1/db/read', json=json_data)

        retvaltemp = dbtemp.json()['counter']
        retval = list()
        retval.append(retvaltemp)
        return jsonify(retval), 200
                
    except:
        return Response(status=400, mimetype='application/json')


# ------------------------------------------------------------------------------------------------------------------------------------------
# ------------------------------------------------------------------------------------------------------------------------------------------

if __name__ == '__main__':
	application.debug=True
	application.run()
