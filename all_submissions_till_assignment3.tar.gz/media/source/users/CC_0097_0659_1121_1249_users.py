from flask import Flask, request, render_template
from flask_restful import Resource, Api, abort
from flask_sqlalchemy import SQLAlchemy
from requests import put,get,post,delete
from constants import AreaEnum
import datetime
import sqlalchemy
import re

app = Flask(__name__)
api = Api(app)

app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:password@localhost' #connect to database rideshare
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

#def setupenv_2(db):
       # db.engine.execute("create database if not exists httpcount;")
       # db.engine.execute("use httpcount;")
       # db.engine.execute("drop table if exists Count;")
       # user_query_2 = "create table Count(id integer not null,httpRequestCount integer not null, primary key(id));"
       # db.engine.execute(user_query_2)
       # user_query_2 = "insert into Count values('1','0');"
       # db.engine.execute(user_query_2)

def setupenv(db):
	db.engine.execute("create database if not exists rideshare;")
	db.engine.execute("use rideshare;")
	db.engine.execute("drop table if exists User;")
	user_query = "create table if not exists User(id integer not null auto_increment, username text not null, password char(40), userhash varchar(64) as (SHA2(username,256)) stored unique, primary key(id));"
	db.engine.execute(user_query)

#using enum: AreaEnum(locality_id).name

class DatabaseRead(Resource):
    def post(self):
       table = request.json['table name']
       column = request.json['column name']
       if(type(column)==list):
           column = ','.join(column)
       where = request.json['where']
       query = "select "+column+" from "+table+" where "+where+";"
       result = db.engine.execute(query)
       res = []
       for row in result:
           res.append(dict(row))
       if(len(res)==0):
           return {},204
       return {"result":res}

class DatabaseWrite(Resource):
    def post(self):
        querytype = 'insert'
        try:
            values = request.json['insert']
            for i in range(len(values)):
                if(type(values[i])==int):
                    values[i] = "'" + str(values[i]) + "'"
                else:
                    values[i] = "'" + values[i] + "'"
            values = ','.join(values)
            column = request.json['column name']
            column = ','.join(column)
        except:
            querytype='delete'
            condition = request.json['condition']
        table = request.json['table name']
        if(querytype=='insert'):
            query = "insert into "+table+"("+column+") values("+values+");"
        else:
            query = "delete from "+table+" where "+condition+";"
        try:
            result = db.engine.execute(query)
            if(result.rowcount==0):
                abort(400)
        except sqlalchemy.exc.IntegrityError:
            abort(400)
        return {}

class DatabaseClear(Resource):
    def post(self):
      # db.engine.execute("update Count set httpRequestCount=httpRequestCount+1 where id=1;")
       update()
       db.engine.execute("drop database rideshare;")
       setupenv(db) #create database and tables
       post('http://172.17.0.1:8000/api/v1/db/clear')
       return {},200

class User(Resource):
    def put(self):
       # db.engine.execute("update Count set httpRequestCount=httpRequestCount+1 where id=1;")
        update()
        pat = "([0-9a-fA-F]){40}"
        try:
            username = request.json['username']
            if(username==''):
                abort(400)
            password = request.json['password']
        except TypeError:
            abort(500)
        if(len(password)!=40 or re.search(pat,password)==None): #check if valid password
           abort(400, message="Enter a password 40 characters long containing only hexadecimal characters")
        jsonwrite = {'insert':[username,password],'column name':['username','password'],'table name':'User'}
        x = post('http://localhost:5000/api/v1/db/write',json=jsonwrite)
        if(not(x.ok)): #error
            abort(x.status_code)
        return {},201

    def delete(self,username):
       # db.engine.execute("update Count set httpRequestCount=httpRequestCount+1 where id=1;")
        update()
        jsonwrite = {'table name':'User','condition':"username='"+username+"'"}
        x = post('http://localhost:5000/api/v1/db/write',json=jsonwrite)
        if(not(x.ok)):
           abort(x.status_code)
        return {}

    def post(self):
      # update()
       abort(405)

    def get(self):
       # db.engine.execute("update Count set httpRequestCount=httpRequestCount+1 where id=1;")
        update()
        jsonread = {'table name':'User','column name':'username','where':'1=1'}
        result = post('http://localhost/api/v1/db/read',json=jsonread)
        if(result.status_code == 204):
           return {},204
        resultjson = result.json()
        users = []
        for i in resultjson['result']:
            users.append(i['username'])
        return users,200

class CountRequest(Resource):
     def get(self):
        # result =  db.egine.execute("select httpRequestCount from Count where id=1;")
         f = open("keepcount.txt","r")
         result = int(f.read())
         f.close()
         return [result],200

     def delete(self):
        # db.engine.execute("update Count set httpRequestCount=0 where id=1;")
         initial()
         return {},200

     def post(self):
         abort(405)

     def put(self):
         abort(405)

class HealthCheck(Resource):
   def get(self):
       return render_template('index.html')

def initial():
     f = open("keepcount.txt","w")
     f.write("0")
     f.close()

def update():
    f = open("keepcount.txt","r+")
    value = int(f.read())
    f.seek(0)
    f.write(str(value+1))
    f.close()

api.add_resource(DatabaseRead, '/api/v1/db/read')
api.add_resource(DatabaseWrite, '/api/v1/db/write')
api.add_resource(DatabaseClear, '/api/v1/db/clear')
api.add_resource(User,'/api/v1/users','/api/v1/users/<string:username>')
api.add_resource(CountRequest, '/api/v1/_count')
api.add_resource(HealthCheck,'/serve')

if __name__ == "__main__":
    setupenv(db)
    initial()
    app.run(host='0.0.0.0',debug=True)
