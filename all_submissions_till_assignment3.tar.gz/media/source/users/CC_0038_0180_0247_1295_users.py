import re
import os
import ast
import json
import csv
import collections
from flask_api import status
from datetime import datetime
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.exc import IntegrityError, OperationalError, SQLAlchemyError
from flask import Flask, jsonify, request, abort,redirect, url_for, session, Response, _request_ctx_stack
import requests

app = Flask(__name__)
app.config['SECRET_KEY'] = "Ride Share api"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'

location = collections.defaultdict(str)
with open('AreaNameEnum.csv', 'r') as fin:
    dictr = csv.DictReader(fin)
    for line in dictr:
        location[int(line['Area No'])] = line['Area Name']

session_options = {'autocommit':False, 'autoflush':False}
db = SQLAlchemy(app)

# DNS Application Loadbalancer
dns_ALB = 'path-based-alb-973289095.us-east-1.elb.amazonaws.com'

SHA1 = re.compile(r'\b[a-fA-F0-9]{40}\b')
ddformat = re.compile(r'\d{2}-\d{2}-\d{4}:\d{2}-\d{2}-\d{2}')
headers = {'Content-Type': 'application/json', 'Accept':'application/json'}
writeURL = 'http://users:5000/api/v1/db/write'
readURL = 'http://users:5000/api/v1/db/read'
METHODS = ['GET', 'PUT', 'POST', 'DELETE', 'PATCH', 'COPY', 'HEAD', 'OPTIONS', 'LINK'
                , 'UNLINK', 'PURGE', 'LOCK', 'UNLOCK', 'PROPFIND', 'VIEW']

class Users(db.Model):
    __tablename__ = 'users'
    username = db.Column('username', db.String(100), primary_key=True)
    password = db.Column('password', db.String(40), nullable=False)
    def __init__(self, username, password):
        self.username = username
        self.password = password

class Count(db.Model):
    __tablename__ = 'count'
    base_count = db.Column('count_id', db.Integer, primary_key=True)
    users_count = db.Column('users_count', db.Integer, nullable=False)
    def __init__(self, users_count):
        self.users_count = users_count

db.create_all()

quer_count = db.session.query(Count).filter_by(base_count=1)
if(quer_count.scalar() is None):
    baseC = Count(0)
    db.session.add(baseC)
    db.session.commit()

# 0. HealthCheck ALB
@app.route('/api/v1/healthcheck', methods = ['GET'])
def healthcheck():
    return Response(status=status.HTTP_200_OK)

# 1.ADD USER (Done)
@app.route('/api/v1/users' , methods = ['PUT'])
def AddUser():
    if(request.method=='PUT'):
        quer_res = db.session.query(Count).filter_by(base_count = 1).all()
        userC = quer_res[0].users_count
        db.session.query(Count).filter_by(base_count = 1).update(dict(users_count=userC+1))
        db.session.commit()

        req = request.get_json()
        try:
            if(not(re.match(SHA1, req['password']))):
                raise ValueError
        except ValueError:
            return Response(status=400)
        adduser = {"table" : "Users", "insert" : req }
        response = (requests.post(writeURL, data = json.dumps(adduser), headers = headers))
        response = response.json()
        return Response(status=response['status_code'])
    return Response(status=405)

# 2.REMOVE USER (Done)
@app.route('/api/v1/users/<uname>', methods = ['DELETE'])
def RemoveUser(uname):
    if request.method=='DELETE':
        quer_res = db.session.query(Count).filter_by(base_count = 1).all()
        userC = quer_res[0].users_count
        db.session.query(Count).filter_by(base_count = 1).update(dict(users_count=userC+1))
        db.session.commit()

        checkuser = {'table':'Users', 'method':'existence', 'where': uname}
        Exists = (requests.post(readURL, data = json.dumps(checkuser), headers = headers)).json()
        if(Exists['Exists']):
            removeuser = {"table" : "Users" , "delete" : uname}
            response = (requests.post(writeURL, data = json.dumps(removeuser), headers = headers)).json()
            return Response(status=response['status_code'])
        else:
            return Response(status=status.HTTP_400_BAD_REQUEST)
    return Response(status=status.HTTP_405_METHOD_NOT_ALLOWED)

# 3.List All Users
@app.route('/api/v1/users',methods=['GET'])
def listusers():
    if(request.method=='GET'):
        quer_res = db.session.query(Count).filter_by(base_count = 1).all()
        userC = quer_res[0].users_count
        db.session.query(Count).filter_by(base_count = 1).update(dict(users_count=userC+1))
        db.session.commit()

        getusers={'table':'Users', 'method': 'list_users'}
        response = (requests.post(readURL, data = json.dumps(getusers), headers = headers)).json()
        if(len(response['Result'])>0):
            return jsonify(response['Result'])
        else:
            return Response(status=status.HTTP_204_NO_CONTENT)
    return Response(status=status.HTTP_405_METHOD_NOT_ALLOWED)

@app.after_request
def after_request_callback(response):
    path = _request_ctx_stack.top.request.url
    if(response.status == '405 METHOD NOT ALLOWED' and '/api/v1/_count' not in path and '/db/clear' not in path):
        quer_res = db.session.query(Count).filter_by(base_count = 1).all()
        userC = quer_res[0].users_count
        db.session.query(Count).filter_by(base_count = 1).update(dict(users_count=userC+1))
        db.session.commit()
    return response

#count_api
@app.route('/api/v1/_count', methods = ['GET'])
def Count_Call():
    if(request.method=='GET'):
        quer_res = db.session.query(Count).filter_by(base_count = 1).all()
        res = []
        res.append(quer_res[0].users_count)
        return jsonify(res)
    return Response(status=status.HTTP_405_METHOD_NOT_ALLOWED)

#Reset
@app.route('/api/v1/_count', methods = ['DELETE'])
def Reset_Count():
    if(request.method=='DELETE'):
        db.session.query(Count).filter_by(base_count = 1).update(dict(users_count=0))
        db.session.commit()
        return Response(status=status.HTTP_200_OK)
    return Response(status=status.HTTP_405_METHOD_NOT_ALLOWED)

# 4.Clear Database[MAKE TWO COPIES, ONE IN EACH CONTAINER]
@app.route('/api/v1/db/clear',methods=['POST'])
def DBClear():
    if(request.method=='POST'):
        getusers={'table':'Users', 'method': 'list_users'}
        response = (requests.post(readURL, data = json.dumps(getusers), headers = headers)).json()
        db.session.query(Users).delete()
        db.session.commit()
        return Response(status=status.HTTP_200_OK)
    return Response(status=status.HTTP_405_METHOD_NOT_ALLOWED)

#5. DB Write
@app.route('/api/v1/db/write', methods = ['POST'])
def DBWrite():
    if(request.method == 'POST'):
        Request = (request.get_data()).decode()
        Request = ast.literal_eval(Request)
        if('insert' in Request):
            try:
                if(Request['table'] == 'Users'):
                    obj = Users(Request['insert']['username'], Request['insert']['password'])
                db.session.add(obj)
                db.session.commit()
            except IntegrityError:
                db.session.rollback()
                return {'status_code': 400}
            return {'status_code': 201}
        elif('delete' in Request):
            if(Request['table'] == 'Users'):
                db.session.query(Users).filter_by(username = Request['delete']).delete()
                deleterides = {"table" : "Rides" , 'method': 'delete_for_user', "per_delete" : Request['delete']}
                #ip = requests.get('https://checkip.amazonaws.com').text[:-1]
                #response = (requests.post('http://'+ip+':8000/api/v1/db/write', data = json.dumps(deleterides), headers = headers)).json()
                response = (requests.post('http://'+dns_ALB+'/api/v1/db/write', data = json.dumps(deleterides), headers = {'Content-Type': 'application/json', 'Accept':'application/json', 'origin':'3.219.74.43'})).json()
            db.session.commit()
            return {'status_code': 200}
    return {'status_code': 405}

#6. DB Read
@app.route('/api/v1/db/read', methods = ['POST'])
def DBRead():
    if(request.method=='POST'):
        Request = (request.get_data()).decode()
        Request = ast.literal_eval(Request)
        if(Request['table']=='Users'):
            if(Request['method']=='existence'):
                quer_res = db.session.query(Users).filter_by(username = Request['where'])
                if(quer_res.scalar() is None):
                    response = {"Exists": 0}
                else:
                    response = {"Exists": 1}
        #added
        if(Request['method']=='list_users'):
                quer_res = db.session.query(Users).all()
                response_all = []
                for row in quer_res:
                    response_all.append(row.username)
                response = {"Result" : response_all}
        return response
    return {'status_code': 405}

if(__name__ == '__main__'):
    app.run(debug=True, host='0.0.0.0')