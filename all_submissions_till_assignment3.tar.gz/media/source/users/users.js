const express = require('express');
const router = express.Router();
const request = require('request-promise');
const Joi = require('@hapi/joi');
const validator = require('express-joi-validation').createValidator({
    passError: true
});
const { checkUserExists } = require('../utils/check');


router.use(async ( req, res, next ) => {
    console.log(`base Url: ${req.baseUrl} `);
    if(req.baseUrl === '/api/v1/users') {
        console.log('Updating Count');
        let count =  {count:1};
        const options = {
            method: 'POST',
            uri: 'http://localhost:8000/api/v1/db/write',
            json: true,
            body: {
                flag: 2,
                fields: count
            },
            headers: {
                'Content-type': 'application/json'
            }
        };

        const result = await request(options);
        console.log('Updated Count');
    }
    next();
});

// ROUTE: /api/v1/users

/*     API 1: Add user
 *
 *      Request: ​{
 *          “username”: “userName”,
 *
 *          “password”: “3d725109c7e7c0bfb9d709836735b56d943d263f”
 *      }
 *
 *      Response: {}
 *
 */
const createUserSchema = Joi.object().keys({
    username: Joi.string().required(),
    password: Joi.string()
        .hex()
        .min(40)
        .max(40)
        .required()
});

router.put('/', validator.body(createUserSchema), async (req, res) => {
    const { username, password } = req.body;

    try {
        if (await checkUserExists('username', { username })) {
            return res.status(400).send();
        } else {
            const options = {
                method: 'POST',
                uri: 'http://localhost:8000/api/v1/db/write',
                json: true,
                body: {
                    flag: 1,
                    fields: {
                        username,
                        password
                    }
                },
                headers: {
                    'Content-type': 'application/json'
                }
            };

            const result = await request(options);
            return res.status(201).send();
        }
    } catch (error) {
        console.error(error.message);
        return res.status(500).send();
    }
});

/*     API 2: Remove user
 *
 *      Request: ​{}
 *
 *      Response: ​{}
 *
 */

router.delete('/:username', async (req, res) => {
    const username = req.params.username;

    try {
        if (await checkUserExists('username', { username })) {
            const options = {
                method: 'POST',
                uri: 'http://localhost:8000/api/v1/db/write',
                json: true,
                body: {
                    flag: 0,
                    fields: {
                        username
                    }
                },
                headers: {
                    'Content-type': 'application/json'
                }
            };

            await request(options);

            return res.status(200).send();
        } else {
            return res.status(400).send();
        }
    } catch (error) {
        console.error(error.message);
        return res.status(500).send();
    }
});


/*     List all users
 *
 *      Request: ​{}
 *
 *      Response: ​{}
 *
 */
router.get('/', async (req, res) => {
    try {
        const options = {
            method: 'POST',
            uri: 'http://localhost:8000/api/v1/db/read',
            json: true,
            body: {
                fields: 'username'
            },
            headers: {
                'Content-type': 'application/json'
            }
        };

        const result = await request(options);

        if(result.length) {
            const user_list = result.map(user => user.username);

            return res.status(200).send(user_list);
        } else {
            return res.status(204).send();
        }
    } catch(error) {
        console.error(error.message);
        return res.status(500).send();
    }
})

// Error 405 for API 1 and API 2
router.all('/', (req, res) => {
    return res.status(405).send();
});

module.exports = router;
