import flask
import pymongo
import requests
import ast
import re
import random
import json
from json import dumps
import csv
from enum import Enum
import datetime

app = flask.Flask(__name__)
location = list()
request_count=0
#ride_id=0
#loading the locations into an array called location
with open('AreaNameEnum.csv') as csvfile:
        reader = csv.reader(csvfile, delimiter=",")
        next(reader)
        for row in reader:
                location.append(int(row[0]))
#coonecting to mongodb s
myclient = pymongo.MongoClient('mongodb://users-mongo:27017/')

#creating the database called mydatabase
mydb = myclient['mydatabase']



users_read_url = "http://users:5000/api/v1/db/read"
users_write_url = "http://users:5000/api/v1/db/write"
rides_read_url = "http://52.3.9.127:8000/api/v1/db/read"
rides_write_url = "http://52.3.9.127:8000/api/v1/db/write"



# we have made 3 collections....
#1. customers: it stores the username and password
#2.rides: it stores the entire ride detail
#3.users_rides:stores the ride id and the new users that are joining an existing ride


@app.route("/api/v1/health",methods=["GET"])
def health():
         return flask.Response("",status=200)

#1 add user
@app.route("/api/v1/users", methods=["PUT"])
def add_user():
        mycol = mydb["customers"]
        username = flask.request.get_json()["username"]
        password = flask.request.get_json()["password"]
        if(mycol.find({"username":username}).count()> 0):
                code = 400
        else:
                # read_url = "http://52.3.9.127/api/v1/db/read"
                # write_url = "http://52.3.9.127/api/v1/db/write"
                d = {}
                d["table"] = "customers"
                d["column"] = ["username"]
                d["data"] = [username]
                l = requests.post(url =users_read_url, json = d)
                l = ast.literal_eval(l.text)
                if(len(l)==2):
                        if(re.search(("^[a-fA-F0-9]{40}$"), password)):
                                mydict = dict()
                                mydict["table"] = "customers"
                                mydict["column"] = ["username", "password"]
                                mydict["data"] = [username, password]
                                l1 = requests.post(url =users_write_url, json = mydict)
                                code = 201
                        else:
                                code = 400
        return flask.Response("{}", status=code)


#2 delete user
@app.route("/api/v1/users/<name>", methods=["DELETE"])
def remove_user(name):
        #print("hello")
        mycol=mydb["customers"]
        if(mycol.find({"username":name}).count() == 0):
                code = 400
        else:
                mycol.delete_one( {"username":name})
                code = 200
        return flask.Response("{}", status=code)


#8 read database
@app.route("/api/v1/db/read", methods=["POST"])
def read_db():
        table = flask.request.get_json()["table"]
        columns = flask.request.get_json()["column"]
        where = flask.request.get_json()["data"]
        mycol = mydb[table]
        mydict = dict()
        for i in range(len(where)):
                mydict[columns[i]] = where[i]
        x = mycol.find(mydict, {'_id':False})
        l = list()
        for i in x:
                print(i)
                l.append(i)
        return flask.jsonify(str(l))

#9 write database
@app.route("/api/v1/db/write", methods=["POST"])
def write_db():
        table = flask.request.get_json()["table"]
        column = flask.request.get_json()["column"]
        data = flask.request.get_json()["data"]
        mycol = mydb[table]
        mydict = dict()
        for i in range(len(data)):
                mydict[column[i]] = data[i]
        x = mycol.insert_one(mydict)
        print("Inserted, id: ", x.inserted_id)
        return flask.jsonify({})

#10 listing all users
@app.route("/api/v1/users",methods=["GET"])
def list_all_users():
        mycol = mydb["customers"]
        x=list(mycol.find())
        k=[]
        for i in x:
                k.append(i["username"])
        if(len(k)!=0):
                code=200
        else: 
                code=204
        return flask.Response(json.dumps(k),status=code,mimetype="application/json")            

'''
#11 clear db
@app.route("api/v1/db/clear",methods=["POST"])
def clear_db():
        mydb.getCollectionNames().forEach(function(collection_name) {mydb[collection_name].remove()})
'''


#11 clear db
@app.route("/api/v1/db/clear",methods=["POST"])
def clear_db():
	myclient.drop_database("mydatabase")
	return flask.Response("{}", status=200, mimetype="application/json")

def increment(response):
     global request_count
     httprequest=flask._request_ctx_stack.top.request.url
     if("/api/v1/users" in httprequest) and response.status_code in (405,400,204,201,200):
            request_count=request_count+1
     return response
app.after_request(increment)

@app.route("/api/v1/_count",methods=["GET"])
def total_requests():
        global request_count
        k=[]
        k.append(request_count)
        return flask.Response(json.dumps(k),status=200,mimetype="application/json")


@app.route("/api/v1/_count",methods=["DELETE"])
def reset_count():
        global request_count
        request_count=0
        return flask.Response("{}",status=200)

if __name__ == "__main__":
        app.debug=True
        app.run(debug=True,host='0.0.0.0')
