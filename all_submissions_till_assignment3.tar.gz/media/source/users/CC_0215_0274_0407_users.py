from flask import Flask, render_template, jsonify, request, Response, abort
import mysql.connector
import requests
import csv
import datetime
import os
app = Flask(__name__)

url_user = 'http://users:5000/'
url_ride = 'http://userride-1939585045.us-east-1.elb.amazonaws.com/'


def createMeta():
    mydb = connect_to_db()
    mycursor = mydb.cursor(buffered=True)
    return mydb, mycursor


def passwordvalidate(passwd):

    if len(passwd) != 40:
        return 1

    checklist = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', ' F', 'a', 'b', 'c', 'd', 'e', 'f']

    for c in passwd:
        # print(c)
        if c not in checklist:
            return 1
    return 0


def ispresent(src):

    d = {}
    with open('AreaNameEnum.csv') as file:
        data = csv.reader(file)
        count = 0
        for row in data:
            if count == 0:
                count = count + 1
            else:
                count = count + 1
                d[row[0]] = row[1]
                # print(row)
    for keys in d.keys():
        if keys == src:
            return 1
    return 0


def istime_upcoming(timestamp):
    if datetime.datetime.strptime(timestamp, '%d-%m-%Y:%S-%M-%H') > datetime.datetime.now():
        return 1
    else:
        return 0


def valid_syntax(timestamp):
    try:
        datetime.datetime.strptime(timestamp, '%d-%m-%Y:%S-%M-%H')
        return 1
    except ValueError:
        return 0


def valid_timestamp(timestamp):

    if valid_syntax(timestamp):
        dt = timestamp.split(":")
        # print(dt)
        d = dt[0].split("-")
        t = dt[1].split("-")
        # print(d[0])
        # print(t)
        # print(len(d[0]))
        if (len(d[0]) == 2) and (len(d[1]) == 2) and (len(d[2]) == 4):
            if (len(t[0]) == 2) and (len(t[1]) == 2) and (len(t[2]) == 2):
                try:
                    datetime.datetime.strptime(timestamp, '%d-%m-%Y:%S-%M-%H')
                    return 1
                except ValueError:
                    return 0
            else:
                return 0
        else:
            return 0
    else:
        return 0

def inc_count():
    global no_of_req
    no_of_req = no_of_req + 1


@app.before_request
def incrementcounter():
    if request.path not in ('/', '/api/v1/_count', '/api/v1/db/write', '/api/v1/db/read', '/api/v1/db/clear'):
        inc_count()


@app.route('/api/v1/_count', methods=['GET'])
def count_req():
    print("entered count requests")
    li = list()
    total = no_of_req
    li.append(total)
    return jsonify(li), 200


@app.route('/api/v1/_count', methods=['DELETE'])
def reset_req():
    global no_of_req
    no_of_req = 0
    return jsonify({})


@app.route('/api/v1/users', methods=['PUT'])
def add_user():
    print("entered the add user api")
    # flag = 0

    data = request.get_json(force=True)
    name = data["username"]
    password = data["password"]

    # print(name, password)

    r = url_user + 'api/v1/db/read'
    w = url_user + 'api/v1/db/write'

    # print(r,w)

    readj = {
        'table': 'user',
        'opn': 'select',
        'where': 'Name=' + "'" + name + "'",
        'columns': ''
    }
    writej = {
        'table': 'user',
        'opn': 'insert',
        'name': name,
        'password': password,
        'columns': ''
    }

    readres = requests.post(r, json=readj)
    print(readres)
    print(readres.status_code)

    if readres.status_code == 200:
        return Response("Name Already Exists", 400)
        # raise ValueError("Name already exists")

    if passwordvalidate(password):
        return Response("Password is Invalid", 400)
        # raise ValueError("Password is Invalid")

    elif readres.status_code == 204:
        writeres = requests.post(w, json=writej)
        print(writeres)
        return jsonify({}), 201

    else:
        return jsonify({}), 400
        # raise ValueError("Bad Request")

    # if res.status_code == 400:
    #     abort(400)
    #
    # elif res.status_code == 405:
    #     abort(400, description="Invalid Username")
    #
    # elif res.status_code == 201:
    #     abort(201)
    #
    # elif res.status_code == 500:
    #     abort(500)
    #
    # elif passwordvalidate(password):
    #     abort(400)

    # else:


@app.route('/api/v1/users/<username>', methods=['DELETE'])
def delete_user(username):
    print("entered the delete user api")

    readu = url_user + 'api/v1/db/read'
    writeu = url_user + 'api/v1/db/write'

    readr = url_ride + 'api/v1/db/read'
    writer = url_ride + 'api/v1/db/write'

    readj = {
        'table': 'user',
        'opn': 'select',
        'where': 'Name=' + "'" + username + "'",
    }
    read1j = {
        'table': 'joinride',
        'opn': 'select',
        'where': 'Name=' + "'" + username + "'",
    }
    read2j = {
        'table': 'ride',
        'opn': 'select',
        'where': 'Name=' + "'" + username + "'",
    }
    writej = {
        'table': 'user',
        'opn': 'delete',
        'where': 'Name=' + "'" + username + "'",
    }
    write1j = {
        'table': 'joinride',
        'opn': 'delete',
        'where': 'Name=' + "'" + username + "'",

    }
    # write2j = {
    #     'table': 'ride',
    #     'opn': 'delete',
    #     'where': 'Name=' + "'" + username + "'",
    # }

    readres = requests.post(readu, json=readj)
    print(readres)

    if readres.status_code == 200:
        read1res = requests.post(readr, json=read1j)
        read2res = requests.post(readr, json=read2j)
        if read2res.status_code == 200:
            return Response("Ride was created by the user", 400)
            # raise ValueError("User created a ride")
        else:
            # writeres = requests.post(w, json=writej)
            # print(writeres)
            if read1res.status_code == 200:
                write1res = requests.post(writer, json=write1j)
                writeres = requests.post(writeu, json=writej)
                # write2res = requests.post(w, json=write2j)
                print(writeres)
                print(write1res)
                # print(write2res)
                return jsonify({}), 200
            else:
                writeres = requests.post(writeu, json=writej)
                # write2res = requests.post(w, json=write2j)
                print(writeres)
                # print(write2res)
                return jsonify({}), 200
    elif readres.status_code == 204:
        return Response("User does not Exists", 400)
        # raise ValueError("User does not exist")
    else:
        return jsonify({}), 400
        # raise ValueError("Bad Request")


@app.route('/api/v1/users', methods=['GET'])
def list_user():
    print("entered the list user api")

    r = url_user + 'api/v1/db/read'

    readj = {
        'table': 'user',
        'opn': 'select',
        'col': 'Name',
        'where': ''
    }
    readres = requests.post(r, json=readj)
    print(readres)

    if readres.status_code == 200:
        data_readres = readres.json()
        res = []
        for name in data_readres:
            print(name)
            res.append(name[0])
        return jsonify(res)
    else:
        return jsonify({}), 204


@app.route('/api/v1/db/clear', methods=['POST'])
def delete_database():
    print("entered delete database api")

    mydb, mycursor = createMeta()

    # mycursor.execute("DROP TABLE joinride")
    mycursor.execute("DROP TABLE user")
    # mycursor.execute("DROP TABLE ride")


    mydb.commit()
    create_tables()
    return jsonify({}), 200

    # w = request.url_root + 'api/v1/db/write'
    # writej = {
    #     'table': '',
    #     'opn': 'drop',
    # }
    # writeres = requests.post(w, json=writej)
    # if writeres.status_code == 200:
    #     return jsonify({}), 200
    # else:
    #     return Response("Database does not exist", 400)


def connect_to_db():
    mydb_connect = mysql.connector.connect(
        host=os.environ['DB_HOST_URL'],
        # port= 5555,
        user=os.environ['DB_USER'],
        password=os.environ['DB_PASS'],
        database=os.environ['DB_NAME']
    )
    return mydb_connect


def create_database():
    mydb, mycursor = createMeta()
    mycursor.execute("CREATE DATABASE " + os.environ['DB_NAME'])


def create_tables():
    mydb, mycursor = createMeta()
    mycursor.execute("CREATE TABLE IF NOT EXISTS user (Name VARCHAR(255) PRIMARY KEY, Password VARCHAR(255))")
    # mycursor.execute("CREATE TABLE IF NOT EXISTS ride (Ride_ID INT PRIMARY KEY AUTO_INCREMENT, "
    #                  "Name  VARCHAR(255), "
    #                  "DestA VARCHAR(255), "
    #                  "DestB VARCHAR(255), "
    #                  "Timestamp VARCHAR(255))")
    # mycursor.execute("CREATE TABLE IF NOT EXISTS joinride (ID INT PRIMARY KEY AUTO_INCREMENT, "
    #                  "Name VARCHAR(255), Ride_ID INT, "
    #                  "FOREIGN KEY (Name) REFERENCES user(Name), FOREIGN KEY (Ride_ID) REFERENCES ride(Ride_ID))")
    # mycursor.execute("CREATE TABLE IF NOT EXISTS joinride (ID INT PRIMARY KEY AUTO_INCREMENT, "
    #                  "Name VARCHAR(255), Ride_ID INT, "
    #                  "FOREIGN KEY (Ride_ID) REFERENCES ride(Ride_ID))")


@app.route('/api/v1/db/read', methods=['POST'])
def read_db():
    mydb, mycursor = createMeta()

    print("entered read api")

    req = request.get_json()

    # json = { 'table': 'user',
    #          'operation': 'select',
    #          'method': 'POST',
    #          'columns':,
    #          'where':
    # }

    table = req['table']
    opn = req['opn']
    where = req['where']

    # to select from table in database

    # print(table, opn)
    # if opn == "select":
    #     sql = "SELECT * FROM " + table + ";"
    #     # val = (table,)
    #     mycursor.execute(sql)
    #     # myresult = mycursor.fetchall()
    #     # print(myresult)
    #     # for x in myresult:
    #     #     print(x)
    #     return jsonify({})

    # to select from table where in database

    if table == 'user':
        if opn == 'select':
            if where:
                sql = "SELECT * FROM " + table + " WHERE " + where + ";"
                mycursor.execute(sql)
                myresult = mycursor.fetchall()
                # print(myresult)
                # for x in myresult:
                #     print(x)
                if len(myresult) != 0:
                    return jsonify({}), 200
                else:
                    return jsonify({}), 204
            else:
                col = req['col']
                sql = "SELECT " + col + " FROM " + table + ";"
                mycursor.execute(sql)
                myresult = mycursor.fetchall()
                if len(myresult) != 0:
                    return jsonify(myresult), 200
                else:
                    return jsonify({}), 204
    else:
        if opn == 'select' and where:
            sql = "SELECT * FROM " + table + " WHERE " + where + ";"
            mycursor.execute(sql)
            myresult = mycursor.fetchall()
            # print(myresult)
            if len(myresult) != 0:
                return jsonify(myresult), 200
            else:
                return jsonify({}), 204
        else:
            sql = "SELECT * FROM " + table;
            mycursor.execute(sql)
            myresult = mycursor.fetchall()
            return jsonify(len(myresult)), 200
    return 1


@app.route('/api/v1/db/write', methods=['POST'])
def write_db():
    mydb, mycursor = createMeta()
    print("entered write api")

    req = request.get_json()
    table = req['table']
    opn = req['opn']
    # print(table, opn, name)

    if table == '':
        sql = "DROP DATABASE " + os.environ['DB_NAME']
        mycursor.execute(sql)
        mydb.commit()
        return jsonify({})

    elif table == 'user':
        if opn == 'insert':
            name = req['name']
            password = req['password']
            sql = """INSERT INTO user (Name, Password) VALUES (%s, %s);"""
            val = (name, password)
            mycursor.execute(sql, val)
            mydb.commit()
            # print("1 record inserted, ID:", mycursor.lastrowid)
            return jsonify({})
        elif opn == 'delete':
            where = req['where']
            sql = "DELETE FROM " + table + " WHERE " + where + ";"
            mycursor.execute(sql)
            mydb.commit()
            if mycursor.rowcount != 0:
                return jsonify({}), 200
            else:
                return jsonify({}), 400
            # print(mycursor.rowcount, "record(s) deleted")

    elif table == 'ride':
        if opn == 'insert':
            name = req['name']
            src = req['src']
            dst = req['dst']
            timestamp = req['timestamp']
            sql = """INSERT INTO ride (Name, DestA, DestB, Timestamp) VALUES (%s, %s, %s, %s)"""
            val = (name, src, dst, timestamp)
            mycursor.execute(sql, val)
            mydb.commit()
            return jsonify({}), 200
        else:
            where = req['where']
            sql = "DELETE FROM " + table + " WHERE " + where + ";"
            mycursor.execute(sql)
            mydb.commit()
            if mycursor.rowcount != 0:
                return jsonify({}), 200
            else:
                return jsonify({}), 400

    else:
        if opn == 'insert':
            name = req['name']
            rideId = req['rideId']
            sql = """INSERT INTO joinride (Name, Ride_ID) VALUES (%s, %s)"""
            val = (name, rideId)
            mycursor.execute(sql, val)
            mydb.commit()
            return jsonify({}), 200
        else:
            where = req['where']
            sql = "DELETE FROM " + table + " WHERE " + where + ";"
            mycursor.execute(sql)
            mydb.commit()
            if mycursor.rowcount != 0:
                return jsonify({}), 200
            else:
                return jsonify({}), 400

    return 1


if __name__ == '__main__':

    #global mydb
    #global mycursor
    global no_of_req
    no_of_req = 0
    #mydb = connect_to_db()
    #mycursor = mydb.cursor(buffered=True)

    # create_database()
    create_tables()
    # mycursor.execute("SHOW TABLES")

    app.run(host="0.0.0.0",debug=True)
