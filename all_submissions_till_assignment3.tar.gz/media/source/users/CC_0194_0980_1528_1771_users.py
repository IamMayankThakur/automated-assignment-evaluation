from flask import Flask, render_template,jsonify,request,abort,Response,json,_request_ctx_stack
import requests
import sqlite3

import re
from datetime import datetime
import csv

app=Flask(__name__)
@app.route("/api/v1/users",methods=["POST","PATCH","DELETE","COPY","HEAD","OPTIONS","LINK","UNLINK","PURGE","LOCK","UNLOCK","PROPFIND","VIEW"])
def methodNotAllowed():
    requests.post("http://ec2-52-0-242-191.compute-1.amazonaws.com:80/api/v1/db/write",json={"OP":6})
    return jsonify({}),405
@app.route("/api/v1/users",methods=["PUT"])
def addUser():
    requests.post("http://ec2-52-0-242-191.compute-1.amazonaws.com:80/api/v1/db/write",json={"OP":6})
    if(request.method == 'PUT'):
        
        try:
            username = request.get_json()["username"]
            password = request.get_json()["password"]
        except KeyError:
            return jsonify({}),400
        checkpwd = re.findall('^[0-9a-fA-Z]{40}$',password)
        if(len(checkpwd) == 0):
            return jsonify({}),400

        readresponse = requests.post("http://ec2-52-0-242-191.compute-1.amazonaws.com:80/api/v1/db/read",json={"OP":1,"table":"Users","where":"username","value":username})
        code = readresponse.status_code
        
        if(code == 500):
            return jsonify({}),500
        elif(code == 201):
            return jsonify({}),400
        elif(code == 204):
            detlist = [username,password]
            writeresponse = requests.post("http://ec2-52-0-242-191.compute-1.amazonaws.com:80/api/v1/db/write",json={"OP":1,"table":"Users","value":detlist})
            if(writeresponse.status_code == 201):
                return jsonify({}),201
            elif(writeresponse.status_code == 500):
                return jsonify({}),500
    else:
        return Response(status=405)


@app.route("/api/v1/users/<username>",
methods=["POST","PATCH","PUT","GET","COPY","HEAD","OPTIONS","LINK","UNLINK","PURGE","LOCK","UNLOCK","PROPFIND","VIEW"])
def methodNotAllowed1():
    requests.post("http://ec2-52-0-242-191.compute-1.amazonaws.com:80/api/v1/db/write",json={"OP":6})
    return jsonify({}),405

@app.route("/api/v1/users/<username>",methods=["DELETE"])
def removeUser(username):
    requests.post("http://ec2-52-0-242-191.compute-1.amazonaws.com:80/api/v1/db/write",json={"OP":6})
    if(request.method == 'DELETE'):
        readresponse = requests.post("http://ec2-52-0-242-191.compute-1.amazonaws.com:80/api/v1/db/read",json={"OP":1,"table":"Users","where":"username","value":username})
        code = readresponse.status_code
        if(code == 500):
            return jsonify({}),500
        elif(code == 204):
            return jsonify({}),400
        elif(code == 201):
            writeresponse = requests.post("http://ec2-52-0-242-191.compute-1.amazonaws.com:80/api/v1/db/write",json={"OP":2,"table":"Users","where":"username","value":username})
            if(writeresponse.status_code == 500):
                return jsonify({}),500
            elif(writeresponse.status_code == 200):
                return jsonify({}),200
    else:
        return Response(status=405)

@app.route("/api/v1/users",methods=["GET"])
def listUsers():
    
    requests.post("http://ec2-52-0-242-191.compute-1.amazonaws.com:80/api/v1/db/write",json={"OP":6})
    if(request.method == 'GET'):
        readresponse = requests.post("http://ec2-52-0-242-191.compute-1.amazonaws.com:80/api/v1/db/read",json={"OP":5})
        code = readresponse.status_code
        
        if(code == 500):
            return jsonify({}),500
        elif(code == 204):
            return jsonify({}),400
        elif(code == 200):
            if(len(readresponse.json()) == 0):
                return jsonify({}),204
            return jsonify(readresponse.json()),200
    else:
        return jsonify({}),405

@app.route("/api/v1/_count",methods=["POST","PATCH","PUT","COPY","HEAD","OPTIONS","LINK","UNLINK","PURGE","LOCK","UNLOCK","PROPFIND","VIEW"])
def methodNotAllowed2():
    requests.post("http://ec2-52-0-242-191.compute-1.amazonaws.com:80/api/v1/db/write",json={"OP":6})
    return jsonify({}),405


@app.route("/api/v1/_count",methods=["GET"])
def countRequests():
    count = requests.post("http://ec2-52-0-242-191.compute-1.amazonaws.com:80/api/v1/db/read",json={"OP":7})
    return jsonify(count.json())


@app.route("/api/v1/_count",methods=["DELETE"])
def resetCount():
    count = requests.post("http://ec2-52-0-242-191.compute-1.amazonaws.com:80/api/v1/db/write",json={"OP":8})
    if(count.status_code==200):
        return jsonify({}),200

@app.route("/api/v1/db/read",methods=["POST"])
def readDB():
    OP = request.get_json()["OP"]
    try:
        conn = sqlite3.connect("cloud_user.db")
    except:
        return Response(status=500)
    if(OP == 5):
        cur1 = conn.execute("SELECT username FROM Users")
        userrows = cur1.fetchall()
        conn.close()
        userdata = []
        for row in userrows:
            userdata.append(row[0])
        response = app.response_class(response=json.dumps(userdata),status=200,mimetype='application/json')
        conn.close()
        return response

    elif(OP == 7):
        cur = conn.execute("SELECT * FROM Count")
        userrows = cur.fetchall()
        conn.close()
        userdata = []
        for row in userrows:
            userdata.append(int(row[0]))
        response = app.response_class(response=json.dumps(userdata),status=200,mimetype='application/json')
        conn.close()
        return response





    elif(OP == 6):
        try:
            conn.execute("DELETE FROM Users")
            return Response(status=200)
        except:
            return Response(status=500)
    




    elif(OP == 3):
        source = request.get_json()['source']
        destination = request.get_json()['destination']
        cur = conn.execute("SELECT * FROM Area WHERE area_no=? or area_no=?",(source,destination))
        rows = cur.fetchall()
        if(len(rows) != 2):
            return Response(status=400)
        cur1 = conn.execute("SELECT * FROM Ride WHERE src=? and dst=?",(source,destination))
        result = cur1.fetchall()
        userdata = []
        for row in result:
            timesplit = row[2].split(" ")
            yy,mm,dd = timesplit[0].split("-")
            hh,mi,ss = timesplit[1].split(":")
            time = dd+"-"+mm+"-"+yy+":"+ss+"-"+mi+"-"+hh
            now = datetime.now()
            currentdt = now.strftime("%d/%m/%Y %H:%M:%S")
            cdd,cmm,cyy = currentdt.split(' ')[0].split('/')
            ch,cm,cs = currentdt.split(' ')[1].split(':')

            check = (datetime(int(cyy),int(cmm),int(cdd),int(ch),int(cm),int(cs)) < datetime(int(yy),int(mm),int(dd),int(hh),int(mi),int(ss)))
            if(check):
                data = {"rideId":str(row[0]),"username":row[1],"timestamp":time}
                userdata.append(data)
        
        response = app.response_class(response=json.dumps(userdata),status=200,mimetype='application/json')
        conn.close()
        return response

    elif(OP == 4):
        source = request.get_json()['source']
        destination = request.get_json()['destination']
        cur = conn.execute("SELECT * FROM Area WHERE area_no=? or area_no=?",(source,destination))
        rows = cur.fetchall()
        if(len(rows) != 2):
            return Response(status=400)
        else:
            return Response(status=201)

    else:
        table = request.get_json()["table"]
        where = request.get_json()["where"]
        value = request.get_json()['value']
        cur = conn.execute("SELECT * FROM "+table+" WHERE "+where+"=?",(value,))
        rows = cur.fetchall()
        if(len(rows) == 0):
            return Response(status=204)
        else:
            if(OP == 1):
                return Response(status=201)
            elif(OP == 2):
                cur1 = conn.execute("SELECT new_users FROM joinRide WHERE join_id=?",(value,))
                userrows = cur1.fetchall()
                conn.close()
                userdata = []
                for row in userrows:
                    userdata.append(row[0])
                timesplit = rows[0][2].split(" ")
                yy,mm,dd = timesplit[0].split("-")
                hh,mi,ss = timesplit[1].split(":")
                time = dd+"-"+mm+"-"+yy+":"+ss+"-"+mi+"-"+hh
                result = {"rideId":value,"created_by":rows[0][1],"users":userdata,"timestamp":time,"source":str(rows[0][3]),"destination":str(rows[0][4])}
                response = app.response_class(response=json.dumps(result),status=200,mimetype='application/json')
                return response


@app.route("/api/v1/db/write",methods=["POST"])
def writeDB():
    OP = request.get_json()["OP"]
    try:
        conn = sqlite3.connect("cloud_user.db")
    except:
        return Response(status=500)

    if(OP == 1):
        table = request.get_json()['table']
        value = request.get_json()['value']
        try:
            conn.execute("PRAGMA foreign_keys = on")
            conn.execute("INSERT INTO "+table+" VALUES(?,?)", (value[0],value[1]))
            conn.commit()
            conn.close()
            return Response(status=201)
        
        except:
            return Response(status=500) #Not Final

    elif(OP == 2):
        table = request.get_json()["table"]
        where = request.get_json()["where"]
        value = request.get_json()['value']
        try:
            conn.execute("PRAGMA foreign_keys = on")
            conn.execute("DELETE FROM "+table+" WHERE "+where+"=?",(value,))
            conn.commit()
            conn.close()
            requests.post("http://ec2-3-222-123-94.compute-1.amazonaws.com:80/api/v1/rides/delete",json={"created_by":value})
            return Response(status=200)
        except:
            return Response(status=500) #Not Final

    elif(OP == 3):
        username = request.get_json()["username"]
        source = request.get_json()["source"]
        destination = request.get_json()["destination"]
        time = request.get_json()["timestamp"]
        arr = time.split(':')
        dd,mm,yy = arr[0].split('-')
        ss,mi,hh = arr[1].split('-')
        time = yy+"-"+mm+"-"+dd+" "+hh+":"+mi+":"+ss

        try:
            conn.execute("PRAGMA foreign_keys = on")
            conn.execute("INSERT INTO Ride(Time_stamp,src,dst,created_by) VALUES(?,?,?,?)", (time,int(source),int(destination),username))
            conn.commit()
            conn.close()
            return Response(status=201)
        except:
            return Response(status=500)
    elif(OP==6):
        conn.execute("UPDATE Count SET count=count+1")
        conn.commit()
        return Response(status=200)
    elif(OP==8):
        conn.execute("UPDATE Count SET count=0")
        conn.commit()
        return Response(status=200)    
@app.route("/api/v1/db/clear",methods=["POST"])
def clearDB():
    #requests.post("http://ec2-52-0-242-191.compute-1.amazonaws.com:80/api/v1/db/write",json={"OP":6})
    try:
        conn = sqlite3.connect("cloud_user.db")
        conn.execute("DELETE FROM Users")
        

        conn.commit()
        return jsonify({}),200
        conn.close()
    except:
        return Response(status=500)


if __name__ == '__main__': 
    
    conn = sqlite3.connect("cloud_user.db")
    usertable = "CREATE TABLE IF NOT EXISTS Users(username VARCHAR(20) NOT NULL PRIMARY KEY,password VARCHAR(20) NOT NULL);"
    cnttable = "CREATE TABLE IF NOT EXISTS Count(count INT NOT NULL);"
    cntinit = "INSERT INTO Count VALUES(0);"
        
    
    conn.execute(usertable)
    conn.execute(cnttable)
    conn.execute(cntinit)
    conn.commit()
    
    conn.close()
    app.run(host='0.0.0.0',debug=True)




