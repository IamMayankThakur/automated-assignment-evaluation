from flask import Flask, render_template,jsonify,request,abort
import requests
from sqlalchemy import create_engine
import sqlalchemy
import re
import pandas as pd
from werkzeug.routing import Rule

app=Flask(__name__)

def my_rule_wrapper(rule, **kwargs):
    kwargs['methods'] = None
    return Rule(rule, **kwargs)

app.url_rule_class = my_rule_wrapper

# database creation --- database name = assignment1.db, tables = users
engine = create_engine("sqlite:///assignment2_users.db")
try:
    sql_command1 = "create table users (username text primary key, password text);"
    with engine.connect() as con:
        con.execute(sql_command1)
        con.execute("PRAGMA foreign_keys=on;")
except:
    pass
df = pd.read_csv("AreaNameEnum.csv")
l = list(df.itertuples(index=False, name=None))
area_list = {i[0]:i[1] for i in l}
load_balancer_ip = "a3-load-balancer-1688029447.us-east-1.elb.amazonaws.com"
users_ip = "52.55.146.247"
rides_ip = "3.85.58.248"
f = open("users_api_count.txt","w")
print(0,file=f)
f.close()

@app.route("/api/v1/users/test")
def test():
    return "Hello stranger!(User Test)"

# api 1 --- adding a new unique user to the database
# list users api (new)
@app.route("/api/v1/users")
def list_add_user():
    with open("users_api_count.txt","r") as f:
        x = int(f.read())
    with open("users_api_count.txt","w") as f:
        print(x+1,file=f)
    if request.method == 'GET':
        sql_query = {"column_names":"username","table_names":"users","where_condition":"1"}
        response = requests.post(url="http://"+users_ip+"/api/v1/db/read",json=sql_query).json()["row_list"]
        result = []
        if len(response)!=0:
            for i in response:
                result.append(i[0])
            return jsonify(result),200
        else:
            return jsonify(result),204
    elif request.method == 'PUT':
        req = request.get_json()
        if ("username" in req) and ("password" in req):
            username = req["username"]
            password = req["password"]
            if (len(username)==0):
                return "",400
            # send request to api 9 to query database to check if username is present
            column_names="username"; table_names="users"; where_condition="exists (select * from users where username='"+username+"')"
            sql_query = {"column_names":column_names,"table_names":table_names,"where_condition":where_condition}
            response = requests.post(url="http://"+users_ip+"/api/v1/db/read",json=sql_query).json()["row_list"]
            if len(response)==0: # if not present add user and send 201 (resource created)
                if (re.match("[a-fA-F0-9]{40}",password)) and (len(password)==40): # checking if password is 40 char hex hash
                    # adding user by sending request to api 8
                    sql_query={"method":"insert", "table_names":"users", "column_names":"username,password", "values_list": "'"+username+"'"+","+"'"+password+"'"}
                    response = requests.post(url="http://"+users_ip+"/api/v1/db/write",json=sql_query)
                    return "",201
    else: # if request method is not "PUT" or "GET", we send 405 (method not allowed)
        return "",405
    return "",400 # if password not compliant, user already exists, or any of required request parameters not present send 400 (bad request)

# api 2 --- deleting an existing user from the database
@app.route('/api/v1/users/<username>')
def delete_user(username):
    with open("users_api_count.txt","r") as f:
        x = int(f.read())
    with open("users_api_count.txt","w") as f:
        print(x+1,file=f)
    if request.method == 'DELETE':
        # send request to api 9 to query database to check if username is present
        column_names="username"; table_names="users"; where_condition="exists (select * from users where username='"+username+"')"
        sql_query = {"column_names":column_names,"table_names":table_names,"where_condition":where_condition}
        response = requests.post(url="http://"+users_ip+"/api/v1/db/read",json=sql_query).json()["row_list"]
        if len(response)==0: # if not present return 400 (bad request) as delete not possible
            return "",400 
        else: # else send request to api 8 to delete and return 200 (success)
            sql_query = {"method":"delete","table_names":"users","where_condition":"username='"+username+"'"}
            response = requests.post(url="http://"+users_ip+"/api/v1/db/write",json=sql_query)
            sql_query = {"method":"delete","table_names":"rides","where_condition":"created_by='"+username+"'"}
            header = {'Origin':users_ip}
            response = requests.post(url="http://"+rides_ip+"/api/v1/db/write",json=sql_query,headers=header)
            sql_query = {"column_names":"rideid,users","table_names":"rides","where_condition":"1"}
            header = {'Origin':users_ip}
            response = requests.post(url="http://"+rides_ip+"/api/v1/db/read",json=sql_query,headers=header).json()["row_list"]
            if len(response)!=0:
                for i in response:
                    if i[1] is not None:
                        users = i[1].split(",")
                        rideid=str(i[0])
                        if username in users:
                            users.remove(username)
                            if len(users)==1:
                                users = users[0]
                            else:
                                res = ""
                                for x in users:
                                    res = res+x+","
                                users=res[:len(res)-1]
                            sql_query = {"method":"update","table_names":"rides","set_values":"users='"+users+"'","where_condition":"rideid="+rideid}
                            header = {'Origin':users_ip}
                            response = requests.post(url="http://"+rides_ip+"/api/v1/db/write", json=sql_query,headers=header)
            return "",200
    else: # if request method is not "DELETE", we send 405 (method not allowed)
        return "",405

# clear database
@app.route("/api/v1/db/clear")
def cleardb():
    # with open("users_api_count.txt","r") as f:
    #     x = int(f.read())
    # with open("users_api_count.txt","w") as f:
    #     print(x+1,file=f)
    if request.method == 'POST':
        sql_query = {"method":"delete","table_names":"users","where_condition":"1"}
        requests.post(url="http://"+users_ip+"/api/v1/db/write",json=sql_query)
        return "",200
    else:
        return "",405

# count number of api calls
# reset count of number of rides created
@app.route("/api/v1/_count", methods = ["GET","DELETE"])
def api_count():
    if request.method == "GET":
        with open("users_api_count.txt","r") as f:
            x = int(f.read())
        return jsonify([x]),200
    elif request.method == "DELETE":
        with open("users_api_count.txt","w") as f:
            print(0,file=f)
        return "",200
    else:
        return "",405

# ​api 8 --- writing to database
@app.route("/api/v1/db/write",methods=["POST"])
def dbwrite():
    # with open("users_api_count.txt","r") as f:
    #     x = int(f.read())
    # with open("users_api_count.txt","w") as f:
    #     print(x+1,file=f)
    if request.method == 'POST':
        req = request.get_json()
        if "method" in req:
            method = req["method"]
            if method == "insert": # if method is insert and all required parameters present, insert and return 200 (success)
                if ("table_names" in req) and ("column_names" in req) and ("values_list" in req):
                    sql_command = "insert into "+req["table_names"]+" ("+req["column_names"]+") values ("+req["values_list"]+");"
                    with engine.connect() as con:
                        con.execute(sql_command)
                    return "",200
            elif method == "delete": # if method is delete and all required parameters present, delete and return 200 (success)
                if ("table_names" in req) and ("where_condition" in req):
                    sql_command = "delete from "+req["table_names"]+" where "+req["where_condition"]+";"
                    with engine.connect() as con:
                        con.execute("PRAGMA foreign_keys=on;")
                        con.execute(sql_command)
                    return "",200
            elif method == "update": # if method is update and all required parameters present, update and return 200 (success)
                if ("table_names" in req) and ("where_condition" in req) and ("set_values" in req):
                    sql_command = "update "+req["table_names"]+" set "+req["set_values"]+" where "+req["where_condition"]+";"
                    with engine.connect() as con:
                        con.execute(sql_command)
                    return "",200
    else: # if request method is not POST, we send 405 (method not allowed)
        return "",405 
    return "",400 # if any of the required request parameters are missing, we send 400 (bad request)

# api 9 --- reading from database
@app.route("/api/v1/db/read", methods=["POST"])
def dbread():
    # with open("users_api_count.txt","r") as f:
    #     x = int(f.read())
    # with open("users_api_count.txt","w") as f:
    #     print(x+1,file=f)
    if request.method == 'POST':
        req = request.get_json()
        y=[]
        if ("column_names" in req) and ("table_names" in req) and ("where_condition" in req): 
            # execute the required read, and return results as response along with 200 (success)
            sql_command = "select "+req["column_names"]+" from "+req["table_names"]+" where "+req["where_condition"]+";"
            with engine.connect() as con:
                x = con.execute(sql_command)
                for ln in x:
                    y.append(list(ln))
            return jsonify({"row_list":y}),200
    else: # if request method is not POST, we send 405 (method not allowed)
        return jsonify("hello"),405
    return jsonify("hello"),400 # if any of the required request parameters are missing, we send 400 (bad request)

if __name__ == '__main__':
    app.debug = True
    app.run(host='0.0.0.0')
