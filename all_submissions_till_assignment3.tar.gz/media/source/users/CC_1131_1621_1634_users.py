from flask import Flask, render_template,\
jsonify,request,abort
import re
import sqlite3 as sq3
import datetime
import requests
import flask
from datetime import datetime

app=Flask(__name__)
global domain
domain = "ec2-34-203-192-241.compute-1.amazonaws.com"
global load_addr
load_addr = "CC-897869852.us-east-1.elb.amazonaws.com"


f=open("file.txt","w")

f.close()

@app.errorhandler(404)

def g(e):

	

	return "error 404 page not found",404

@app.errorhandler(405)

def g1(e):

	f=open("file.txt","a")

	f.write('a')

	f.close()

	return "Method not allowed",405


@app.route('/api/v1/db/read',methods=["POST"])
def db_read():
	
	
	action=flask.request.values.get('action')
	table=flask.request.values.get('table')

	columns=flask.request.values.get('columns')
	where=flask.request.values.get('where')
	
	
	userdb_connection=sq3.connect('db/user_details.db')
	cursor_user=userdb_connection.cursor()
	
	
	if(action == "select" and where == "NA"):
		try:
			existing_usersdb=cursor_user.execute("SELECT"+ columns+"FROM" +"\'"+table+"\'")
			y=existing_usersdb.fetchall()
			r=""
			if(table=="user_ride"):
				for i in y:
					r=r+"+"+str(i)
			else:
				for i in y:
					r=r+","+str(i[0])

			if(r==""):
				return "NA"
			return r
		except:
			cursor_user.execute("CREATE TABLE users (username varchar,password varchar)")
			userdb_connection.commit()
			existing_usersdb=cursor_user.execute("SELECT"+ columns+"FROM" +"\'"+table+"\'")
			y=existing_usersdb.fetchall()
			r=""
			if(table=="user_ride"):
				for i in y:
					r=r+"+"+str(i)
			else:
				for i in y:
					r=r+","+str(i[0])

			if(r==""):
				return "NA"
			return r

	elif( where !="NA"):
		where=where.split(";")
		
		if(len(where) == 4):
			
			existing_usersdb=cursor_user.execute("SELECT "+ columns+" FROM" +"\'"+table+"\'"+"WHERE "+where[0]+" = " +"\'"+where[1]+"\'"+" and "+where[2]+" = " +"\'"+where[3]+"\'")
			y=existing_usersdb.fetchall()
			
			r=""
			u=""
			for i in y:
				r=r+"+"+str(i)
		else:
			

		
			existing_usersdb=cursor_user.execute("SELECT "+ columns+" FROM " +table+" WHERE "+where[0]+"=(?)",(where[1],))
			y=existing_usersdb.fetchall()
			r=""
			u=""
			for i in y:
				u=i
				if(u == ""):
					return ""
				for i in u:
					r=r+","+str(i)

		
		if(r==""):
			return "NA"
		return r
	

			
		
		

@app.route('/api/v1/db/write',methods=["POST"])
def db_write():

	action=flask.request.values.get("action")
	scolumn=flask.request.values.get("scolumn")
	table=flask.request.values.get("table")
	where=flask.request.values.get("where")
	values=flask.request.values.get("values")
	
	values.strip(",")
	values=values.split(",")
	userdb_connection=sq3.connect('db/user_details.db')
	cursor_user=userdb_connection.cursor()
	try:
		cursor_user.execute("CREATE TABLE users (username varchar,password varchar)")
		userdb_connection.commit()
	except:
		yr=0

	if(action == "delete"):
		
		where=where.split(";")

		
		
		
		existing_usersdb=cursor_user.execute("DELETE FROM  "+table+" WHERE "+where[0] +"=(?)",(where[1],))
		
		userdb_connection.commit()
		return "succesfull",201
	if(action == "update"):
		where=where.split(";")
		
		existing_usersdb=cursor_user.execute("UPDATE "+table+" SET "+scolumn+"="+"\'"+values[0]+"\'"+" WHERE "+where[0] +"=(?)",(where[1],))
		userdb_connection.commit()
		return "uodate success"
	if(action == "insert" and table=="user_ride"):
		
		existing_usersdb=cursor_user.execute("INSERT INTO"+"\'"+table +"\'"+"(username,timestamp,source,destination) "+"VALUES(?,?,?,?)",(values[0],values[1],values[2],values[3]))
		
		userdb_connection.commit()
		return "success"
		
	if(action == "insert" and table=="users"):
		existing_usersdb=cursor_user.execute("INSERT INTO"+"\'"+table+"\'"+"VALUES(?,?)",(values[0],values[1]))
		userdb_connection.commit()
		return "success"

	userdb_connection.close()
	
		
		

@app.route('/api/v1/db/clear',methods=["POST"])	
def clear_db():
	global domain
	global load_addr
	
	try:
		userdb_connection=sq3.connect('db/user_details.db')
		cursor_user=userdb_connection.cursor()
		existing_usersdb=cursor_user.execute("DELETE FROM  users")
			
		userdb_connection.commit()
	except:
		abort(400)
	return " ",200

	


#URL Routing:
@app.route('/api/v1/users',methods=["PUT"])
def add_user():
	global domain
	global load_addr
	f=open("file.txt","a")

	f.write('a')

	f.close()
	username=request.get_json()["username"]
	password=request.get_json()["password"]
	post={"action":"select","table":"users","columns":"*","where":"NA"}
	url= 'http://'+domain+':80/api/v1/db/read'
	headers={"Origin":domain}
	p=requests.post(url,data=post)
	if(p.text!="NA"):
		
		r=p.text
		
		r=r.strip(",")
		
		existing_users=r.split(",")
		for i in existing_users:
			if(i == username):
				
				return "",400
				break
	
	





	
	if(not re.search("^[a-fA-F0-9]{40}$",password)):

		
		abort(400)
	
	
	values=username+","+password
	post={"action":"insert","table":"users","columns":"*","where":"NA","values":values}
	url= 'http://'+domain+':80/api/v1/db/write'
	headers={"Origin":domain}
	p=requests.post(url,data=post)
	t=p.text
	return "",201

	
		
	
@app.route('/api/v1/users/<user>',methods=["DELETE"])
def remove_user(user):
	global domain
	global load_addr
	f=open("file.txt","a")

	f.write('a')

	f.close()
	post={"action":"select","table":"users","columns":"*","where":"NA"}
	url= 'http://'+domain+':80/api/v1/db/read'
	headers={"Origin":domain}
	p=requests.post(url,data=post)
	
	if(p.text == "NA"):
		abort(400)
	r=p.text
	r=r.strip(",")
	
	
	existing_users=r.split(",")
	
	if(user in existing_users):
		t="username;"+user
	
		post={"action":"delete","table":"users","columns":"NA","where":t,"values":"NA"}
		url= 'http://'+domain+':80/api/v1/db/write'
		headers={"Origin":domain}
		p=requests.post(url,data=post)
		
		
		
		
		post={"action":"select","table":"user_ride","columns":"*","where":"NA"}
		url= 'http://'+load_addr+':80/api/v1/db/read'
		headers={"Origin":domain}
		p=requests.post(url,data=post,headers=headers)
		t=p.text
		

		
		if(p.text != "NA" ):
			t=p.text
			
			t=t.strip("+")
			t=t.split("+")
			f=0
			for i in t:
				
				i=i.strip("()")
				i=i.split(",")
				
				if(user in i[5]):
					t="ride;"+i[0]
					f=1
					
					p1=i[5].replace(user,"")
					p1=p1.replace("\'","")
					p1=p1.split(";")
					
					
					p2=""
					for j in p1:
						
						if(j!=" "):
							p2=p2+";"+j
					p2=p2.strip(";")
				
					post={"action":"update","table":"user_ride","scolumn":"ride_mate","where":t,"values":p2}
					url= 'http://'+load_addr+':80/api/v1/db/write'
					headers={"Origin":domain}
					p=requests.post(url,data=post,headers=headers)
					t=p.text
					
				i[1]=i[1].replace("\'","")
				i[1]=i[1].strip(" ")
				
				if(user in i):
					
					t="ride;"+i[0]
					
					post={"action":"delete","table":"user_ride","columns":"NA","where":t,"values":"NA"}
					url= 'http://'+load_addr+':80/api/v1/db/write'
					headers={"Origin":domain}
					p=requests.post(url,data=post,headers=headers)
					t=p.text
					
			return t+"succesfully deleted in user rides if any rides",200
		

			
			return "out",200
		else:
			return "empty",200
	else:
		abort(400)

@app.route('/api/v1/users',methods=["GET"])
def list_all_users():
	global domain
	global load_addr
	f=open("file.txt","a")
	f.write('a')
	f.close()
	post={"action":"select","table":"users","columns":"*","where":"NA"}
	url= 'http://'+domain+':80/api/v1/db/read'
	headers={"Origin":domain}
	p=requests.post(url,data=post)
    

	l=list()
	if(p.text!="NA"):

		r=p.text

		r=r.strip(",")

		existing_users=r.split(",")
		for i in existing_users:
			l.append(i)
	else:
		return "empty",400
	return jsonify(l)
@app.route('/api/v1/_count',methods=["GET"])

def get_count():
	global domain
	global load_addr

       	
	f=open("file.txt","r")


	p=list()
	p.append(len(f.read()))

	return jsonify(p)
	return "hi"
@app.route('/api/v1/_count',methods=["DELETE"])
def del_count():
	global domain
	global load_addr

       	
	f=open("file.txt","w")
	f.close()
	return "done",200

if __name__ == '__main__':	
	app.debug=True
	app.run(host='0.0.0.0',port=80)
        
