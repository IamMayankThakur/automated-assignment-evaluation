# on 8080
# add, del, list(list of usernames), read, write db, clear db
from flask import Flask, render_template, jsonify, request, abort
import flask
import sqlite3
import string
import json
import requests
import ast
import datetime
import os

os.system("rm a2.db")


app = Flask(__name__)

mydb = sqlite3.connect('a2.db')
mycursor = mydb.cursor()
mydb.execute("CREATE TABLE users (uname VARCHAR(255),pswd VARCHAR(40))")
mydb.execute("CREATE TABLE http_count (count INTEGER)")
mydb.commit()
mydb.close()

# f = open("count.txt","w")
# f.write("0")
# f.close()

count1=0

@app.before_request
def count_inc():
    url = request.path
    global count1
#     db=["/api/v1/db/read","/api/v1/db/write","/api/v1/_count","/api/v1/users/check"]
    # u=["/api/v1/users","/api/v1/users/<username>","/api/v1/db/clear"]
#     flag=0
#     for ur in app.url_map.iter_rules():
#         if(url not in db and url==ur):
#             flag=1
#     print(flag)    

    if(url.startswith('/api/v1/users')):
        mydb = sqlite3.connect('a2.db')
        count1 = count1+1
        mydb.execute("INSERT INTO http_count VALUES ("+str(count1)+")")
        mydb.commit()
        mydb.close()
#         f = open("count.txt","r")
#         count = int(f.read())
#         f.close()
#         f = open("count.txt","w")
#         count+= 1
#         count1=0
#         f.write(str(count))
#         f.close()

# @app.after_request
# def count_dec(response):
#     url = request.path
#     db=["/api/v1/db/read","/api/v1/db/write","/api/v1/_count","/api/v1/users/check"]
#     stats = [200,201,405]

#     status = response.status_code
#     if(status not in stats and url not in db):
#         f = open("count.txt","r")
#         count = int(f.read())
#         f.close()
#         f = open("count.txt","w")
#         count-= 1
#         f.write(str(count))
#         f.close()
#     return response

# df = pd.read_csv('area.csv')



# ----------------------------------------------1 ADD USER---------------------------------------------------
@app.route("/api/v1/users", methods=["PUT"])
def addUser():
    #print("########API1#######")
    
    # f = open("count.txt","r")
    # count = int(f.read())
    # f.close()
    # f = open("count.txt","w")
    # count+= 1
    # f.write(str(count))
    # f.close()

    uname = request.get_json()["username"]
    pswd = request.get_json()["password"]
    users = []
    obj = {
        "columns": "uname,pswd",
        "where": "uname='"+uname+"'",
        "table": "users"
    }
    obj = json.dumps(obj)  # stringified json
    obj = json.loads(obj)  # content-type:application/json
    # send request to db api
    x = requests.post("http://0.0.0.0:80/api/v1/db/read", json=obj)
    # print(x.text)
    # Parse the text response (mycursor.fetchall() list) from read api to list
    users = ast.literal_eval(x.text)
    if(len(users) != 0):
        return abort(400)
    else:
        pswd = pswd.lower()
        if(len(pswd) != 40 or not all(c in string.hexdigits for c in pswd)):
            return abort(405)
        # JSONify request object so db api can understand
        obj = {
            "operation": "insert",
            "column": "(uname,pswd)",
            "insert": "['"+uname+"','"+pswd+"']",
            "table": "users"
        }
        obj = json.dumps(obj)  # stringified json
        obj = json.loads(obj)  # content-type:application/json
        # send request to db api
        x = requests.post("http://0.0.0.0:80/api/v1/db/write", json=obj)
        return (jsonify({}), 201)


# ------------------------------------------------2 DELETE USER--------------------------------------------------
@app.route("/api/v1/users/<username>", methods=["DELETE"])
def delUser(username):

    # f = open("count.txt","r")
    # count = int(f.read())
    # f.close()
    # f = open("count.txt","w")
    # count+= 1
    # f.write(str(count))
    # f.close()

    obj = {
        "columns": "uname,pswd",
        "where": "uname='"+username+"'",
        "table": "users"
    }
    obj = json.dumps(obj)  # stringified json
    obj = json.loads(obj)  # content-type:application/json
    # send request to db api
    x = requests.post("http://0.0.0.0:80/api/v1/db/read", json=obj)
    #print(x.text)
    # Parse the text response (mycursor.fetchall() list) from read api to list
    users = ast.literal_eval(x.text)

    if(len(users) == 0):
        return abort(400)
    else:
        obj = {
            "operation": "delete",
            "column": "uname",
            "insert": "'"+username+"'",
            "table": "users"
        }
        obj = json.dumps(obj)  # stringified json
        obj = json.loads(obj)  # content-type:application/json
        # send request to db api
        x = requests.post("http://0.0.0.0:80/api/v1/db/write", json=obj)

#         obj = {
#         "columns": "ride_ID,uname",
#         "where": "created_by='"+username+"' OR uname=",
#         "table": "rides"
#         }
#         obj = json.dumps(obj)  # stringified json
#         obj = json.loads(obj)
#         x = requests.post("http://rides:80/api/v1/db/read", json=obj) #put ip of rides
#         rides = ast.literal_eval(x.text)
        
#         for (ride,uname) in rides:
#             obj = {
#                 "operation": "delete",
#                 "column": "ride_ID,uname",
#                 "insert": "'"+ride+"','"+uname+"'",
#                 "table": "rides"
#             }
#             obj = json.dumps(obj)  # stringified json
#             obj = json.loads(obj)  # content-type:application/json
#             # send request to db api
#             x = requests.post("http://rides:80/api/v1/db/write", json=obj) #put ip of rides
        return (jsonify({}), 200)

# -------------------------------------------------3 List User---------------------------------------------------
@app.route("/api/v1/users", methods=["GET"])
def list_user():
    
    # f = open("count.txt","r")
    # count = int(f.read())
    # f.close()
    # f = open("count.txt","w")
    # count+= 1
    # f.write(str(count))
    # f.close()

    #print("LIST USERS\n\n\n")
    obj = {
        "columns": "uname",
        "where": "",
        "table": "users"
    }

    obj = json.dumps(obj)  # stringified json
    obj = json.loads(obj)  # content-type:application/json
    # send request to db api
    x = requests.post("http://0.0.0.0:80/api/v1/db/read", json=obj)
    #print(x.text)
    # Parse the text response (mycursor.fetchall() list) from read api to list
    users = ast.literal_eval(x.text)

    u=[]
    for user in users:
        u.append(user[0])
    # print("$%$",u)
    return(jsonify(u),200)


# -------------------------------------------------4 Write to db-------------------------------------------------
# Write into a DB
@app.route("/api/v1/db/write", methods=["POST"])
def insert():
    mydb = sqlite3.connect('a2.db')
    mycursor = mydb.cursor()
    op = request.get_json()["operation"]
    column = request.get_json()["column"]
    insert = request.get_json()["insert"]
    table = request.get_json()["table"]
    query = ''
    if(op == "insert"):
        query += 'INSERT INTO ' + table+' '+column+' VALUES ('
        insert = insert[1:len(insert)-1]
        insert = insert.split(",")
        # insert = list(map(lambda x:str(x),insert))
        for i in range(len(insert)):
            if(i != 0):
                query += ","
            query += insert[i]
        query += ")"

    else:
        query += 'DELETE FROM '+table+' WHERE ('
        column = column.split(",")
        insert = insert.split(",")
        if(len(column) != len(insert)):
            abort(400)
        for i in range(len(column)):
            if(i != 0):
                query += 'AND'
            query += column[i]+'='+insert[i]
        query += ")"
    #print(query)
    query = query+";"
    mydb.execute(query)
    # print("\n\n\n\n\n\n EXECUTED \n\n\n\n\n\n")
    mydb.commit()
    mydb.close()
    return ("{}", 200)

# -------------------------------------------------5 Read fron DB-------------------------------------------------
# Read into a DB
@app.route("/api/v1/db/read", methods=["POST"])
def read():
    mydb = sqlite3.connect('a2.db')
    mycursor = mydb.cursor()
    #print("------API#9------")
    query = 'SELECT '
    columns = request.get_json()["columns"]
    where = request.get_json()["where"]
    table = request.get_json()["table"]
    try:
        distinct = request.get_json()["distinct"]
        query+='DISTINCT '
    except:
        distinct = '0'
    '''
    Made the read a little more flexible with respect to where conditions and select * condition
    '''
    if len(columns) != 1:
        for col in columns.split(','):
            query += col+','
        query = query[0:-1]
    else:
        query = 'SELECT '+columns
    if where != '':
        query = query+' FROM '+table+' WHERE ('
        where = where.split(",")
        for i in range(len(where)):
            if(i != 0):
                query += ' AND '
            query += where[i]
        query += ")"
    else:
        query = query+' FROM '+table
    #print(query)
    query = query+";"
    s=mydb.execute(query)
    # s = mycursor.fetchall()
    # print("\n\n\n\n\n\nEXECUTED\n\n\n\n\n")
    res = []
    for row in s:
        res.append(row)
    # Return a string of mycursor.fetchall() that the calling api can parse into a list easily
    mydb.close()
    return (jsonify(res), 200)


#-------------------------------------------------6 CLEAR DB----------------------------------------
@app.route("/api/v1/db/clear", methods=["POST"])
def clear():
    # f = open("count.txt","r")
    # count = int(f.read())
    # f.close()
    # f = open("count.txt","w")
    # count+= 1
    # f.write(str(count))
    # f.close()

    mydb = sqlite3.connect('a2.db')
    mycursor = mydb.cursor()
    query = 'SELECT name FROM sqlite_master WHERE type="table"'
    mycursor.execute(query)
    s = mycursor.fetchall()
    # s = mycursor.fetchall()
    # print("(((((((((",s)

    for table in s:
        # print(table[0])
        query = "DELETE FROM "+table[0]
        mydb.execute(query)
        mydb.commit()

    mydb.close()
    return(jsonify({}),200)

# ---------------------------------------7 COUNT REQUESTS------------------------------------------
@app.route("/api/v1/_count", methods=["GET"])
def totalRequests():
    mydb = sqlite3.connect('a2.db')
    s = mydb.execute("SELECT COUNT(*) FROM http_count");
    res = []
    for row in s:
        res.append(row)
    res = res[0]
    mydb.close()
#     f = open("count.txt","r")
#     count = int(f.read())
#     f.close()
    return(jsonify(res),200)
#    return abort(405)


# --------------------------------------8 RESET REQUESTS -------------------------------------------
@app.route("/api/v1/_count", methods=["DELETE"])
def resetRequests():
    global count1
    mydb = sqlite3.connect('a2.db')
    mydb.execute("DELETE FROM http_count");
    count1 = 0
    mydb.commit()
    mydb.close()
#     f = open("count.txt","w")
#     #count = int(f.read())
#     count = 0
#     f.write(str(count))
#     f.close()
#     count1=0
    return(jsonify({}),200)
#    return abort(405)

if __name__ == '__main__':
    app.debug = True
    app.run(host="0.0.0.0",port=80)
