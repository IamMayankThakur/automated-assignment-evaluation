#from gevent import monkey
#monkey.patch_all()
from flask import Flask, render_template,jsonify,request,abort,Response
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import json
import requests
import pandas as pd
from sqlalchemy.orm.exc import NoResultFound
#from gevent.pywsgi import WSGIServer

users={}
ride_count=1000
rides={}
ride_numbers=[]
count=0
clearDBflaguser=0 #kanishk
clearDBflagride=0 #kanishk
httprequestusers=0

app=Flask(__name__)

db = SQLAlchemy(app)

class User(db.Model):
    __tablename__ = 'user'
    username = db.Column(db.String(800000000000000000000000000000000000), primary_key=True, nullable=False)
    password = db.Column(db.String(800000000000000000000000000000000000), unique=False, nullable=False)

    #kanishk
    @property
    def serialize_user(self):
        return self.username




db.create_all()




def validate_pswd(password):
    if len(password)!=40:
        return False
    for i in password:
        if(not i.isdigit() and i not in 'abcdef' and i not in 'ABCDEF'):
            return False
    return True
        

@app.route('/api/v1/users', methods=['PUT'])
def Add_user():
    global httprequestusers
    httprequestusers+=1
    global users#kanishk
    global clearDBflaguser#kanishk
    if(clearDBflaguser):#kanishk
        clearDBflaguser=0#kanishk
        users={}#kanishk
    try:
        data = {}
        type = 'add'
        data=dict(request.json)
        print(data)
        #print("\nI'm here\n")
        user_check = db.session.query(User).filter_by(username=data['username']).all()
        #print("\nI'm here\n")
        if(len(user_check) == 0):
            if(validate_pswd(data['password'])):
                users[data["username"]]=data["password"]
                print(users.keys())
                url_request = "http://users/api/v1/cd/write"
                headers_request = {'Content-type': 'application/json', 'Accept': 'text/plain'}
                res = json.dumps(data)
                data_request = {'type' : 'add','insert': res}
                response = requests.post(url_request,data=json.dumps(data_request),headers=headers_request)
                print(response)
                check = db.session.query(User).all()
                print(check)
                return Response(json.dumps(dict()),status=201)
            else:
                return jsonify({}),400
        else:
            return jsonify({}),400
    except:
        return jsonify({}),400


@app.route('/api/v1/users/<username>', methods=['DELETE'])
def Remove_user(username):
    global httprequestusers
    httprequestusers+=1
    try:
        type='removeuser'
        data={}
        data["username"]=username
        print("\n I'm here \n")
        user_check = db.session.query(User).filter_by(username=data['username']).all()
        print("\n I'm here \n")
        print("user_check: ",user_check)
        if (len(user_check) != 0):
            print("\n I'm here \n")
            del users[username]
            print("\n I'm here \n")
            url_request = "http://users/api/v1/cd/write"
            headers_request = {'Content-type': 'application/json', 'Accept': 'text/plain'}
            res = json.dumps(data)
            data_request = {'type' : 'removeuser','removeuser': res}
            response = requests.post(url_request,data=json.dumps(data_request),headers=headers_request)
            print(response)
            check = db.session.query(User).all()
            print(check)
            return Response(json.dumps(dict()),status=200)
        else:
            return jsonify({}),400
    except:
        return jsonify({}),400

#kanishk the whole api
@app.route('/api/v1/users', methods=['GET'])
def disp_all_users():
    print("in the display_all users function")
    global httprequestusers
    httprequestusers+=1
    try:
        if(len(users)==0):
            print("no users")
            return jsonify({}),204
        else:
            print("there are users in disp_users")
            data={}
            type='allusers'
            url_request = "http://users/api/v1/cd/read"
            headers_request = {'Content-type': 'application/json', 'Accept': 'text/plain', 'Origin': 'rideshare-2052802136.us-east-1.elb.amazonaws.com'}
            res = json.dumps(data)
            data_request = {'type' : 'allusers','data' : res}
            response = requests.post(url_request,data=json.dumps(data_request),headers=headers_request)
            Users = response.json()
            return jsonify(Users),200
    except:
        return jsonify({}),400

def valid_src_dest(src,dest):
    df = pd.read_csv("AreaNameEnum.csv")
    print(df["Area No"])
    if(int(src) not in list(df["Area No"]) or int(dest) not in list(df["Area No"]) or src == dest):
        return 0
    else:
        return 1





@app.route('/api/v1/cd/write', methods=['POST'])
def write_to_db():
    type_ = request.json['type']
    if type_ == 'add':
        user = request.json['insert']
        data = json.loads(user)
        adduser = User(username=data["username"], password=data["password"])
        db.session.add(adduser)
        db.session.commit()
        return Response(json.dumps(dict()),status=200)
    elif type_ == 'createride':
        ride = request.json['insert']
        data = json.loads(ride)
        addride = Ride(ride_id=data["rideId"],created_by=data["created_by"],source=data["source"],destination=data["destination"],timestamp=data["timestamp"])
        db.session.add(addride)
        db.session.commit()
        return Response(json.dumps(dict()),status=200)
    elif type_ == 'addusertoride':
        userride = request.json['insert']
        data = json.loads(userride)
        addusertoride = User_Ride(ride_id=data["Ride_Id"],user = data["username"],index=data["index"])
        db.session.add(addusertoride)
        db.session.commit()
        return Response(json.dumps(dict()),status=200)
    elif type_ == 'removeuser':
        user = request.json['removeuser']
        data = json.loads(user)
        usertodelete = db.session.query(User).filter_by(username = data['username']).one()
        db.session.delete(usertodelete)
        db.session.commit()
        usertodelete = db.session.query(User_Ride).filter_by(user = data['username']).all()
        for i in usertodelete:
            db.session.delete(i)
        db.session.commit()
        return Response(json.dumps(dict()),status=200)
    elif type_ == 'removeride':
        ride = request.json['removeride']
        data = json.loads(ride)
        usertodelete = db.session.query(Ride).filter_by(ride_id = data['rideId']).one()
        db.session.delete(usertodelete)
        db.session.commit()
        return Response(json.dumps(dict()),status=200)
    elif type_ == 'removeridefromother':
        ride = request.json['removeride']
        data = json.loads(ride)
        usertodelete = db.session.query(User_Ride).filter_by(ride_id = data['rideId']).all()
        for i in usertodelete:
            db.session.delete(i)
        db.session.commit()
        return Response(json.dumps(dict()),status=200)
    elif type_ == 'createuserride':
        userride =  request.json['insert']
        data = json.loads(userride)
        userrideadd = User_Ride(user=data["username"],ride_id=data["rideId"],index=data["index"])
        db.session.add(userrideadd)
        db.session.commit()
        return Response(json.dumps(dict()),status=200)
        

def datetimeconvert(datestring):
    datetime_object = datetime.strptime(datestring, '%d-%m-%Y:%S-%M-%H')
    return datetime_object
    
    
@app.route('/api/v1/cd/read', methods=['POST'])
def read_from_db():
    type_ = request.json['type']
    if type_ == 'ridedetails':
        user = request.json['getride']
        data = json.loads(user)
        rides=db.session.query(Ride).filter_by(ride_id=data['rideId']).one()
        db.session.commit()
        user_rides = db.session.query(User_Ride).filter_by(ride_id=data['rideId']).all()
        users=list()
        for u in user_rides:
            users.append(u.user)
        print(users)
        #print(rides)
        return  jsonify(rides=rides.serialize_ride(users))

    elif type_ == 'readride':
        user = request.json['getride']
        data = json.loads(user)
        rides=db.session.query(Ride).filter_by(source=data['source'], destination=data['destination']).all()
        db.session.commit()

        serialised_rides = []
        for indv_ride in rides:
            print("hello \t\t")
            indv_ride = indv_ride.serialize_ride_deets
            print("bye \t\t")
            if datetimeconvert(indv_ride["timestamp"]) > datetime.now():
                serialised_rides.append(indv_ride)
        print("ser_rides \t\t",serialised_rides)
        #print("hey",rides_temp)
        return jsonify(serialised_rides), 200

    #kanishk
    elif type_ == 'allusers':
        print("in the read db")
        Users = db.session.query(User).all()
        users_list=[]
        for i in Users:
            users_list.append(i.serialize_user)
        print(users_list)
        return jsonify(users_list),200

#kanishk#kanishk#kanishk#kanishk#kanishk#kanishk
@app.route('/api/v1/db/clear', methods=['POST'])
def clean_DB():
    global users
    global rides
    global ride_numbers
    global ride_count
    global count
    global timeflag
    global clearDBflaguser
    global clearDBflagride
    users.clear()
    rides.clear()
    ride_numbers.clear()
    ride_count=1000
    clearDBflaguser=1
    clearDBflagride=1
    print(users)
    users=db.session.query(User).all()
    for i in users:
        db.session.delete(i)
    db.session.commit()
    users=db.session.query(User).all()
    print(users)
    #rides=db.session.query(Ride).all()
    #for i in rides:
    #   db.session.delete(i)
    #db.session.commit()
    #rides=db.session.query(Ride).all()
    #print(rides)
    #userrides=db.session.query(User_Ride).all()
    #for i in userrides:
    #    db.session.delete(i)
    #db.session.commit()
    #userrides=db.session.query(User_Ride).all()
    #print(userrides)
    return jsonify({}),200


@app.route('/api/v1/_count',methods=['GET'])
def totalHTTPrequest():
	global httprequestusers
	totalrequests = []
	totalrequests.append(httprequestusers)
	print(totalrequests)
	return jsonify(totalrequests),200

@app.route('/api/v1/_count',methods=['DELETE'])
def resetHTTPrequest():
    global httprequestusers
    httprequestusers = 0
    return jsonify({}),200
    

if __name__=='__main__':
    app.debug=True
    app.run(port = 5005)
    #http_server = WSGIServer(("",5005),app)
    #http_server.serve_forever()
