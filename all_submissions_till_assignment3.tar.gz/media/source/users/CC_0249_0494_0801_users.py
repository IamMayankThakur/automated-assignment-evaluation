from flask import Flask,render_template,jsonify,request,abort
import csv
import os
import re
import enumeration
import time
import datetime
import pickle
import flask
import os.path
import requests

app=Flask(__name__)

c1=0
b={}
c4=0

if(os.path.isfile("users.data")==False):

	f=open("users.data","wb")
	f.close()

	'''b["data"]={}

	b["file"]="users.data"

	q=request.post("http://127.0.0.1:5000/api/v1/db/write",json=b)
	'''
'''
	b["data"]={}

	b["file"]="rides.data"

	q=request.post("http://127.0.0.1:5000/api/v1/db/write",json=b)
'''
"""

f=open("users.data","wb")

f.close()



f=open("rides.data","wb")

f.close()
"""

@app.errorhandler(405)
def count(e):
	if(request.url!="http://34.230.206.86/api/v1/db/clear" or request.url!="http://34.230.206.86:80/api/v1/_count"):
		global c4
		c4=c4+1
	return "",405

@app.route("/api/v1/db/clear",methods=["POST"])

def dele():
	if request.method!="POST":
		abort(405)
	else:
		if os.path.exists("users.data")==False:
			abort(400,description="db doesnt exist")
		else:
			os.remove("users.data")
			f=open("users.data","wb")
			f.close()
			return "",200

def authenticate(passwd):

    if len(passwd) != 40:

        return False

    try:

        temp = int(passwd, 16)

    except ValueError:

        return False

    return True




@app.route("/api/v1/users",methods=["GET"])

def list_all_users():
	global c4
	c4=c4+1

	users={}
	l=[]

	if request.method!="GET":

		abort(405)
		#return jsonify("")

	else:

		if os.stat("users.data").st_size !=0:

			#f=open("users.data","rb")

			#users=pickle.load(f)

			#f.close()

			b["file"]="users.data"

			users1=requests.post("http://127.0.0.1:8080/api/v1/db/read",json=b)
			users=users1.json()

			for i in users:
				l.append(i)

			return jsonify(l),200

		else:

			return "",204

@app.route("/api/v1/users",methods=["PUT"])

def add_user():
	global c4
	c4=c4+1


	users={}

	temp=dict(request.get_json())
	b={}


	if request.method!="PUT":
		abort(405)



	else:

		if os.stat("users.data").st_size !=0:

			#f=open("users.data","rb")

			#users=pickle.load(f)

			#f.close()

			b["file"]="users.data"

			users1=requests.post("http://127.0.0.1:8080/api/v1/db/read",json=b)
			users=users1.json()



			if temp["username"] not in users.keys():

				if authenticate(temp["password"])==True:

					users[temp["username"]]=temp["password"]

					#f=open("users.data","wb")

					#pickle.dump(users,f)

					#f.close()

					b["data"]=users

					b["file"]="users.data"

					q=requests.post("http://127.0.0.1:8080/api/v1/db/write",json=b)

					return "",201

				else:

					abort(400,description="invalid password")

			else:

				abort(400,description="user already exists")

		else:

			if temp["username"] not in users.keys():

				if authenticate(temp["password"])==True:

					users[temp["username"]]=temp["password"]

					#f=open("users.data","wb")

					#pickle.dump(users,f)

					#f.close()

					b["data"]=users

					b["file"]="users.data"

					q=requests.post("http://127.0.0.1:8080/api/v1/db/write",json=b)


					#status_code = flask.Response(status=201)

					return "",201

				else:

					abort(400,description="invalid password")

			else:

				abort(400,description="user already exists")

				"""Status Codes"""




@app.route("/api/v1/users/<username>",methods=["DELETE"])

def remove_user(username):
	global c4
	c4=c4+1
	b=dict()

	if request.method!="DELETE":

		abort(405)

	else:

		temp=dict()

		users=dict()

		rides=[]

		#if os.stat("rides.data").st_size!=0:

			#f=open("rides.data","rb")

			#rides=pickle.load(f)

			#f.close()

		b["file"]="rides.data"


		rides1=requests.post("http://18.214.133.226:80/api/v1/db/read",json=b)
		try:
			rides=rides1.json()

		except ValueError:
			rides=[]

		for i in range(0,len(rides)-1):
			if rides[i]["created_by"]==username:
				del rides[i]

		for i in range(0,len(rides)):

			for j in range(0,len(rides[i]["users"])):

				if username==rides[i]["users"][j]:

					del rides[i]["users"][j]


		b["data"]=rides

		b["file"]="rides.data"

		q=requests.post("http://18.214.133.226:80/api/v1/db/write",json=b)

		if os.stat("users.data").st_size!=0:

			#f=open("users.data","rb")

			#users=pickle.load(f)

			#f.close()

			b["file"]="users.data"

			users1=requests.post("http://127.0.0.1:8080/api/v1/db/read",json=b)
			users=users1.json()
			if username in users:

				users.pop(username)

				#f=open("users.data","wb")

				#pickle.dump(users,f)

				#f.close()

				b["data"]=users

				b["file"]="users.data"

				q=requests.post("http://127.0.0.1:8080/api/v1/db/write",json=b)

				return "",200

			else:

				abort(400,description="user doesnt exist")

				"""Status Codes"""

		else:

			abort(400,description="no users")



@app.route("/api/v1/_count",methods=["GET"])

def counts():
	if request.method!="GET":
		abort(405)
	else:
		global c4
		l=[]
		l.append(c4)
		return jsonify(l),200



@app.route("/api/v1/_count",methods=["DELETE"])

def counts1():
	if request.method!="DELETE":
		abort(405)
	else:
		global c4
		c4=0
		return "",200


@app.route("/api/v1/db/write",methods=["POST"])

def write():
	b=dict(request.get_json())
	f=open(b["file"],"wb")
	pickle.dump(b["data"],f)
	f.close()
	return jsonify({})

@app.route("/api/v1/db/read",methods=["POST"])

def read():
	b=dict(request.get_json())
	f=open(b["file"],"rb")
	a=pickle.load(f)
	f.close()
	return jsonify(a)





if __name__ == '__main__':	

	app.debug=True
	app.run(host="0.0.0.0",port=8080)