from flask import Flask, render_template, request, abort
import json
import pandas as pd
from datetime import datetime
from pymongo import MongoClient
import re
import requests


"""LOCAL TESINTG"""
# client = MongoClient('localhost', 27017)
# now = datetime.now()
# current_time = now
# # current_time = now.strftime("%d-%m-%Y:%S-%M-%H") #use this to get time

# # db init
# db = client.testdb  # connecting to the database
# collection_users = db.users  # connecting to the collection users
# collection_rides = db.rides  # connecting to the collection users


"""GLOBAL TESINTG"""
users_client = MongoClient("mongodb://users_mongodb:9996/")
rides_client = MongoClient("mongodb://rides_mongodb:9997/")

now = datetime.now()
current_time = now
# current_time = now.strftime("%d-%m-%Y:%S-%M-%H") #use this to get time

# db init
users_db = users_client.users_db  # connecting to the users database
collection_users = users_db.users  # connecting to the collection users

rides_db = rides_client.rides_db  # connecting to the rides database
collection_rides = rides_db.rides  # connecting to the collection users


app = Flask(__name__)

"""

    Note: Whenever there is a read/write/delete operation: just call read() or write() or delete() in the 
    following format :

    READ FORMAT
    >> api_data =
    {
    “table”: “collectionsname”,
    “columns”: [“attributenames",], -------> set this as None if u want all the attributes
    “where”: {"attribute":"value”} ----> set this as {} if u want all the rides
    }
    >> read_db(api_data)

    OR

    WRITE FORMAT
    >> api_data = 
    {
    “insert” : <data>,  -----> data will be either a users or rides dictionary with the respective attribute values you want to insert/update
    “table” : “collections_into_which_you_wanna_insert”
    "status" : "delete"/"update"/"insert" -----> depending on whether it is a delete operation or update.
    }
    >> write_db(api_data)

"""

# data structures
# just an instance. this will keep getting overwritten.
users_data = {
    "username": None,
    "password": None,
    "user_status": None  # valid/invalid
}

rides_data = {
    "rideId": None,  # shreya/drasti I need to have a word about this with you
    "created_by": None,
    "timestamp": None,  # NOT current_time , defined at the top.
    "source": None,
    "destination": None,
    "riders": [],  # will be a list to which you need to append to.
    "ride_status": None  # upcomming/completed/deleted
}


# def #refresh_database():
#     # here we just get all the records in the rides db and then update it.

#     api_data = {
#         "table": "rides",
#         "columns": None,
#         # valid/invalid username checking will happen in the readdb service.
#         "where": {"ride_status": "upcoming"}
#     }
#     # data_retrieved = read_db(api_data)
#     URL = "http://127.0.0.1:5000/api/v1/db/read"
#     data_retrieved = json.loads(requests.post(
#         URL, json=json.dumps(api_data)).content)

#     collection_handler = collection_rides
#     # data_retrieved  = collection_handler.find({"ride_status":"upcoming"},{"_id":0})
#     try:
#         for i in data_retrieved:
#             temp_time = datetime.strptime(i["timestamp"], r"%d-%m-%Y:%S-%M-%H")
#             print("[INFO]:TEMP TIME IS ===", temp_time)
#             if(temp_time < current_time):
#                 # i["ride_status"] = "completed"
#                 # newvalues = { "$set": i }
#                 # collection_handler.update_one({"rideId": i["rideId"]}, newvalues)
#                 # replacing it with API calls
#                 api_data = {
#                     "insert": {"rideId": i["rideId"], "ride_status": "completed"},
#                     "table": "rides",
#                     "status": "update"
#                 }

#                 URL = "http://127.0.0.1:5000/api/v1/db/write"
#                 requests.post(URL, json=json.dumps(api_data))

#     except Exception as e:
#         print(e)
#         pass


@app.route("/")
def main():
    return "Users container service. Wonderful, it works."

# http requets APIs
@app.route("/api/v1/_count", methods=["GET"])
def returnCountOfRequests():
    # countRequests()
    # reading the config file to check which rideId to assign next
    try:
        filee = open("config.json", "r+")
        data_read = json.loads(filee.read())
        filee.close()
        return_data = list()
        return_data.append(data_read["httpRequests"])
        return(json.dumps(return_data))
    except:
        abort(405)
        return "error opening the configuration file, this message is just for testing purposes"


def countRequests():
    # reading the config file to check which rideId to assign next
    try:
        filee = open("config.json", "r+")
        data_read = json.loads(filee.read())
        data_read["httpRequests"] = data_read["httpRequests"] + 1
        filee.seek(0)
        filee.write(json.dumps(data_read))
        filee.truncate()
        filee.close()
    except:
        abort(405)
        return "error opening the configuration file, this message is just for testing purposes"


@app.route("/api/v1/_count", methods=["DELETE"])
def deleteCountOfRequests():
    # countRequests()
    # reading the config file to check which rideId to assign next
    try:
        filee = open("config.json", "r+")
        data_read = json.loads(filee.read())
        data_read["httpRequests"] = 0
        filee.seek(0)
        filee.write(json.dumps(data_read))
        filee.truncate()
        filee.close()
        return {}, 200
    except:
        abort(405)
        return "error opening the configuration file, this message is just for testing purposes"

# "user" collections functions
# listing all the containers
@app.route("/api/v1/users", methods=["GET"])
def list_users():
    countRequests()
    # refresh_database()
    print("[INFO]:LIST ALL USERS FUNCTION EXECUTED")
    api_data = {
        "table": "users",
        "columns": None,
        # valid/invalid username checking will happen in the readdb service.
        "where": {}
    }
    # data_retrieved = read_db(api_data)
    URL = "http://127.0.0.1:5000/api/v1/db/read"
    data_retrieved = json.loads(requests.post(
        URL, json=json.dumps(api_data)).content)
    list_of_users = [i["username"] for i in data_retrieved]
    if(len(list_of_users) == 0):
        return json.dumps(list_of_users), 204
    else:
        return json.dumps(list_of_users), 200


@app.route("/api/v1/users", methods=["PUT"])
def add_user():
    countRequests()
    # refresh_database()
    print("[INFO]:ADD USER FUNCTION EXECUTED")
    """ 
    Checks to be made.
    1. Verify the username does not already exist in the existing database. If it does, abort appropriately
    2. If the username does not exist, make sure the SHA in the message body follows the SHA specfications.
    3. If it does, add this user to the the "users" collections.
    """
    try:
        username = request.get_json()["username"]
        password = request.get_json()["password"]
    except:
        # client didn't send stuff properly
        abort(400)

    # Verify the username does not already exist in the existing database. If it does, abort appropriately
    api_data = {
        "table": "users",
        "columns": None,
        # valid/invalid username checking will happen in the readdb service.
        "where": {"username": username}
    }
    # data_retrieved = read_db(api_data)
    URL = "http://127.0.0.1:5000/api/v1/db/read"
    data_retrieved = json.loads(requests.post(
        URL, json=json.dumps(api_data)).content)

    if(len(data_retrieved) == 0):
        # If the username does not exist, make sure the SHA in the message body follows the SHA specfications.
        rex = re.compile(r'[0-9a-fA-F]{40}')
        m = rex.search(password) == None
        if(len(password) == 40 and not m):
            # If it does, add this user to the the "users" collections.
            api_data = {
                "insert": {"username": username, "password": password, "user_status": "valid"},
                "table": "users",
                "status": "insert"
            }

            URL = "http://127.0.0.1:5000/api/v1/db/write"
            requests.post(URL, json=json.dumps(api_data))
            # return "username was added successfully"
            return {}, 201
        else:
            abort(400)
            # return "password strength inadequate"

    else:
        abort(400)
        # return "Username already exists"


@app.route("/api/v1/users/<username>", methods=["DELETE"])
def remove_user(username=None):
    countRequests()
    print("[INFO]:REMOVE USER FUNCTION EXECUTED")
    """
    1. Check if the user exists. Abort accordingly.
    2. If he does exist, call the write_db() with "username" value set in the user dictionary and status==delete.
    """
    if(username == None):
        # means stuff was not sent properly by the user
        abort(400)

    api_data = {
        "table": "users",
        "columns": None,
        "where": {"username": username}
    }

    URL = "http://127.0.0.1:5000/api/v1/db/read"
    data_retrieved = json.loads(requests.post(
        URL, json=json.dumps(api_data)).content)
    if(len(data_retrieved) == 0):
        abort(400)
        return "username to be deleted does not exists"
    elif(len(data_retrieved) > 1):
        return "probably an error form our side; ignore"
        abort(500)
    else:
        api_data = {
            "insert": {"username": username},
            "table": "users",
            "status": "delete"
        }

    URL = "http://127.0.0.1:5000/api/v1/db/write"
    requests.post(URL, json=json.dumps(api_data))
    return {}, 200
    """
    1. Check if the user exists. Abort accordingly.
    2. If he does exist, call the write_db() with "username" value set in the user dictionary and status==delete.
    """


@app.route("/api/v1/users", methods=["POST"])
def error():
    countRequests()
    abort(405)


"""
NOte:

1.Ishwar will code the read_db and write_db functions. Just pick a function, discuss on the group
and code your part. Call the read_db and write_db functions properly.

2.read_db() will always return a list of user/rides dictionaries. It can be a single mongoDB document in the form
[{}] or many matching documents of the form [{},{},{},{}]

3. Do not fuck up the write operations. Set the _status variables properly.

4. Return the dictionaries properly from your functions. call
>> return json.dumps(your_return_dictionary)

5. Don't be a dumbass by sharing this template with others. #obviously

6. Write proper comments. 

"""
@app.route("/api/v1/db/read", methods=["POST"])
def read_db():
    print("[INFO]:READ DB FUNCTION EXECUTED")
    """
    READ FORMAT
    >> api_data =
    {
    “table”: “collectionsname”,
    “columns”: [“attributenames",], -------> set this as None if u want all the attributes
    “where”: {"attribute"="value”} ----> set this as None if u want all the rides
    }
    so this is the incomming data ; for now let's just code assuming columns=None and we return all values
    """
    try:
        dictionary_data = {}
        print("IN THE READ DB FUNCTION", request.get_json())
        dictionary_data["table"] = json.loads(request.get_json())["table"]
        print(dictionary_data["table"])
        dictionary_data["columns"] = json.loads(request.get_json())["columns"]
        print(dictionary_data["columns"])
        dictionary_data["where"] = json.loads(request.get_json())["where"]
        print(dictionary_data["where"])

    except:
        abort(500)
        pass

    # first we need to figure out which collection we need to append to
    # defining a collection handler
    if(dictionary_data["table"] == "users"):
        collection_handler = collection_users
        doc = "user_status"
        document_status = "valid"
    elif(dictionary_data["table"] == "rides"):
        collection_handler = collection_rides
        doc = "ride_status"
        document_status = "upcoming"

    # if(dictionary_data["columns"]==None): #getting all the attributes
    print("[INFO]: CONSTRAINT CHECKING", dictionary_data["where"])
    dictionary_data["where"][doc] = document_status
    print("WHERE STATUS: ", dictionary_data["where"])
    data_retrieved = collection_handler.find(
        dictionary_data["where"], {"_id": 0})
    return json.dumps(list(data_retrieved))  # [{}] format


@app.route("/api/v1/db/write", methods=["POST"])
def write_db():
    print("[INFO]:WRITE DB FUNCTION EXECUTED")
    """
    recieved
    api_data = {
            "insert" : rides_data,
            "table" : "rides",
            "status": "insert"
        } incomming data format , where rides_data is the record we need to insert
    """
    # first we need to figure out which collection we need to append to
    # defining a collection handler
    try:
        dictionary_data = {}
        print("IN THE READ DB FUNCTION", request.get_json())
        dictionary_data["insert"] = json.loads(request.get_json())["insert"]
        print(dictionary_data["insert"])
        dictionary_data["table"] = json.loads(request.get_json())["table"]
        print(dictionary_data["table"])
        dictionary_data["status"] = json.loads(request.get_json())["status"]
        print(dictionary_data["status"])

    except:
        abort(500)
        pass

    if(dictionary_data["table"] == "users"):
        collection_handler = collection_users
    elif(dictionary_data["table"] == "rides"):
        collection_handler = collection_rides

    # now we need to check the status and see what kind of write is being requested for
    write_type = dictionary_data["status"]

    if write_type == "insert":
        collection_handler.insert_one(dictionary_data["insert"])

    elif write_type == "update":

        # {"rideId" : rideId, "riders":username}
        temp = dictionary_data["insert"]
        print("[INFO]:UPDATE FUNCTION")
        myquery = {"rideId": temp["rideId"]}
        # using myquery, lets first get the record of that particular rideId
        # we need to set api_data again
        api_data = {
            "table": "rides",
            "columns": None,
            "where": {"rideId": temp["rideId"]}
        }

        URL = "http://127.0.0.1:5000/api/v1/db/read"
        retrieved_record = json.loads(requests.post(
            URL, json=json.dumps(api_data)).content)

        if(len(retrieved_record) != 1):  # should recieve only one unique row
            abort(500)
        else:
            # coz the return is in the form of a list
            retrieved_record = retrieved_record[0]
            # now lets update this retrieved record with the new values
            # the following part is hardcoded. #need to fix this in future iterations.
            for key in temp.keys():
                if(key != "rideId" and key != "riders"):
                    # replacing all the old values with the new values #need a for loop to replace every key value pair
                    retrieved_record[key] = temp[key]
                elif(key == "riders"):
                    retrieved_record[key].append(temp[key])
                    retrieved_record[key] = list(set(retrieved_record[key]))
            # once this is done, we need to write "retireved_record" back into the mongo db
            newvalues = {"$set": retrieved_record}
            # find the document with myquery and update it with the newvalues
            collection_handler.update_one(myquery, newvalues)

    elif write_type == "delete":
        print("[INFO]:UPDATE FUNCTION")
        # here we need to find that particular record and not delete it, but just set the rides status or the user status to deleted/invalid
        if(dictionary_data["table"] == "users"):
            document_status = "invlaid"
            set_table = "users"
        else:  # if it is rides
            document_status = "deleted"
            set_table = "rides"

        # {"rideId" : rideId} or ("username":username)
        temp = dictionary_data["insert"]
        myquery = temp

        api_data = {
            "table": set_table,
            "columns": None,
            "where": temp
        }
        URL = "http://127.0.0.1:5000/api/v1/db/read"
        retrieved_record = json.loads(requests.post(
            URL, json=json.dumps(api_data)).content)

        if(len(retrieved_record) != 1):
            abort(500)
        else:
            retrieved_record = retrieved_record[0]
            # coz the return is in the form of a list
            # now lets update this retrieved record with the new values
            # set_table[-1] = ride/user + "_status"
            newvalues = {"$set": {set_table[:-1]+"_status": document_status}}
            # find the document with myquery and update it with the newvalues
            collection_handler.update_one(myquery, newvalues)

    return True


@app.route("/api/v1/db/clear", methods=["POST"])
def clear_db():
    countRequests()
    users_client.drop_database("users_db")
    return {}, 200


if __name__ == "__main__":
    app.run(host='0.0.0.0', debug=True, port=5000)
