from flask import Flask,render_template,jsonify,request,abort
from random import seed
import datetime
import random
import pymysql
import string
import requests
import json


app=Flask(__name__)

#Database connection
connection = pymysql.connect(host="172.18.0.2", port=3306, user="root", passwd="password", database="cloud")
cursor = connection.cursor()

#Load Balancers Checks this.
@app.route("/")
def new_method():
    return "", 200

# For adding User.
@app.route("/api/v1/users",methods=["PUT"])
def add_user():
    # return jsonify({"hey":"there1"}), 200
    user_details = dict(request.get_json())
    # global http_count
    # http_count = http_count +  1
    app.config["http_count1"] += 1
    payload = {"table":"User_Details","columns":["*"],\
        "where": "NULL"}
    req = requests.post("http://0.0.0.0:80/api/v1/db/read", json = {"query": payload})
    flag = verify_user(req.text, user_details["username"])
    if(flag == 1):
        return jsonify({}), 400

    if(check(str(user_details["password"]))):
        payload = {"insert":[str(user_details["username"]), str(user_details["password"]),str(random.randint(0, 9999999999))]\
            ,"columns":["User_Name","Password","User_Id"],"table":"User_Details"}
        req = requests.put("http://0.0.0.0:80/api/v1/db/write", json = {"query": payload})
        return jsonify({}), req.status_code
    else:   
        return jsonify({}), 400


# For verifying user existence.
def verify_user(users,username):
    flag = 0;
    if(users == ""):
        return 2
    users = json.loads(users);
    # print("User is being verified",users)
    for i in users.keys():
        # print(users[i][0])
        if(users[i][0] == username):
            flag = 1;
    return flag


# For checking Whether a Password is hexadecimal or not
def check(value):  
    # print("Entered in check"+"".join(value))
    if(len(value) != 40):
        return False
    for letter in value:
        # print(letter)        
        # If anything other than hexdigit  
        # letter is present, then return  
        # False, else return True  
        if letter not in string.hexdigits:  
            return False
    return True


# For Deleting User.
# Have to make some changes.
@app.route("/api/v1/users/<username>", methods=["DELETE"])
def delete_user(username):
    #for deleting from User_Details
    # global http_count
    # http_count += 1
    app.config["http_count1"] += 1
    payload = {"table":"User_Details","columns":["User_Name","Password"],\
        "where":"User_Name = '" + username}
    req = requests.post("http://0.0.0.0:80/api/v1/db/read", json = {"query": payload})
    flag = verify_user(req.text, username)
    if(flag == 0):
        return jsonify({}), 400
    if(req.status_code == 201):
        try:
            deleteSql = "DELETE FROM User_Details WHERE User_Name = '" + str(username) + "';"
            cursor.execute(deleteSql)
            connection.commit()
            return jsonify({}), 200
        except:
            return jsonify({}), 400
    elif(req.status_code == 401):
        return jsonify({}), 400
    else:       
        return jsonify({}), 405


# For Listing The User.
@app.route("/api/v1/users",methods=["GET"])
def list_users():
    try:
        # global http_count
        # http_count += 1
        app.config["http_count1"] += 1
        payload = {"table":"User_Details","columns":["*"],\
            "where": "NULL"}
        req = requests.post("http://0.0.0.0:80/api/v1/db/read", json = {"query": payload})
        if(req.text == ""):
            return jsonify([]), 204
        users = json.loads(req.text)
        usernames = list()
        for i in users.keys():
            usernames.append(users[i][0])
        return jsonify(usernames), 200
    except:
        return jsonify([]), 405


# Write to DB
@app.route("/api/v1/db/write", methods=["PUT"])
def db_write():
    # print("I am in Write DB")
    req = request.get_json()["query"]
    query = "INSERT INTO " + req["table"] + " ("
    for i in req["columns"]:
        query = query + i + ","
    query = query[0:len(query)-1] + ") VALUES("
    for i in req["insert"]:
        query = query + "'" + str(i) + "',"
    query = query[0:len(query)-1] + ");"
    try:
        # print(query) 
        cursor.execute(query)
        connection.commit()
        return jsonify({"noerror":query}), 201
    except Exception as ex:
        # print(ex.args)
        return jsonify({"error":query}), 400


# Read to DB
@app.route("/api/v1/db/read", methods=["POST"])
def db_read():
    req = request.get_json()["query"]
    if(req["where"] == "NULL"):
        query = "SELECT * FROM " + req["table"] + " ;"
    else:
        query = "SELECT * FROM " + req["table"] +" WHERE " + req["where"] + "';"
    try: 
        # print(query)
        cursor.execute(query)
        rows = cursor.fetchall()
        data = dict()
        index = 1
        for r in rows:
            temp = list()
            for i in r:
                temp.append(str(i))
            data[index] = temp
            index += 1
        
        if (len(rows) != 0):
            return jsonify(data), 201
        else:
            return "", 401
    except:
        return "", 400


# Clear DB
@app.route("/api/v1/db/clear", methods=["POST"])
def clear_db():
    # global http_count
    # http_count += 1
    try:
        deleteSql = "DELETE FROM User_Details;"
        cursor.execute(deleteSql)
        connection.commit()
        return jsonify({}), 200
    except:
        return jsonify({}), 400


# For Counting the Total Number of Http request made.
@app.route("/api/v1/_count",methods=["GET"])
def count_http():
    # global http_count
    try:
        return json.dumps([app.config["http_count1"]]), 200
    except:
        return {}, 405


# For Reseting Http request counter.
@app.route("/api/v1/_count", methods=["DELETE"])
def reset_http():
    # global http_count
    try:
        app.config["http_count1"] = 0
        return {}, 200
    except:
        return {}, 405


if __name__ == '__main__':
    app.debug = True
    app.config["http_count1"] = 0
    app.run(host="0.0.0.0", port='80')