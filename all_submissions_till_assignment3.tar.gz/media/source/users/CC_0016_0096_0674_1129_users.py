import sys
import os
from dbb import db
from dbb import rides
from dbb import users
from sqlalchemy.exc import IntegrityError
from flask import Flask
from flask import request
from flask import jsonify
from flask import url_for
from flask import redirect
import json
from sqlalchemy import text
import requests
import datetime

n=0

app = Flask(__name__)
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

#app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:////home/harshith/Desktop/6th_semester/cloud/flask/assignment1/not/san/cloud.db'
app.config['SQLALCHEMY_DATABASE_URI'] 	= 'sqlite:///../data/user.db'
db.init_app(app)

		
@app.route('/api/v1/users', methods=['POST','DELETE','PATCH','COPY','HEAD','OPTIONS','LINK','UNLINK','PURGE','LOCK','UNLOCK','PROPFIND','VIEW']) #API 0.1
def func():
	
		global n
		n=n+1
		return jsonify({}),405
		

@app.route('/api/v1/users/<name>', methods=['POST','PUT','GET','PATCH','COPY','HEAD','OPTIONS','LINK','UNLINK','PURGE','LOCK','UNLOCK','PROPFIND','VIEW']) #API 0.2
def func1(name):
	
		global n
		n=n+1
		return jsonify({}),405

@app.route('/api/v1/users', methods=['PUT']) #API 1
def add_user():
		
		global n
		n=n+1
		if(request.method!="PUT"):
			return jsonify({}),405
	
		_json = request.json
		_name = _json['username']
		_password = _json['password']
		
		if _name and _password and request.method == 'PUT':
		
			if(len(_password)==40):
				for i in _password:
					if(i=='A' or i=='a' or i=='B' or i=='b' or i=='C' or i=='c' or i=='D' or i=='d' or i=='E' or i=='e' or i=='F' or i=='f' or ( int(i)>=0 and int(i)<=9)):
						url='http://ec2-34-239-72-32.compute-1.amazonaws.com/api/v1/db/write' 
						obj={'table' : 'users', 'name':_name , 'password':_password,'method': 'PUT'}
						response = requests.post(url,json=obj)
						
						if(response.status_code == 201):
							return jsonify({}),201
						else:	
							return jsonify({}),400
			else:
				return jsonify({}),400
			
						
			
		
@app.route('/api/v1/users/<name>', methods=['DELETE']) # API 2
def delete_user(name):
		
		global n
		n=n+1
		if(not(request.method=="DELETE")):
			return jsonify({}),405
			
		url='http://ec2-34-239-72-32.compute-1.amazonaws.com/api/v1/db/read' 
		obj={'table':'users','name':name,'method': 'GET'}
		response = requests.post(url,json=obj)	
		if(response.status_code == 400):
				return jsonify({}),400
		
		url='http://ec2-34-239-72-32.compute-1.amazonaws.com/api/v1/db/write' 
		obj={'table' : 'users', 'name':name,'method': 'DELETE'}
		response = requests.post(url,json=obj)
		if(response.status_code != 200):
				return jsonify({}),400
				
		url='http://ec2-52-71-16-98.compute-1.amazonaws.com/api/v1/db/write'
		obj={'table' : 'rides', 'created_by':name,'method': 'DELETE2'}
		response = requests.post(url,json=obj)
		if(response.status_code != 200):
				return jsonify({}),400
				
		
		
				
				
	
		url='http://ec2-52-71-16-98.compute-1.amazonaws.com/api/v1/db/read'
		obj={'table':'rides','name':name,'method': 'GETUSERS'}
		response = requests.post(url,json=obj)
		x = json.loads(response.text)
		
		
		
		lst=[]
		for i in x:
			m=i['users']
			if not m:
				continue
			elif(name in m):
			
				lst.append(i['rideId'])
			else:
				continue
				
		#return jsonify(lst),200
		length=len(lst)
		
		for i in lst:
			url='http://ec2-52-71-16-98.compute-1.amazonaws.com/api/v1/db/read'
			
			obj={'table':'rides','rideId':i,'method': 'GETALL'}
			response1 = requests.post(url,json=obj)
			
			x = json.loads(response1.text)
			passengers = x["users"]
			
			k=passengers.split(',')
			k.remove(name)
			
			newusers = ','.join(k)
			
			
						
			url='http://ec2-52-71-16-98.compute-1.amazonaws.com/api/v1/db/write' 
			obj={'table':'rides','users': newusers,'rideId':i,'method': 'UPDATE'}
			response = requests.post(url,json=obj)
			if(response.status_code == 200):
				continue
			else:	
				return jsonify({}),400
				
		return jsonify({}),200
			
		
			
			

	

@app.route('/api/v1/users',methods=['GET']) #API x
def listusers():
	
	global n
	n=n+1

	if(not(request.method == 'GET')):
		return jsonify({}),405
		
	
	
	url='http://ec2-34-239-72-32.compute-1.amazonaws.com/api/v1/db/read'
	
	obj={'table':'users','method': 'GETALL'}
	response = requests.post(url,json=obj)
	x =json.loads(response.text)
	
	
	if(response.text=="{}\n"):
		return jsonify({}),204
	else:	
		
		
		lst=[]
		for i in x:
			m=i['username']
			lst.append(m)
			
			
		return jsonify(lst),200
		
		
@app.route('/api/v1/db/clear',methods=['POST']) #API y
def del1():

	if(not(request.method == 'POST')):
		return jsonify({}),405
		
	
	
	sql = "DELETE FROM users"
	
	
	x=db.session.execute(sql)
	db.session.commit()
	
	
	if(x):
		return jsonify({}),200
	else:
		return jsonify({}),400	
		
		

	
@app.route('/api/v1/_count', methods=['GET']) #API counthttp
def count_http():
	
	if(request.method!="GET"):
			return jsonify({}),405
	
	lst=[]
	lst.append(n)		
	return jsonify(lst),200	
			
			
			
@app.route('/api/v1/_count', methods=['DELETE']) #API clearhttp
def clear_http():
	
	if(request.method!="DELETE"):
			return jsonify({}),405
			
	global n

	n=0
	
	return jsonify({}),200		
 
	


@app.route('/api/v1/db/write',methods=["POST"])  #API 8
def write():
	try:
		_json = request.get_json()
		
		if(_json['table']=='users'):
			if (_json['method']=='PUT'):
			
				a=_json['name']
				b=_json['password']
				
				c="\'" + a + "\'" + "," + "\'" + b + "\'"
				sql = text("INSERT INTO users (username,password) VALUES ("+c+")")
				x=db.session.execute(sql)
				db.session.commit()
						
				if(x):
					return jsonify({}),201
				else:
					return jsonify({}),400	
								
				
			if (_json['method']=='DELETE'):							
				
				c="\'" + _json['name'] + "\'"
				sql = text("DELETE FROM users WHERE username="+c)
									 
				x=db.session.execute(sql)
				#x=db.session.execute("DELETE FROM users WHERE username="+c				
				db.session.commit()				
				
				if(x):
					return jsonify({}),200
				else:
					return jsonify({}),400					
				
			else:
				return not_found()					
			
				
		
				
						
	except Exception as e:
		print(e)
			


@app.route('/api/v1/db/read',methods=['POST'])   #API 9
def read():


	try:
		_json = request.get_json()
		
		
		if(_json['table']=='users'):
		
			if (_json['method']=='GET'):
				
				a="\'" + _json['name'] + "\'"
				select_stmt = text("SELECT * FROM users WHERE username=:param")
				
				
				c=0
				x=db.session.execute(select_stmt,{"param":_json['name']})#,_json['name'])
				for i in x:
					c=c+1;
					
				if(c>0):
					return jsonify({}),200
				else:
					return jsonify({}),400
					
					
					
			if (_json['method']=='GETALL'):
				
				
				select_stmt = text("SELECT username FROM users")
				x=db.session.execute(select_stmt)
				#rows = cursor.fetchall()
				li=[]
				#for i in x:
				#	li.append(i)
					
				#return jsonify( [dict(row) for row in x])
				
				if(x):
					return jsonify( [dict(row) for row in x]),200
				else:
					return jsonify({}),400	
				
		
		
				
				
				
	except Exception as e:
		print(e)
	
		
		
				




		
@app.errorhandler(404)
def not_found(error=None):
    message = {
        'status': 404,
        'message': 'Not Found: ' + request.url,
    }
    resp = jsonify(message)
    resp.status_code = 404

    return resp
		
if __name__ == "__main__":
    if os.environ.get('PORT') is not None:
        app.run(debug=True, host='0.0.0.0', port=os.environ.get('PORT'))
    else:
        app.run(debug=True, host='0.0.0.0',port=80)
