#changed
# <------ IP addresses that can be used are 172.17.0.2 or 172.17.0.3, should check which among them in the container before using --------->

from flask import Flask, render_template,\
jsonify,request,abort

app=Flask(__name__)

import sqlite3
import requests
import random
import datetime

RS400=400

RS405=405
RS200=200
RS201=201
RS204=204
ct=0
f = open("AreaNameEnum.csv", "r")
l = f.readlines()
source = "1"
arealist = []
destination = "20"
m = [0, 0]
for i in l:
    i = i.split(",")
    arealist.append(i[0])
arealist=arealist[1:]










shalist=['0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f']
def checksha(string):
	if(len(string)!=40):
		return True
	else:
		for i in list(string):
			if i not in shalist:
				return True
	return False

@app.route("/api/v1/_count",methods=["GET"])
def recount():
	if(request.method!="GET"):
		return jsonify({}),RS405
	con=sqlite3.connect("../data/rideshare.db")
	cur=con.cursor()	 
	q="select * from count;"
	cur.execute(q)
	res=cur.fetchall()
	ct=res[0][0]
	sstr='['+str(ct)+']'
	return sstr	

@app.route("/api/v1/_count",methods=["DELETE"])
def resetcount():
	if(request.method!="DELETE"):
		return jsonify({}),RS405
	con=sqlite3.connect("../data/rideshare.db")
	cur=con.cursor()	 
	q="update count set ct=0;"
	cur.execute(q)
	con.commit()
	return jsonify({}),RS200	
def count():
	con=sqlite3.connect("../data/rideshare.db")
	cur=con.cursor()	 
	q="update count set ct=ct+1;"
	cur.execute(q)
	con.commit()




@app.route("/api/v1/users",methods=["PUT","DELETE","POST"])
def adduser():
	count()
	req=request.get_json()
	if(request.method!="PUT"):
		return jsonify({}),RS405
	if(not("username" in req and "password" in req)):
		return jsonify({}),RS400
	username=req["username"]
	#if ("username" in req):
	#	return "Yesss"
	password=req["password"]
	if username=="":
		return jsonify({}),RS400
	if(checksha(password)):
		return jsonify({}),RS400
	
	req1={"where":["username='%s'" % username],"columns":["username"],"table":"user"}
	r1 = requests.post('http://localhost:5000/api/v1/db/read',json=req1)
	l=eval(r1.text)
	if(len(l)!=0):
		# d={"405":"Not allowed"}
		return jsonify({}),RS400
	
	
	req2={"table":"user","columns":["username","password"],"insert":[username,password]}
	r2 = requests.post('http://localhost:5000/api/v1/db/write',json=req2)
	# return r2.json()     
	if("200" in str(r2)):
		return jsonify({}),RS201
	else:
		return jsonify({}),RS500
######heree 16/3
@app.route("/api/v1/users/<name>",methods=["DELETE","POST","GET","PUT"])
def deluser(name):
	count()
	if(request.method!="DELETE"):
		return jsonify({}),RS405

	#'''
	#check if there is username in user table
	#'''
	req1={"where":["username='%s'" % name],"columns":["username"],"table":"user"}
	r1 = requests.post('http://localhost:5000/api/v1/db/read',json=req1)
	l=eval(r1.text)

	if len(l)!=0:

		#'''
		#delete from user table
		#'''
		req2={"table":"user","delete":name,"columns":"username"}
		r = requests.post('http://localhost:5000/api/v1/db/write',json=req2)


		if("200" not in str(r)):
			return jsonify({}),RS500
		#else:
		#	return jsonify({}),RS500
		#deleting if name is creator 
		newreq={"table":"rides","delete":name,"columns":"username"}
		headers={"Origin":"34.206.7.67"}
		newr=requests.post('http://18.213.31.1:80/api/v1/db/write',json=newreq)


		req4={"where":[],"columns":["users","rideid"],"table":"rides"}
		headers={"Origin":"34.206.7.67"}
		r4= requests.post('http://18.213.31.1:80/api/v1/db/read',json=req4)

		mylist=eval(r4.text)
		#print("MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM")
		#print(name)
		for i in range(len(mylist)):
			myusers=eval(mylist[i][0])
			print("MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM")
			print(mylist[i][0])
			if name in myusers :
				myusers.remove(name)
				rid=mylist[i][1]
				mystr=str(myusers)
				newreq={"table":"rides","sset":['users="%s"'% mystr],"where":["rideid='%s'" % rid]}
				newr=requests.post('http://18.213.31.1:80/api/v1/db/write',json=newreq)
		

		return jsonify({}),RS200
			

	d={"405":"Not allowed"}
	return jsonify({}),RS400

	#return "donee"

#to be put on user microservice
@app.route("/api/v1/users",methods=["GET","POST","DELETE"])
def listusers():
	count()
	if(request.method!="GET"):
		return jsonify({}),RS405
	req1={"where":[],"columns":["username"],"table":"user"}
	r1 = requests.post('http://localhost:5000/api/v1/db/read',json=req1)
	if('200' in str(r1)):
		responselist=[]
		l=eval(r1.text)
		if len(l)==0:
			return jsonify({}),RS204		
		usernames=[]
		users="["
		#return users 
		for i in range(len(l)):
			usernames.append(l[i][0])
			users+="'"+l[i][0]+"'"+","
					
		users=users[:-1]
		users+="]"
		return users
	
	return jsonify({}),RS400

#######
@app.route("/api/v1/db/read",methods=["POST"])
def readdb():
	con=sqlite3.connect("../data/rideshare.db")
	cursorobj=con.cursor()	
	req=request.get_json()
	where=req["where"] #list
	cols=req["columns"] #list
	table=req["table"]
	sstr="select "
	if(len(cols)==0):
		sstr+=" *,"
	for i in range(len(cols)):
		sstr+="%s ," % cols[i]
	sstr=sstr[:-1]
	sstr+="from %s " % table
	if(len(where)!=0):
		sstr+="where "	
		for i in range(len(where)):
			sstr+= where[i]
			sstr+=" and "
		sstr=sstr[:-4]
	sstr+=";"

	res=cursorobj.execute(sstr)
	return str(list(res))


# @app.route("/api/v1/db/write",methods=["POST"])
# def writedb():
# 	con=sqlite3.connect("/home/ubuntu/rideshare.db")
# 	cursorobj=con.cursor()	
# 	#sstr="insert into user values('abishek','123sg');"

# 	req=request.get_json()
# 	if "insert" in req:
# 		insert=req["insert"] #list
# 		cols=req["columns"] #list
# 		table=req["table"]
# 		sstr="insert into %s(" % table
		 

# 		for i in range(len(cols)):
# 			sstr+=cols[i]+","
# 		sstr=sstr[:-1]
# 		sstr+=") values("

# 		for i in range(len(insert)):
# 			sstr+="'%s'," %insert[i]
# 		sstr=sstr[:-1]
# 		sstr+=");"
# 		#return sstr
# 		cursorobj.execute(sstr)
# 		con.commit()
# 		dok={"201":"ok"}
# 		return jsonify(dok)		

# 	elif("delete" in req):
# 		data=req["delete"]
# 		table=req["table"]
# 		col=req["columns"]
# 		#data=req["data"]
# 		sstr="delete from %s where " %table
# 		sstr+=col+"= '%s';" %data
# 		cursorobj.execute(sstr)
# 		con.commit()
# 		dok={"201":"ok"}
# 		return jsonify(dok)		
# 	elif ("sset" in req ):
# 		table=req["table"]
# 		sset=req["sset"] #list
# 		where=req["where"] #list
# 		sstr="UPDATE %s set " % table
		
# 		for i in range(len(sset)):
# 			sstr+=" %s," % sset[i]
# 		sstr=sstr[:-1]
# 		if(len(where)!=0):
# 			sstr+=" where "	
# 			for i in range(len(where)):
# 				sstr+=  where[i]
# 				sstr+=" and "
# 			sstr=sstr[:-4]
# 		sstr+=";"
# 		print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
# 		print(sstr)
# 		cursorobj.execute(sstr)
# 		con.commit()
# 		dok={"201":"ok"}
# 		return jsonify(dok)

# <------ Idk what changes, but this is a method from the new api calling function and guees we should change the db functions because it needs to know which db Users or Rides --------->

#<----- Here also database must be parameterised ig ------>
@app.route("/api/v1/db/write",methods=["POST"])
def writedb():
	con=sqlite3.connect("../data/rideshare.db")
	cursorobj=con.cursor()	
	#sstr="insert into user values('abishek','123sg');"

	
	req=request.get_json()
	if "insert" in req:
		insert=req["insert"] #list
		cols=req["columns"] #list
		table=req["table"]
		sstr="insert into %s(" % table
		 

		for i in range(len(cols)):
			sstr+=cols[i]+","
		sstr=sstr[:-1]
		sstr+=") values("

		for i in range(len(insert)):
			sstr+="'%s'," %insert[i]
		sstr=sstr[:-1]
		sstr+=");"
		#return sstr
		cursorobj.execute(sstr)
		con.commit()
		dok={"201":"ok"}
		return jsonify(dok)		

	elif("delete" in req):
		data=req["delete"]
		table=req["table"]
		col=req["columns"]
		#data=req["data"]
		if data=="" and col=="":
			sstr="delete from %s;" %table
		else:
			sstr="delete from %s where " %table
			sstr+=col+"= '%s';" %data
		cursorobj.execute(sstr)
		con.commit()
		dok={"201":"ok"}
		return jsonify(dok)	
		
	elif ("sset" in req ):
		table=req["table"]
		sset=req["sset"] #list
		where=req["where"] #list
		sstr="UPDATE %s set " % table
		
		for i in range(len(sset)):
			sstr+=" %s," % sset[i]
		sstr=sstr[:-1]
		if(len(where)!=0):
			sstr+=" where "	
			for i in range(len(where)):
				sstr+=  where[i]
				sstr+=" and "
			sstr=sstr[:-4]
		sstr+=";"
		print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
		print(sstr)
		cursorobj.execute(sstr)
		con.commit()
		dok={"201":"ok"}
		return jsonify(dok)		
	
@app.route("/api/v1/db/clear",methods=["DELETE","POST","GET","PUT"])
def cleardb():	
	#count()
	if(request.method!="POST"):
		return jsonify({}),RS405
	tablename="user"
	req={"table":tablename,"delete":"","columns":""}
	r = requests.post('http://localhost:5000/api/v1/db/write',json=req)
	#r2=requests.post('http://172.21.0.3:80/api/v1/db/clear',json=req)
	
	if("200" in str(r)):
		return jsonify({}),RS200
	else:
		return jsonify({}),RS500
	
if __name__ == '__main__':	
	app.debug=True
	#app.bind(9000)
	#app.run(host="0.0.0.1",port=5000)
	app.run()
