from flask import Flask, jsonify, request, abort
from flask_sqlalchemy import SQLAlchemy
import requests, json
import datetime

application = Flask(__name__)
application.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///user.db'
application.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(application)


class User(db.Model):
	id = db.Column(db.Integer, primary_key=True)
	username = db.Column(db.String(80), unique=True, nullable=False)
	password = db.Column(db.String(80), nullable=False)

	def __repr__(self):
		return f'<User {self.username}>'


ADDR = "http://A3-1166210111.us-east-1.elb.amazonaws.com"
PORT = ":80"
WRADR = f'http://0.0.0.0{PORT}/api/v1/db/write'
RADR = f'http://0.0.0.0{PORT}/api/v1/db/read'
headers = {"Content-Type": "application/json"}
request_count = 0

@application.route("/api/v1/db/write", methods=["POST"])
def write_to_db():
	operation = request.get_json()["operation"]
	if operation == 1:
		uname = request.get_json()["username"]
		passwd = request.get_json()["password"]
		new_user = User(username=uname, password=passwd)
		db.session.add(new_user)
	elif operation == 2:
		# send this request only if you know that the user already exists
		uname = request.get_json()["username"]
		remove_this_user = User.query.filter_by(username=uname).first()
		db.session.delete(remove_this_user)
	
	db.session.commit()
	return jsonify({"Error": ""})


@application.route("/api/v1/db/read", methods=["POST"])
def read_from_db():
	operation = request.get_json()["operation"]
	if operation == 1 or operation == 2:
		uname = request.get_json()["username"]
		if not User.query.filter_by(username=uname).first():
			return jsonify({"Error": "user does not exist"})
		return jsonify({"Error": ""})
	elif operation == 10:
		uname_list = User.query.all()
		uname_list = [i.username for i in uname_list]
		return jsonify({"userList":uname_list})
	return jsonify({"Error": ""})

def is_hex(s):
	hex_digits = set("0123456789abcdefABCDEF")
	for char in s:
		if not (char in hex_digits):
			return False
	return True


@application.route("/api/v1/users", methods=["DELETE", "GET", "POST", "PUT"])
def add_a_user_or_list_user():
	if request.method == "PUT":
		update_count()
		try:
			uname = request.get_json()["username"]
		except KeyError:
			return {}, 400
		check = requests.post(
			url=RADR, json={"operation": 1, "username": uname}, headers=headers)
		c_json = check.json()
		if c_json["Error"] == "user does not exist":
			passwrd = request.get_json()["password"]
			if len(passwrd) == 40 and is_hex(passwrd):
				data = {"operation": 1, "username": uname, "password": passwrd}
				resp = requests.post(url=WRADR, json=data, headers=headers)
				r_json = resp.json()
				if r_json["Error"] == "":
					# No Errors, 200 OK
					return {}, 201

			else:
				# if length of password < 40 or it is not in hex or both
				# Bad Request
				return {}, 400
		else:
			return {}, 400
	elif request.method == "GET":
		update_count()
		data = {"operation": 10}
		resp = requests.post(url=RADR, json=data, headers=headers)
		r_json = resp.json()
		if r_json["userList"] == []:
			return jsonify([]), 204
		else:
			return jsonify(r_json["userList"]), 200
	else:
		return method_not_allowed()



@application.route("/api/v1/users/<username>", methods=["DELETE", "GET", "POST", "PUT"])
def delete_a_user(username):
	if request.method == "DELETE":
		update_count()
		data = {"operation": 2, "username": username}
		check = requests.post(url=RADR, json=data, headers=headers)
		c_json = check.json()

		if c_json["Error"] == "user does not exist":
			# no user, bad request
			return {}, 400
		else:
			resp = requests.post(url=WRADR, json=data, headers=headers)
			if resp.json()["Error"] == "":
				# delete successful
				return {}, 200
	else:
		return method_not_allowed()


# @application.route("/api/v1/users", methods=["DELETE", "GET", "POST", "PUT"])
# def list_users():
# 	if request.method == "GET":
# 		update_count()
# 		data = {"operation":10}
# 		resp = requests.post(url=RADR, json=data, headers=headers)
# 		r_json=resp.json()
# 		if r_json["userList"] == []:
# 			return jsonify([]),204
# 		else:
# 			return jsonify(r_json["userList"]),200
# 	else:
# 		return method_not_allowed()


@application.route("/api/v1/db/clear", methods=["DELETE", "GET", "POST", "PUT"])
def clear_db():
	if request.method == "POST":
		update_count()
		db.drop_all()
		db.create_all()
		return {}, 200
	else:
		return method_not_allowed()


@application.route("/api/v1/_count", methods=["DELETE", "GET", "POST", "PUT"])
def count_requests_and_reset_request():
	if request.method == "GET":
		#return {"msg":"hi"},200
		with open("count.txt") as c:
			request_count = json.load(c)["count"]
		return str("[ " + str(request_count)+" ]"), 200
	elif request.method == "DELETE":
		with open("count.txt", "w") as c:
			request_count = 0
			json.dump({"count": request_count}, c)
		return {}, 200
	else:
		return method_not_allowed()


# @application.route("/api/v1/_count", methods=["DELETE", "GET", "POST", "PUT"])
# def reset_requests():
# 	if request.methos == "DELETE":
# 		with open("count.txt", "w") as c:
# 			request_count = 0
# 			json.dump({"count": request_count}, c)
# 		return {}, 200
# 	else:
# 		return method_not_allowed()


def update_count():
	with open("count.txt", "r+") as c:
		request_count = json.load(c)["count"]
		request_count += 1
		c.seek(0)
		c.truncate()
		json.dump({"count": request_count}, c)

@application.route("/")
def index():
	return jsonify("<h4>Hello user World</h4>")

def method_not_allowed():
	update_count()
	return {}, 405

if __name__ == "__main__":
	db.create_all()
	try:
		a = open("count.txt")
		a.close()
	except:
		with open("count.txt", "w") as c:
			request_count = 0
			json.dump({"count": request_count}, c)
	application.run(debug=True,host='0.0.0.0',port=int(PORT[1:]))



