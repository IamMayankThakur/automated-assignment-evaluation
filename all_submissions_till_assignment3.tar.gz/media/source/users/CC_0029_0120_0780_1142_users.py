#!/usr/bin/env python3


import sys
import os


from gevent import monkey
monkey.patch_all()


import requests
import flask
from threading import Lock
from gevent.pywsgi import WSGIServer


app = flask.Flask(__name__)
usersdb_host = os.environ['USERSDB_HOST']
ridesdb_host = os.environ['RIDESDB_HOST']
n_requests = 0
n_requests_lock = Lock()


def increment_requests():

    global n_requests

    n_requests_lock.acquire()
    try:
        n_requests += 1
    finally:
        n_requests_lock.release()


@app.before_request
def before_request():

    non_increment_paths = ('/', '/api/v1/_count', '/api/v1/db/clear')
    verify_origin_paths = ('/api/v1/users')

    inc_flag = True

    if flask.request.path in non_increment_paths:
        inc_flag = False
    elif flask.request.path in verify_origin_paths:
        if 'Origin' in flask.request.headers:
            inc_flag = True

    if inc_flag:
        increment_requests()


@app.route('/', methods=['GET'])
def index():

    return flask.jsonify({}), 200


def passwd_isValid(passwd):

    if len(passwd) != 40:
        return False

    for c in passwd.lower():
        if not c.isdigit():
            if c not in 'abcdef':
                return False

    return True


# API 1: Add user
# API 10: List all users
@app.route('/api/v1/users', methods=['GET', 'PUT'])
def addUserandListAllUsers():

    try:

        if flask.request.method == 'PUT':

            user = flask.request.get_json()

            print('PUT:', user)

            username = user['username']
            password = user['password']

            json = {
                'table': 'users',
                'where': 'username=' + username
            }

            resp = requests.post(usersdb_host + '/api/v1/db/read', json=json)
            if resp.status_code == 200:
                exists = True
            elif resp.status_code == 204:
                exists = False
            else:
                raise ValueError('bad request')

            if exists:
                raise ValueError('username already exists')

            if not passwd_isValid(password):
                raise ValueError('invalid password')

            json = {
                "operation": "insert",
                "table": "users",
                "ins_doc": user
            }

            resp = requests.post(usersdb_host + '/api/v1/db/write', json=json)

            return flask.jsonify(dict()), 201

        elif flask.request.method == 'GET':

            json = {
                'table': 'users'
            }

            resp = requests.post(usersdb_host + '/api/v1/db/read', json=json)
            if resp.status_code == 200:
                temp = resp.json()
                resp_data = [None for i in range(len(temp))]
                for i, user_id_hex in enumerate(temp):
                    tmp_json = temp[user_id_hex]
                    try:
                        username = tmp_json['username']
                    except KeyError as e:
                        continue
                    resp_data[i] = username
                resp_data = list(filter(lambda x: x is not None,
                                        resp_data))
                return flask.jsonify(resp_data), 200
            elif resp.status_code == 204:
                return flask.Response(status=204)
            else:
                raise ValueError('bad request')


    except (ValueError, KeyError, TypeError) as e:
        flask.abort(flask.Response(response=str(e), status=400))

    finally:
        pass


# API 2: Remove user
@app.route('/api/v1/users/<username>', methods=['DELETE'])
def delUser(username):

    try:

        print('DELETE:', username)

        json = {
            'table': 'users',
            'where': 'username=' + username
        }

        resp = requests.post(usersdb_host + '/api/v1/db/read', json=json)
        if resp.status_code == 200:
            exists = True
        elif resp.status_code == 204:
            exists = False
        else:
            raise ValueError('bad request')

        if not exists:
            raise ValueError('delete failed - no user deleted')

        # delete the user
        json = {
            'operation': 'delete',
            'table': 'users',
            'where': 'username=' + username
        }

        resp = requests.post(usersdb_host + '/api/v1/db/write', json=json)
        if resp.status_code != 200:
            raise ValueError('delete failed')

        # remove the user from all the rides they are a part of
        json = {
            'operation': 'update',
            'table': 'rides',
            'update_op': {'$pull': {'users': username}}
        }

        resp = requests.post(ridesdb_host + '/api/v1/db/write', json=json)
        if resp.status_code != 200:
            raise ValueError('delete failed')

        # delete all rides created by the user
        json = {
            'operation': 'delete',
            'table': 'rides',
            'where': 'created_by=' + username
        }

        resp = requests.post(ridesdb_host + '/api/v1/db/write', json=json)
        if resp.status_code != 200:
            raise ValueError('delete failed')

        return flask.jsonify(dict()), 200

    except (ValueError, KeyError, TypeError) as e:
        flask.abort(flask.Response(response=str(e), status=400))

    finally:
        pass


@app.route('/api/v1/db/clear', methods=['POST'])
def DBClear():

    try:

        resp = requests.post(usersdb_host + '/api/v1/db/clear',
                             json=flask.request.get_json())
        if resp.status_code == 200:
            return flask.jsonify({}), 200
        else:
            raise ValueError('clear failed')

    except (ValueError, KeyError, TypeError) as e:
        flask.abort(flask.Response(response=str(e), status=400))

    finally:
        pass


@app.route('/api/v1/_count', methods=['GET', 'DELETE'])
def RequestCount():

    global n_requests

    try:

        if flask.request.method == 'GET':

            n_requests_lock.acquire()
            try:
                return flask.jsonify([n_requests]), 200
            finally:
                n_requests_lock.release()

        else:  # DELETE

            n_requests_lock.acquire()
            try:
                n_requests = 0
                return flask.jsonify({}), 200
            finally:
                n_requests_lock.release()

    except (ValueError, KeyError, TypeError) as e:
        flask.abort(flask.Response(response=str(e), status=400))

    finally:
        pass


if __name__ == '__main__':
    server_type = 'debug'
    server_port = 1101
    if len(sys.argv) >= 2:
        if sys.argv[1] in ('debug', 'deploy'):
            server_type = sys.argv[1]
        else:
            print('Usage: ./<filename> [debug [port]|deploy [port]]')

        if len(sys.argv) == 3:
            server_port = int(sys.argv[2])

    if server_type == 'debug':
        app.run(debug=True, host='0.0.0.0', port=server_port)
    else:
        app.debug = True
        http_server = WSGIServer(('', server_port), app)
        http_server.serve_forever()
