from flask import * 
from flask import request
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import *
from sqlalchemy import exc
from datetime import datetime
import requests

app = Flask(__name__) 
app.config['JSON_SORT_KEYS'] = False

app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///user.db'
 
db = SQLAlchemy(app)

class User(db.Model):
	__tablename__ = 'User'
	name = db.Column(db.String(50), primary_key = True)
	password = db.Column(db.String(40))

class ReqTable1(db.Model):
	__tablename__ = 'ReqTable1'
	rowid = db.Column(db.Integer, primary_key = True, autoincrement=True)
	content = db.Column(db.String(50))

db.create_all()

def is_hex(val):
	try:
		a = int(val,16)
		return 1
	except:
		return 0

def increment():
	mydata = {"table":"ReqTable1","insert": ["test"]}
	r = requests.post("http://127.0.0.1:5000/api/v1/db/write",json=mydata)


@app.errorhandler(405)
def method_not_allowed(e):
        increment()
        return jsonify(error=str(e)),405

@app.route("/api/v1/_count",methods=["GET"])
def http_req():
	query= "SELECT COUNT(*) from ReqTable1"
	mydata = {"query":query}
	r = requests.post("http://127.0.0.1:5000/api/v1/db/read",json=mydata)
	res = json.loads(r.text)
	count = res[0]["COUNT(*)"]
	l = [count]
	return jsonify(l),200

@app.route("/api/v1/_count",methods=["DELETE"])
def http_req_del():
	query= "DELETE from ReqTable1"
	mydata = {"query":query}
	r = requests.post("http://127.0.0.1:5000/api/v1/db/read",json=mydata)
	res = json.loads(r.text)
	return "200",200

### API 1 ###
@app.route("/api/v1/users",methods=["PUT"])
def add_user():
	increment()
	usr = request.get_json()["username"]
	pas = request.get_json()["password"]
	if(len(pas)!=40 or (is_hex(pas) != 1)):
		return Response("Password must be SHA1 hash hex only",status = 400,mimetype='application/text')
	else:
		mydata = {"table":"User","insert":[usr,pas]}
		r = requests.post("http://127.0.0.1:5000/api/v1/db/write",json=mydata)
		res = r.text
		if res=='201':
			return Response("Added user successfully",status = 201,mimetype='application/text')
		elif res=='400':
			return Response("Username taken already",status = 400,mimetype='application/text')
		elif res=='500':
			return Response("Internal server errror",status = 500,mimetype='application/text')

### API 2 ###
@app.route("/api/v1/users/<username>",methods=["DELETE"])
def del_user(username):
	increment()
	query = "SELECT COUNT(*) from User where name = '"+username+"'"
	mydata = {"query":query}
	r = requests.post("http://127.0.0.1:5000/api/v1/db/read",json=mydata)
	res = json.loads(r.text)
	count = res[0]["COUNT(*)"]
	if count==0:
		return Response("User does not exist",status = 400,mimetype='application/text')
	else:
		query = "DELETE from User where name = '"+username+"'"
		mydata = {"query":query}
		r = requests.post("http://127.0.0.1:5000/api/v1/db/read",json=mydata)
		res = r.text
		if res=="200":
			return Response("User deleted successfully",status = 200,mimetype='application/text')
		else:
			return Response("Internal server error",status = 500,mimetype='application/text')

### API 3 ###
@app.route("/api/v1/users",methods=["GET"])
def get_user():
	increment()
	query = "SELECT name from User "
	mydata = {"query":query}
	r = requests.post("http://127.0.0.1:5000/api/v1/db/read",json=mydata)
	res = json.loads(r.text)
	l = []
	for i in res:
			name = i["name"]
			l.append(name)
	return jsonify(l),200

	
### API 8 ###
@app.route("/api/v1/db/write",methods=["POST"])
def write_db():
	tbl = request.get_json()["table"]
	data = request.get_json()["insert"]
	if (tbl == "User"):
		try:
			user = User(name=data[0], password=data[1])
			db.session.add(user)
			db.session.commit()
			return '201'
		except exc.IntegrityError as e:
			db.session().rollback()
			return '400'
		except:
			return '500'
	elif (tbl == "ReqTable1"):
		try:
			row = ReqTable1(content=data[0])
			db.session.add(row)
			db.session.commit()
			return '201'
		except exc.IntegrityError as e:
			db.session().rollback()
			return '400'
		except:
			return '500'

### API 9 ###
@app.route("/api/v1/db/read",methods=["POST"])
def read_db():
	query = request.get_json()["query"]
	res = {}
	engine = create_engine('sqlite:///user.db')
	connection = engine.connect()
	if "DELETE" in query:
		connection.execute(query)
		return "200"
	else:
		result = connection.execute(query)
		res = [dict(x) for x in result]
		return jsonify(res)

### clearDB API ###
@app.route("/api/v1/db/clear",methods=["POST"])
def clear_db():
	#increment()
	engine = create_engine('sqlite:///user.db')
	connection = engine.connect()
	query = "DELETE FROM User"
	connection.execute(query)
	return "200"

@app.route('/',methods=["GET"])
def adduser():
	return jsonify("in docker2")

if(__name__=="__main__"):
    app.run(host="0.0.0.0", debug=True)
