from flask import Flask, render_template,jsonify,request,abort,url_for,Response
import re
import psycopg2
import requests
import json
import datetime
from waitress import serve
#ip = "http://52.72.15.183"
api_count = 0
pg_ip = "52.72.15.183"
ip = "http://localhost"
#ride_ip = "http://52.72.15.183:8000"
ride_ip = "http://3.230.61.99:80"
locations = {}
#print("Am I actually going insane?", flush=True)
def testdate(timestamp):
	halves = timestamp.split(":")
	if len(halves)!=2:
		return False
	datepart = halves[0].split("-")
	if len(datepart)!=3:
		return False
	day = datepart[0]
	month = datepart[1]
	year = datepart[2]
	timepart = halves[1].split("-")
	if len(timepart)!=3:
		return False
	sec = timepart[0]
	mins = timepart[1]
	hr = timepart[2]
	try:
		datetime.datetime(int(year),int(month),int(day),int(hr),int(mins), int(sec))
	except:
		return False
	return True

def makedt(timestamp):
	halves = timestamp.split(":")
	datepart = halves[0].split("-")
	timepart = halves[1].split("-")
	day = int(datepart[0])
	month = int(datepart[1])
	year = int(datepart[2])
	sec = int(timepart[0])
	mins = int(timepart[1])
	hr = int(timepart[2])
	return datetime.datetime(year,month,day,hr,mins,sec)

with open("AreaNameEnum.csv") as f:
	lines = f.readlines()
	lines = lines[1:]
	for l in lines:
		line = l.split(",")
		locations[int(line[0])] = line[1].rstrip("\r").rstrip("\n")

app=Flask(__name__)

@app.route('/')
def health():
	return Response('{}', status=200)

@app.route('/api/v1/users', methods=['GET','PUT',"POST","DELETE"])
def adduser():
	#print("Method requested:", request.method, flush=True)
	global api_count
	api_count +=1
	if request.method == 'PUT':
		data = request.json
		print("data:", data)
		pattern = re.compile(r'\b[0-9a-f]{40}\b')
		prepost = str(data)
		match = re.match(pattern, data['password'])
		print("Add user method evoked")
		r = requests.post(ip + "/api/v1/db/read",json={"table":"users","username":data["username"]})
		r = r.json()
		l = len(r['username'])
		if(match != None)  and (l == 0):
			r = requests.post(ip + "/api/v1/db/write",json={"table":"user","operation":"insert","username":data["username"],"password":data["password"]})
			return Response("{}",status=201)
		return 	Response("{}",status=400)
	elif request.method == "GET":
		try:
			r = requests.post(ip + "/api/v1/db/read",json={"table":"users"})
			r = r.json()
			l = r["username"]
			length = len(l)
			if length == 0:
				return Response("{}", status = 204)
			return Response(json.dumps(l),status = 200)
		except:
			return Response("{}",status=400)

	else:
		return Response("{done:yes}", status=405)
	print("ENd of ThIng!>!", flush=True)

@app.route('/api/v1/users/<username>',  methods=['GET','PUT',"POST","DELETE"])
def removeuser(username):
	global api_count
	api_count +=1
	if request.method == 'DELETE':
		r = requests.post(ip + "/api/v1/db/read",json={"table":"users","username":username})
		r = r.json()
		l = len(r["username"])
		if(l != 0):
			r = requests.post(ip + "/api/v1/db/write",json = {"table":"user","operation":"delete","username":username})
			r2 = requests.post(ride_ip + "/api/v1/db/write", json = {"table":"both","operation":"delete","username":username})
			return Response('{}',status = 200)
		return Response("{}",status=400)
	else:
		return Response("{}", status=405)

'''
@app.route('/api/v1/users')
def listuser():
	global api_count
	api_count +=1
	if request.method == "GET":
		try:
			r = requests.post(ip + "/api/v1/db/read",json={"table":"users"})
			r = r.json()
			l = r["username"]
			length = len(l)
			if length == 0:
				return Response("{}", status = 204)
			return Response(json.dumps(l),status = 200)
		except:
			return Response("{}",status=400)
	else:
		return Response("{}", status=405)

'''

@app.route('/api/v1/db/clear', methods=['GET','PUT',"POST","DELETE"])
def clear():
	if request.method == "POST":
		try:
			connection = psycopg2.connect(user = "postgres",password = "password",host = pg_ip,port = "5432",database = "rideshare")
			cursor = connection.cursor()
			query = "DELETE FROM users;"
			cursor.execute(query)
			connection.commit()
			requests.post(ride_ip+"/api/v1/db/clear")
			return Response("{}",status=200)
		except:
			return Response("{}",status=400)
	else:
		return Response("{}", status=405)



@app.route('/api/v1/db/write', methods=['GET','PUT',"POST","DELETE"])
def writedb():
	if request.method == "POST":
		data = request.json
		prepost = "NoConn"
		connection = psycopg2.connect(user = "postgres",password = "password",host = pg_ip ,port = "5432",database = "rideshare")
		prepost = "Conned"
		cursor = connection.cursor()
		if(data["operation"] == "insert"):
			if(data["table"] == "user"):
				query = "INSERT INTO users(userid,password) VALUES('" +data["username"]+ "','"+data["password"]+"');"
			
		if(data["operation"] == "delete"):
			if(data["table"] == "user"):
				query = "DELETE FROM users where userid = '" +data["username"]+ "';"
			
		cursor.execute(query)
		connection.commit()
		return Response("{}",status=200)
	else:
		return Response("{}", status=405)


@app.route('/api/v1/_count', methods=["GET"])
def request_count():
	global api_count
	return Response(json.dumps([api_count]),status="200")

@app.route('/api/v1/_count',methods=["DELETE"])
def reset_count():
	global api_count
	api_count = 0
	return Response("{}", status="200")


@app.route('/api/v1/db/read', methods=["POST"])
def readdb():
	data = request.json
	connection = psycopg2.connect(user = "postgres",password ="password",host = pg_ip ,port = "5432",database = "rideshare")
	cursor = connection.cursor()
	output = {}
	try:
		kw = data["username"]
		query = "SELECT * from users WHERE userid = '"+kw+"';"
	except KeyError:
		query = "SELECT userid from  users"
	if(data["table"] == "users"):
		#query = "SELECT * FROM users WHERE userid = '" +data["username"]+ "';"
		output["username"] = []
		cursor.execute(query)
		result = cursor.fetchall()
		for i in range(len(result)):
			output["username"].append(result[i][0])
	return jsonify(output)
	
if __name__ == '__main__':
	serve(app, host = "0.0.0.0", port = 80)
	#print("THE APP HAS ATLEAST STARTED OK")
	#app.run(host="0.0.0.0",port=80)
