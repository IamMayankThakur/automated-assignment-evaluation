from flask import Flask, render_template,\
jsonify,request,abort, Response
import json
import string, logging
import psycopg2
import pandas
import requests
from datetime import datetime

def make_connection():
	#connection =-1
	try:
	    connection = psycopg2.connect(user = "postgres",
	                                  password = "postgres",
	                                  host = "users_db",
	                                  port = "5432",
	                                  database = "cc_a1")
	    print("DEBUG: ", connection)
	    cursor = connection.cursor()

	except (Exception, psycopg2.Error) as error :
	    print ("Error while connecting to PostgreSQL", error)
	    abort(405)
	finally:
		return connection

app=Flask(__name__)
#total_req = 0
def create_tables():
	con = make_connection()
	cur = con.cursor()
	cur.execute("CREATE TABLE IF NOT EXISTS users(username varchar PRIMARY KEY NOT NULL, password varchar(40));")
	con.commit()
	cur.close()
	con.close()

def checkSHA(pwd):
	if(len(pwd)!=40 or not(all(c in string.hexdigits for c in pwd))):
		#print(pwd)
		return False
	else:
		return True
def locExists(num):
	colnames = ['AreaNo', 'AreaName']
	data = pandas.read_csv('AreaNameEnum.csv', names=colnames)
	areas = data.AreaNo.tolist()
	if(num not in areas):
		return 0
	else:
		return 1
def update_count():
	f = open("total_req", "r")
	req_count= f.read()
	req_count= int(req_count.strip())
	req_count+=1
	f.close()
	w = open("total_req", "w")
	w.write(str(req_count))
	w.close()

@app.route("/api/v1/users", methods=["PUT"])
def add_user():
	update_count()
	create_tables()
	created = 201
	username = request.get_json()["username"]
	pwd = request.get_json()["password"]
	#print("Username = ", username)
	#print("pwd = ", pwd)
	
	if(username==''):
		abort(400)

	elif(not(checkSHA(pwd))):
		abort(405)

	else:
		print("Checkpoint1")
		#Create new request to insert
		insert_request = {"insert": [username,pwd], "table": "users"}
		print(insert_request)
		read_req = {"table": "users", "where" :"username='"+username+"'"}
		resp = requests.post(url ="http://users:80/api/v1/db/read", json = read_req)
		resp = resp.text
		resp = json.loads(resp)
		#Checking if user exists or not
		if(len(resp)!=0):
			print("User already exists")
			abort(400)

		#inserting new user
		insert(insert_request)
		print(request.get_json())
		return Response({},status=201)

@app.route("/api/v1/users/<name>", methods=["DELETE"])
def del_user(name):
	update_count()
	create_tables()
	username = str(name)

	#terminate operation if username doesn't exist
	if(username==''):
		abort(400)

	else:
		#First check if specified user exists or not
		read_req = {"table": "users", "where" :"username='"+username+"'"}
		resp = requests.post(url ="http://users:80/api/v1/db/read", json = read_req)
		resp = resp.text
		resp = json.loads(resp)

		if(len(resp)==0):
			print("Can't delete user because he doesnt exist")
			abort(400)
		else:
			try:
				del_user = "DELETE FROM users WHERE username = %s"
				connection = make_connection()
				cursor2 = connection.cursor()
				cursor2.execute(del_user, (username,))
				connection.commit()
				cursor2.close()
				connection.close()
				return '',200
			except (Exception, psycopg2.Error) as error:
				print("Error in Delete operation", error)
				abort(405) #not sure about this

@app.route("/api/v1/users", methods=["GET"])
def user_listing():
	update_count()
	create_tables()
	user_clause = {"table": "users", "where":"'1'='1'"}
	print("Before calling read API")
	ulisting = requests.post(url ="http://users:80/api/v1/db/read", json = user_clause)
	ulisting = ulisting.text
	ulisting = json.loads(ulisting)
	print("DEBUG1", ulisting)
	if (len(ulisting)==0):
               return jsonify([]),204
	newlist = [str(i[0]) for i in ulisting]
	#print(newlist)
	return jsonify(newlist)

@app.route("/api/v1/_count", methods=["GET"])
def req_count():
	f = open("total_req", "r")
	req_count= f.read()
	req_count = int(req_count.strip())
	f.close()
	l=[]
	l.append(req_count)
	return jsonify(l),200
@app.route("/api/v1/_count", methods=["DELETE"])
def reset_count():
	w = open("total_req", "w")
	w.write('0')
	w.close()
	return '',200

@app.route("/api/v1/db/write", methods=["POST"])
def insert(req):
	create_tables()
	table= req["table"]
	connection = make_connection()
	cursor = connection.cursor()
	try:
		if(table == "users"):
			username = req["insert"][0]
			pwd = req["insert"][1]
			print(username,pwd)
			insert_user = "INSERT INTO users (username, password) VALUES (%s,%s)"
			record = (username, pwd)
			cursor.execute(insert_user, record)
			connection.commit()

			#Logging message
			count = cursor.rowcount
			print (count, "Record inserted successfully into users table")

		else:
			abort(405)

	except(Exception, psycopg2.Error) as error:
		if(connection):
			print("Failed to insert record", error)
			abort(405)
	finally:
		if(connection and cursor):
			cursor.close()
			connection.close()	



@app.route("/api/v1/db/read", methods=["POST"])
def read():
	create_tables()
	req = request.get_json()
	connection = make_connection()
	cursor = connection.cursor()
	try:
		table= req["table"]
		ret = -1
		where = req["where"]
		q = "SELECT * FROM "+ table+" WHERE " + where
		cursor.execute(q)
		rec = cursor.fetchall()
		cursor.close()
		connection.close()
		print("table = ", table,"Rec: ",rec)
		if(len(rec)==0):
			print("Record Doesn't exist")
			return jsonify([])
		else:
			return jsonify(rec)

	except(Exception, psycopg2.Error) as error:
		if(connection):
			print("Failed to read record", error)
			abort(405)
	finally:
		if(connection and cursor):
			cursor.close()
			connection.close()
	return '',405
@app.route("/api/v1/db/clear", methods=["POST"])
def clear_db():
	create_tables()
	try:
		del1 = "DELETE FROM users"
		#del2 = "DELETE FROM rides"
		#del3 = "DELETE FROM user_ride"
		connection = make_connection()
		cursor3 = connection.cursor()
		cursor3.execute(del1)
		connection.commit()

		cursor3.close()
		connection.close()
		return '',200
	except (Exception, psycopg2.Error) as error:
		print("Error in Delete operation", error)
		return 405

if __name__ == '__main__':
	app.run(host='0.0.0.0', debug=True, port=80)
	#app.run()