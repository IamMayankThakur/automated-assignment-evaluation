from flask import Flask, Request, jsonify,request ,  Response,json , url_for
from collections import defaultdict
import csv
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm.attributes import flag_modified
#from sqlalchemy.types import *
from flask_marshmallow import Marshmallow
from sqlalchemy import PickleType
#import os
#from crud import *
import datetime
import requests
#import tldextract
import re
from datetime import datetime
from datetime import date
app = Flask(__name__)
#basedir = os.path.abspath(os.path.dirname(__file__))
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///CC_0024_0162_1618_1640_app.sqlite'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
dab = SQLAlchemy(app)
ma = Marshmallow(app)
from multiprocessing import Value
counter = Value("i",0)

class User(dab.Model):
    #id = dab.Column(dab.Integer, primary_key=True)
    username = dab.Column(dab.String(),primary_key=True)
    password = dab.Column(dab.String())

    def __init__(self, username, password):
        self.username = username
        self.password = password

class UserSchema(ma.Schema):
    class Meta:
        # Fields to expose
        fields = ('username', 'password')


user_schema = UserSchema()

dab.create_all()


@app.route("/api/v1/users" ,methods=["PUT"])
def add_user():
    with counter.get_lock():
        counter.value+=1
    dic = {}
    dictt={}
    dictt["some"] = "adduser"
    dictt['username'] = request.json['username']
    url="http://3.221.196.147:80/api/v1/db/read"
    #data = {'username':"gagana","password":"dskjf85u6i"}
    headers = {'Content-type': 'application/json', 'Accept': 'text/plain'}
    r = requests.post(url, json = dictt, headers=headers)
    #return r.text
    password = request.json['password']
    pattren = re.compile('^[0-9a-f]{40}$')
    matches = pattren.match(password)
    if r.text != "None":
        return jsonify({}),400
    if not re.match(pattren,password):
        return jsonify({}),400
    else:
        dic["username"] = request.json['username']
        dic["password"] = request.json['password']
        username = request.json['username']
        dic["some"] = "user"
        url="http://3.221.196.147:80/api/v1/db/write"
        #data = {'username':"gagana","password":"dskjf85u6i"}
        headers = {'Content-type': 'application/json', 'Accept': 'text/plain'}
        r = requests.post(url, json = dic, headers=headers)
        return jsonify({}),201



@app.route("/api/v1/users/<username>", methods=["DELETE"])
def user_delete(username):
    with counter.get_lock():
        counter.value+=1
    dictt={}
    dictt["some"] = "deluser"
    dictt['username'] = username
    url="http://3.221.196.147:80/api/v1/db/read"
    request.headers = {'Content-type': 'application/json', 'Accept': 'text/plain'}
    r = requests.post(url, json = dictt, headers=request.headers)
    if r.text=="None":
        return jsonify({}),400
    else:
        url="http://3.221.196.147:80/api/v1/db/write"
        headers = {'Content-type': 'application/json', 'Accept': 'text/plain'}
        res = requests.post(url, json = dictt, headers=headers)
        return jsonify({}),200


@app.route("/api/v1/users",methods=["GET"] )
def get_users():
    with counter.get_lock():
        counter.value+=1
    #return str(request.headers.get('Origin'))
    dic={}
    dic['some']="get_user"
    url="http://3.221.196.147:80/api/v1/db/read"
    headers = {'Content-type': 'application/json', 'Accept': 'text/plain'}
    r = requests.post(url,json = dic ,headers = headers)
    if (r.text=="[]"):
        return jsonify({}),204
    else:
        return r.text

@app.route("/api/v1/db/write", methods=["POST"])
def write_dab():
    content = ""
    #ext = tldextract.extract("http://3.221.196.147:80/user")
    if (request.json['some'] == "user"):
        content = request.json
        username = content["username"]
        password = content["password"]
        new_user = User(username, password)
        dab.session.add(new_user)
        dab.session.commit()
        return content
    
    elif (request.json['some'] == 'deluser'):
        content = request.json
        username = content['username']
        user=User.query.get(username)
        dab.session.delete(user)
        dab.session.commit()
        return user_schema.jsonify(user)
    
        
@app.route('/api/v1/db/read',methods=['POST'])
def read_dab():
    content = ''

    if request.json['some'] == 'adduser':
        content = request.json
        username = content['username']
        user=User.query.get(username)
       # return user_schema.jsonify(user)
        return str(user)                      

    elif(request.json['some'] == 'get_user'):
        lis=[]
        users=User.query.all()
        for user in users:
            lis.append(user.username)
        return str(lis)
    elif(request.json['some'] == 'deluser'):
        content = request.json
        username = content['username']
        user=User.query.get(username)
        return str(user)  


@app.route("/api/v1/db/clear",methods=["POST"])
def clear_db():
    with counter.get_lock():
        counter.value+=1
    '''meta = dab.metadata
    for table in reversed(meta.sorted_tables):
        dab.session.execute(table.delete())
    dab.session.commit()
    return jsonify({}),200'''
    users=User.query.all()
    for user in users:
        dab.session.delete(user)
        dab.session.commit()
    return jsonify({}),200
    
        
        
@app.route("/api/v1/_count",methods=['GET'])
def get_count():
    li = []
    li.append(counter.value)
    return str(li)

@app.route("/api/v1/_count",methods=['DELETE'])
def reset_count():
    counter.value=0
    return jsonify({}),200            
            
if __name__ == '__main__':
    app.run(host="0.0.0.0",port=80,debug=True)


