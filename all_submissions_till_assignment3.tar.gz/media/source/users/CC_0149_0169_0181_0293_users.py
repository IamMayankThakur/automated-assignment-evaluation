import os
import time
import json
import requests
import re
import csv
import logging
from flask import Flask, request, jsonify, redirect, url_for, Response
from pymongo import MongoClient
from random import randint
from datetime import datetime
from flask_cors import CORS, cross_origin

app = Flask(__name__)
cors = CORS(app)
app.config['CORS_HEADERS'] = 'Content-Type'

username = os.environ.get("MONGO_INITDB_ROOT_USERNAME")
password = os.environ.get("MONGO_INITDB_ROOT_PASSWORD")
client = MongoClient(
    "mongodb://mongodb:27017",
    username=username,
    password=password
)
db = client.testdb

def db_api(key, database, collection, mode):
    key_string = json.dumps(key)
    if database == "rides":
        if mode == "read":
            json_string = {'query' : key_string, 'database' : database, 'collection' : collection}
            jstring = json.dumps(json_string)
            r = requests.post("http://52.86.121.173/api/v1/db/read/", json=jstring)
            return r
        else:
            json_string = {'query' : key_string, 'database' : database, 'collection' : collection, "mode" : mode}
            jstring = json.dumps(json_string)
            r = requests.post("http://52.86.121.173/api/v1/db/write/", json=jstring)
            return r
    elif database == "count":
        if mode == "read":
            json_string = {'query' : key_string, 'database' : database, 'collection' : collection}
            jstring = json.dumps(json_string)
            r = requests.post("http://18.210.167.1/api/v1/db/read/", json=jstring)
            return r
        else:
            json_string = {'query' : key_string, 'database' : database, 'collection' : collection, "mode" : mode}
            jstring = json.dumps(json_string)
            r = requests.post("http://18.210.167.1/api/v1/db/write/", json=jstring)
            return r
    else:
        if mode == "read":
            json_string = {'query' : key_string, 'database' : database, 'collection' : collection}
            jstring = json.dumps(json_string)
            r = requests.post("http://18.210.167.1/api/v1/db/read/", json=jstring)
            return r
        else:
            json_string = {'query' : key_string, 'database' : database, 'collection' : collection, "mode" : mode}
            jstring = json.dumps(json_string)
            r = requests.post("http://18.210.167.1/api/v1/db/write/", json=jstring)
            return r

def count2_ini():
    dbnames = client.list_database_names()
    mydb2 = client["count2"]
    #mycol2 = mydb2["count2"]
    ###print("hmmm")
    ###print(dbnames)
    if 'count2' not in dbnames:
        cn = client.count2.count2.count_documents({})
        ###print(cn,"pppppppppppppppppppppppppppppppppppp")
        if cn == 0:
            db_api({'name':'count2','count2':'0'},"count2","count2","insert")
            return "201"
    return "400"


def req_count2():
    count2_ini()
    r = db_api({'name': 'count2'},"count2","count2","read")
    try:
        count2 = int(r.text)
    except:
        count2 = 0
    count2 += 1
    r2 = db_api({'count2' : str(count2)},"count2","count2","update")
    return "200"
    
@app.route("/api/v1/users/", methods=['POST'])
def add_user_to_ride_fallback1():
    req_count2()
    return Response("", status="405", mimetype="application/json")
#Function to create new users.      
@app.route("/api/v1/users/", methods=['PUT'])
def create_user():
    req_count2()
    try:
        try:
            username = request.json["username"]
            password = request.json["password"]
        except:
            return Response("", status="400", mimetype="application/json")

        u = db_api({'username':username},"users","users","read")
        ###print(str(u))
        if u.text == "400":
            if len(password) == 40 and re.match("([a-f0-9]{40})", password):
                insert = {'username' : username, 'password' : password}
                try:
                    r = db_api(insert,"users","users","insert")
                    ##print(str(r.text))
                    if r.json():
                        return Response("{}", status="201", mimetype="application/json")
                    else:
                        return Response("", status="500", mimetype="application/json")
                except:
                    return Response("", status="500", mimetype="application/json")

            else:
                return Response("", status="400", mimetype="application/json")
        
        else:
            return Response("", status="400", mimetype="application/json")
        
    except:
        return Response("", status="500", mimetype="application/json")

#Function to list all users.#200 204 405
@app.route("/api/v1/users", methods=['GET'])
def list_all_users():
    req_count2()
    try:
        try:
            u = db_api({},"users","users","read")
            #app.logger.debug(str(u))
            ####print(u.text)
        except Exception as e:
            return Response("", status="500", mimetype="application/json")
        #return u.content
        ####print(str(u.content).rstrip('\n'), file=sys.stderr)
        if len(u.json()) == 0:
            return Response("", status="204", mimetype="application/json")

        return Response(u, status="200", mimetype="application/json")
    except Exception as err:
        return Response("", status="500", mimetype="application/json")

@app.route("/api/v1/users/<username>", methods=['PUT','GET','HEAD','POST','CONNECT','OPTIONS','TRACE','PATCH'])
def add_user_to_ride_fallback3(rideId):
    req_count2()
    return Response("", status="405", mimetype="application/json")
#Function to delete users.
@app.route("/api/v1/users/<username>", methods=['DELETE'])
def delete_user(username):
    req_count2()
    try:
        u = db_api({'username':username},"users","users","read")

        if u.text == "400":
            return Response("Username does not exist", status="400", mimetype="application/json")
 
        else:
            delete = {'username' : username}
            try:
                ur = db_api({"created_by":username},"rides","rides","read")
                if ur.text == "400":
                    r = db_api(delete,"users","users","update")
                    if r.text == "200":
                        return Response("{}", status="200", mimetype="application/json")
                    else:
                        return Response("", status="500", mimetype="application/json")
                else:
                    return Response("this user cannot be deleted as he is associated with a ride", status="400", mimetype="application/json")
            except Exception as e:
                return Response("", status="500", mimetype="application/json")
        
    except Exception as e:
        return Response("", status="500", mimetype="application/json")

#Function to write to the DB.
@app.route("/api/v1/db/write/", methods=['POST'])
def write_db():
    r_db = client.rides
    r_col = r_db.rides
    ridesIdcol = r_db.id

    u_db = client.users
    u_col = u_db.users

    c_db = client.count2
    c_count2 = c_db.count2

    try:
    #if 1:
        try:
            ins = request.json
            insert_data = json.loads(ins)

            query = json.loads(insert_data["query"])
            collection = insert_data["collection"]
            database = insert_data["database"]
            mode = insert_data["mode"]

        except:
            return Response("", status="400", mimetype="application/json")
        #print(mode, database)
        if mode == "insert":
            if database == "rides":
                if collection == "rides":
                    ride_id = r_col.insert(query)
                    find = r_col.find_one({'_id' : ride_id})
                    output = {'created_by' : find['created_by'], 'rideId' : find['rideId'], 'users' : find['users'], 'timestamp' : find['timestamp'], 'source' : find['source'], 'destination' : find['destination']}
                    return jsonify({'result' : output})

                else:
                    if collection == "id":
                        i = ridesIdcol.find_one({'name': 'rideId'})
                        if i:
                            return "200"
                        else:
                            ridesIdcol.insert(query)
                            return "200"
            
            elif database == "users":
                ###print("hi+++++++++++++++++++++++++++++++++++++++++++++++")
                user_id = u_col.insert(query)
                ###print(user_id)
                return "200"
            
            elif database == "count2":
                count2_id = c_count2.insert(query)
                ####print(count2_id)
                return "201"

        elif mode == "update":
            #print("hi1")
            if database == "rides":
                #print("hi2")
                if collection == "rides":
                    ur = r_col.find_one({'rideId':query['rideId']})
                    if query['username'] in ur['users']:
                        return "400"
                    r_col.find_one_and_update({'rideId' : query['rideId']},{"$push": {"users": query['username']}})
                    return Response("", status="200", mimetype="application/json")
                
                else:
                    ridesIdcol.find_one_and_update({'name': 'rideId'},{"$set": {"rideId": str(query['rideId'])}})
                    return "201"

            elif database == "users":
                #print("hi3")
                #print("khfs la")
                u_col.find_one_and_delete({'username' : query['username']})
                return "200"

            elif database == "count2":
                #print("hi4")
                c_count2.find_one_and_update({'name': 'count2'},{"$set": {"count2": str(query['count2'])}})
                return "201"    

            else:
                r_col.find_one_and_delete({'rideId' : query['rideId']})
                return "200"      
    except Exception as e:
        return Response("Service Unavailable", status="500", mimetype="application/json")

#Function to read from the DB.
@app.route("/api/v1/db/read/", methods=['POST'])
def read_db():
    r_db = client.rides
    r_col = r_db.rides
    ridesIdcol = r_db.id

    u_db = client.users
    u_col = u_db.users

    c_db = client.count2
    c_count2 = c_db.count2

    #try:
    if 1:
        try:
            read = request.json
            read_data = json.loads(read)

            query = json.loads(read_data['query'])
            collection = read_data["collection"]
            database = read_data["database"]

        except:
            return "400"

        if database == "rides":
            if collection == "rides":
                if 'rideId' in query:
                    find = r_col.find_one(query)
                    if find:
                        output = {'created_by' : find['created_by'], 'rideId' : find['rideId'], 'users' : find['users'], 'timestamp' : find['timestamp'], 'source' : find['source'], 'destination' : find['destination']}
                        output['timestamp'] = datetime.fromtimestamp(output['timestamp']).strftime("%d-%m-%Y:%S-%M-%H")
                        return jsonify(output)
                    else:
                        return "400"
                else:
                    ride = list(r_col.find(query))
                    output = []
                    for r in ride:
                        out = {"rideId":r['rideId'], "timestamp":r['timestamp'], "created_by":r['created_by']}
                        output.append(out)
                    if output:
                        for r_ in output: r_['timestamp'] = datetime.fromtimestamp(r_['timestamp']).strftime("%d-%m-%Y:%S-%M-%H")
                        return jsonify(output)
                    else:
                        return "400"

            elif collection == "id":
                    
                find = ridesIdcol.find_one(query)
                if find:
                    return find['rideId']
                else:
                    return "400"
            
        elif database == "users":
            if query:
                find = u_col.find_one(query)
                if find:
                    output = {'username' : find['username'], 'password' : find['password']}
                    return jsonify(output)
                else:
                    return "400"        
            else:
                find = u_col.find(query)
                output = []
                if find:
                    for i in find:
                        ####print(i)
                        out = i['username']
                        output.append(out)
                    return jsonify(output)
                return "400"  

        elif database == "count2":
            find = c_count2.find_one()
            ##print(find['count2'])
            if find:
                ##print("lol")
                return find['count2']
            else:
                return "400"
        
    #except Exception as ert:
        ###print(str(ert))
     #   return Response("", status="500", mimetype="application/json")

#Function to clear the DB.#200 400 405
@app.route("/api/v1/db/clear", methods=['POST'])
def drop_users_db():
    try:
        client.drop_database("users")
        return Response("{}", status="200", mimetype="application/json")
    except:
        return Response("", status="400", mimetype="application/json")


@app.route("/api/v1/_count", methods=['GET'])
def get_count2():
    try:
        count2_ini()
        r = db_api({'name': 'count2'},"count2","count2","read")
        ####print(r.text)
        try:
            r = int(r.text)
        except:
            r = 0
    except Exception as e:
        return Response("", status="400", mimetype="application/json")

    r = "["+str(r)+"]"

    return Response(r, status="200", mimetype="application/json")


@app.route("/api/v1/_count", methods=['DELETE'])
def clear_count2():
    try:
        count2_ini()
        r = db_api({'count2' : "0"},"count2","count2","update")
    except:
        return Response("", status="400", mimetype="application/json")

    return Response("", status="200", mimetype="application/json")

#@app.before_first_request
#def before_first_request_func():
#    ##print("[Init]")

if __name__ == "__main__":
    app.run(host="0.0.0.0", debug=True, port=80)
else:
    gunicorn_logger = logging.getLogger('gunicorn.error')
    app.logger.handlers = gunicorn_logger.handlers
    app.logger.setLevel(gunicorn_logger.level)
    app.logger.debug('this will show in the log')


