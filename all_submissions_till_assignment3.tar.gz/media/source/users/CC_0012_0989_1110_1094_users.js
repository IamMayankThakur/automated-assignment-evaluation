//server.js
// Dependencies
const express = require('express');
const apiV1 = require('./routes/v1');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
require('dotenv/config');

// Initializing the server
const server = express();

// connecting to mongoDB
mongoose.connect(process.env.DB_CONNECTION,{
    useNewUrlParser: true,
    useUnifiedTopology: true,
    useCreateIndex : true,
    useFindAndModify : false
});

// configuring the server
server.use(bodyParser.urlencoded({extended: false}));
server.use(bodyParser.json());

// to handle CORS
server.use((req,res,next) => {
    res.header('Access-Control-Allow-Origin','*');
    res.header('Access-Control-Allow-Headers','Origin, X-Requested-With, Content-Type, Accept, Authorization');
    if(req.method === 'OPTIONS'){
        res.header('Acces-Control-Allow-Methods', 'POST, GET, PUT, DELETE');
        return res.status(200).json({})
    }
    next();
});

// setting the middleware to route the requests
server.use('/api/v1',apiV1);

// handling bad paths/errors
server.use((req,res,next) => {
    res.status(405).json({});
});

server.use((error, req,res,next) => {
    res.status(error.status || 500);
    res.json({});
});

// Listening on port 8080
server.listen(80,function(){
    console.log('Listening on port 80...');
});

//routes/v1.js
// dependencies
const express = require('express');
const usersHandler = require('./users')
const dbHandler = require('./db')
const countHandler = require('./count');
const fs = require('fs');

// variables
const api = express();
const pathToFile = '/app/users/data/counts.json';

// to route user requests
api.use('/users',async (req,res,next) =>{
    var counts = JSON.parse(fs.readFileSync(pathToFile));
    counts.count += 1;
    fs.writeFileSync(pathToFile,JSON.stringify(counts));
    next();
},usersHandler);

// to route db operations
api.use('/db',dbHandler);

// to return count
api.use('/_count',countHandler);

// to handle unknown paths and errors
api.use((req, res, next) => {
    res.status(405).json({});
})

// export
module.exports = api;


//routes/users.js
// dependencies
const express = require('express');
const helper = require('../helper');
const request = require('request-promise');
require('dotenv/config');

//variables
const router = express.Router();
const localhost = process.env.LOCALHOST;
const lPort = process.env.L_PORT;

// setting routes
// 1. Add user
router.put('/', async (req, res, next) => {
    // get the data from request body
    const username = req.body.username;
    const password = req.body.password;
    console.log('Entered put request');

    // check if password is SHA1
    if (password == null || !helper.validPass(password)) {
        console.log('Invalid password');
        res.status(400).json({});
    }
    else {
        console.log('passed password check');

        // check if user exists
        var body = {
            table: 'user',
            where: {
                username: username
            }
        };
        var options = {
            url: localhost + ':' + lPort + '/api/v1/db/read',
            body: JSON.stringify(body),
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            }
        };

        try {
            var response = await request.post(options);
            console.log('first response');
            response = JSON.parse(response);
            res.status(400).json({});
        } catch{
            body = {
                action: 1,
                table: 'user',
                values: [username, password]
            };
            options = {
                url: localhost + ':' + lPort + '/api/v1/db/write',
                method: 'POST',
                body: JSON.stringify(body),
                headers: {
                    'Content-Type': 'application/json'
                }
            };

            response = await request.post(options);
            console.log('after write');
            console.log(response);
            response = JSON.parse(response);
            const statusCode = response.statusCode;

            res.status(statusCode).json({});
        }



    }


});

// 2.Remove user
router.delete('/:username', async (req, res, next) => {
    const username = req.params.username;
    console.log('in delete');
    /*try{
        var response = await request.post({
            url : serverName + '/api/v1/db/read',
            body : JSON.stringify({
                table : 'ride',
                action : 2,
                where : {
                    created_by : username
                }
            }), 
            headers: {
                'Content-Type': 'application/json'
            }
        });
        response = JSON.parse(response);
        console.log(response);
        if(response.length > 0){
            console.log('sending response');
            res.status(400).json({});
            return;
        }
    }catch(err){
        console.log(err);
    }*/
    

    var body = {
        table: 'user',
        action : 2,
        where: {
            username: username
        }
    };
    var options = {
        url: localhost + ':' + lPort + '/api/v1/db/write',
        body: JSON.stringify(body),
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        }
    };

    try{
        var response = JSON.parse(await request.post(options));
        console.log('delete response');
        console.log(response);
        res.status(response.statusCode).json({});
    } catch(error){
        console.log(error);
        res.status(400).json({});
    }
});

// List all users
router.get('/', async (req,res,next) => {
    try{
        console.log("Sending get details");
        var body = {
            table : 'user',
            action : 0
        };
        var options = {
            url: localhost + ':' + lPort + '/api/v1/db/read',	
            method: 'POST',
            body : JSON.stringify(body),
            headers: {
                'Content-Type': 'application/json'
            }
        };
        var response = await request.post(options);
        response = JSON.parse(response);
        console.log(response);
        if(response.length > 0){
            var result = [];
            for(var i=0;i<response.length;i++){
                console.log(response[i]);
                result.push(response[i]['username']);
            }
            console.log(result);
            res.status(200).json(result);
        }else{
            res.status(200).json([]);
        }        
        return;
    }
    catch{
        res.status(204).json(response);
    }
});

router.use((req,res,next) => {
    res.status(405).json({});
});

// export the router
module.exports = router

//routes/db.js
// dependencies
const express = require('express');
const User = require('../models/user');

// variables
const router = express.Router();

// 8. Write to db
router.post('/write', async (req, res, next) => {
    /*console.log('db/write called');
    res.status(200).json({
        something : 'something'
    });*/
    const action = req.body.action;
    const table = req.body.table;

    // if action is 1 create
    if (action == 1) {
        if (table === 'user') {
            const user = new User({
                username: req.body.values[0],
                password: req.body.values[1],
                rides: req.body.values[2]
            });
            console.log(user);
            try {
                const savedUser = await user.save();
                console.log(savedUser);
                res.json({
                    statusCode: 201
                });
            } catch (err) {
                console.log('Inside db');
                console.log(err);
                res.json({
                    statusCode: 500
                });
            }

        }
    } else if (action == 2) {
        if (table === 'user') {
            try {
                //const username = req.body.where.username;
                //var response = await Ride.updateMany({users : username}, {$pull : {users : username}});
                //console.log('Update response');
                //console.log(response);
                var response = await User.deleteOne(req.body.where);
                console.log('delete response');
                console.log(response); 
                if(response.deletedCount > 0){
                    res.status(200).json({
                        statusCode : 200
                    });
                }  else{
                    res.status(200).json({
                        statusCode : 400
                    });
                }             
                
            } catch (err) {
                console.log('Inside action 2 user db');
                console.log(err);
                res.status(400).json({
                    statusCode : 400
                });
            }
        }
    } 
});

// 9. Read from db
router.post('/read', async (req, res, next) => {

    const table = req.body.table;
    const action = req.body.action;
    
    console.log('Entered read db');
    console.log(table);
    console.log(action);
    if (table === "user") {
        console.log('Reading db');
        if(action == 0){
            try{
                var result = await User.find({}).select('username -_id');
                console.log(result);
                res.status(200).json(result);
                return;
            }
            catch{
                res.status(200).json({});
                return;
            }            
        }
        try {
            var result = await User.findOne(req.body.where);
            console.log(result);
            console.log(result.username);
            res.status(200).json({
                statusCode: 200
            });
        } catch (err) {
            console.log('Inside db');
            console.log(err);
            res.status(400).json({
                statusCode : 400
            });
        }
    }
});

router.post('/clear',async (req,res,next) => {
    console.log("Clearing db");
    try{
        var result = await User.remove({});
        res.status(200).json({});
        console.log("success");
    }
    catch{
        res.status(400).json({});
        console.log("Failure");
    }
});

router.use((req,res,next) => {
    res.status(405).json({});
});

//
module.exports = router;


//count.js
// dependencies
const express = require('express');
const fs = require('fs');

//variables
const router = express.Router();
const pathToFile = '/app/users/data/counts.json';

// api to return count
router.get('/',async (req,res,next) => {
    try{
        const counts = JSON.parse(fs.readFileSync(pathToFile));
        res.status(200).json([counts.count]);

    }catch{
        console.log("Error reading file");
    }
});

// to reset count
router.delete('/', async (req,res) => {
    var counts = JSON.parse(fs.readFileSync(pathToFile));
    counts.count = 0;
    fs.writeFileSync(pathToFile,JSON.stringify(counts));
    res.status(200).json({});
});

// voiding bad requests
router.all('/', (req,res,next) => {
    res.status(405).json({});
});


// export the router
module.exports = router