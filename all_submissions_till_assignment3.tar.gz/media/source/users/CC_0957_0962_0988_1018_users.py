from flask import Flask,render_template,jsonify,request,abort
from flask_sqlalchemy import SQLAlchemy
import re
import requests
import datetime
from multiprocessing import Value

app=Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI']='sqlite:///users.db'
db=SQLAlchemy(app)
class User(db.Model):
    username=db.Column(db.String(200),nullable=False,primary_key=True)
    password=db.Column(db.String(40),nullable=False)
db.create_all()
counter = 0

@app.route("/api/v1/_count",methods=["GET","DELETE"])
def count():
    if request.method=="GET":
        global counter
        temp=list()
        temp.append(counter)
        return jsonify(temp),200
    elif request.method=="DELETE":
        counter=0
        return {},200
    else:
        abort(405)

#databse write operation
@app.route("/api/v1/db/write",methods=["POST"])
def write():
    data=request.get_json()["insert"]
    column=request.get_json()["column"]
    table=request.get_json()["table"]
    data1=[]
    for i in data:
        if type(i) is str:
            print(type(i))
            data1.append("\'"+i+"\'")
        else:
            data1.append(str(i))
    #data=list(map(lambda x:'\''+x+'\'' if isinstance(x,str),data))	#inserting single qoute '' to data
    column=",".join(column)	#combining column with join
    data1=",".join(data1)#combining data with join
    try:
    	qry="insert into "+table+"("+column+") values("+data1+");"
    	db.session.execute(qry)
    	db.session.commit()
    	return {}
    except Exception as e:
    	print(e)
    	abort(400)

@app.route("/api/v1/db/read",methods=["POST","DELETE"])
def read():
    if request.method=="POST":	#to read from data
        a={}
        table=request.get_json()["table"]
        column=request.get_json()["columns"]
        where=request.get_json()["where"]
        column=",".join(column)
        qry="select "+column+" from "+table+ " where "+where+ ";"
        print(qry)
        try:
            result=db.session.execute(qry)
            count=0
            for i in result:
                a[count]=list(i)
                count+=1
            return jsonify(a)
        except Exception as e:
            print(e)
            abort(400)
    elif request.method=="DELETE":	#to delete from table
        table=request.get_json()["table"]
        where=request.get_json()["where"]
        qry="delete from "+table+" where "+where+";"       
        try:
            db.session.execute(qry)
            db.session.commit()
            return {}
        except Exception as e:
            print(e)
            abort(400)

#1st task inserting user to the table
@app.route("/api/v1/users",methods=["PUT","GET","POST","DELETE"])
def addUser():
    global counter
    counter+=1
    if request.method=="PUT":
        try:
            username=request.get_json()["username"]
            password=request.get_json()["password"]
            crrt=re.search("[0-9|a-f|A-F]{40}",password)
            if(crrt and len(password)==40):
                #Check whether the user is present in the table
                    a={"insert":[username,password],"column":["username","password"],"table":"user"} #making json format
                    resp=requests.post("http://18.209.219.230/api/v1/db/write",json=a)    #send post request to database url  to wite to database
                    #resp.status_code, .json()
                    if resp.status_code==200:       #resp.json() gives passed json
                        return {},201
                    elif resp.status_code==400:
                        return {},400
            else:
                abort(resp.status_code)
        except Exception as e:
            print(e)
            abort(400)
    elif request.method=="GET":
        a={"table":"user","columns":["username"],"where":"username like '%'"}
        resp1=requests.post("http://18.209.219.230/api/v1/db/read",json=a)
        users=resp1.json()
        if(len(users)<=0):
            return {},204
        else:
            users=list(users.values())
            act_user=list()
            for i in users:
                act_user.append(i[0])
            return jsonify(act_user),200
    else:
        abort(405)

@app.route("/api/v1/users/<username>",methods=["PUT","GET","POST","DELETE"])
def removeUser(username):
    global counter
    counter+=1
    if request.method=="DELETE":
	    a={"table":"user","columns":["username"],"where":"username='"+username+"'"}
	    b={"table":"ride","columns":["rideId"],"where":"created_by='"+username+"'"}
	    c={"table":"participant","columns":["rideId","username"],"where":"username='"+username+"'"}
	    resp1=requests.post("http://18.209.219.230/api/v1/db/read",json=a)
	    resp2=requests.post("http://50.17.167.22/api/v1/db/read",json=b)
	    resp3=requests.post("http://50.17.167.22/api/v1/db/read",json=c)
	    if((len(resp1.json())>0)and(len(resp2.json())>0)and(len(resp3.json())>0)):	#if exist delete
	        resp1=requests.delete("http://18.209.219.230/api/v1/db/read",json=a)
	        resp2=requests.delete("http://50.17.167.22/api/v1/db/read",json=b)
	        resp3=requests.delete("http://50.17.167.22/api/v1/db/read",json=c)
	        if resp1.status_code==200:
	            if resp2.status_code==200:
	                if resp3.status_code==200:
	           # b={"table":"participant","columns":["username"],"where":"username='"+username+"'"}
	            #resp1=requests.delete("http://18.209.219.230/api/v1/db/read",json=b)
	            #if resp1.status_code==200:
	                    return {}
	                else:
	                    abort(resp3.status_code)
	            else:
	                abort(resp2.status_code)        
	            #else:
	               # {},400
	        else:
	            abort(resp1.status_code)
	    else:
	    	abort(400)
    else:
        abort(405)    
        

@app.route("/api/v1/db/clear",methods=["POST"])
def userclear():
    if(request.method!="POST"):
        abort(405)
    else:
        a={"table":"user","columns":["username"],"where":"username like '%'"}
        resp1=requests.delete("http://18.209.219.230/api/v1/db/read",json=a)
        resp3=requests.post("http://50.17.167.22/api/v1/db/clear")

        if((resp1.status_code==200)and(resp3.status_code==200)):
            return {},200
        else:
            abort(400)

if __name__=="__main__":
      app.debug=True #one parameter ip and  port
      app.run(host="0.0.0.0",port=8000)