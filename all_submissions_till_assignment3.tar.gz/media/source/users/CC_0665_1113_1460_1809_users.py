from flask import Flask ,render_template,abort,request,jsonify
from flask_sqlalchemy import SQLAlchemy
import requests
import json
import re
from datetime import datetime
from constants import *

app = Flask(__name__)
app.config['SQLALCHEMY_TRACK_MODIFICATIONS']=False
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///db.sqllite3'
db = SQLAlchemy(app)
count=0
class ride(db.Model):
        id=db.Column(db.Integer, primary_key=True)
        created_by=db.Column(db.String(120),  nullable=False)
        timestamp=db.Column(db.String(120),  nullable=False)
        source=db.Column(db.String(120),  nullable=False)
        destination=db.Column(db.String(120),  nullable=False)
        def __init__(self,created_by,timestamp,source,destination):
                #self.id=id
                self.created_by=created_by
                self.source=source
                self.timestamp=timestamp
                self.destination=destination
        def __repr__(self):
                return '<ride %r>' % self.id
class share(db.Model):
        id=db.Column(db.Integer, primary_key=True)
        username=db.Column(db.String(80), primary_key=True)
        
        def __init__(self,id,username):
                self.id=id
                self.username=username
        def __repr__(self):
                return '<share %r>' % self.id

class User(db.Model):
    #id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(40), primary_key=True)
    password = db.Column(db.String(120), nullable=False)
    def __init__(self,username,password):
       self.username=username
       self.password=password
                
    def __repr__(self):
        return '%r' % self.username
		

@app.route('/api/v1/_count',methods=["GET","DELETE"])
def total_number_of_requests():
	global count
	if(request.method=="GET"):
		bl=list()
		bl.append(count)
		return jsonify(bl),200
	elif(request.method=="DELETE"):
		count=0
		return jsonify({}),200

		
@app.route('/api/v1/users',methods=["GET"])
def get_users():
	global count
	count=count+1
	usercheck=requests.post('http://127.0.0.1:80/api/v1/db/read',json={"table":"User"})
	y=json.loads(usercheck.text)
	print(y["1"])
	for i in range(len(y["1"])):
            #print(i)
            y["1"][i]=y["1"][i][1:len(y["1"][i])-1]
	print("one",y["1"])
	if(not y["1"]):
		return jsonify({}),204
	print("two",y["1"])
	return jsonify(y["1"]),200

@app.route('/api/v1/db/clear',methods=["POST"])
def clear_db():
	#global count
	#count=count+1
	User.query.delete()
	#share.query.delete()
	#ride.query.delete()
	
	#db.session.add(a)
	db.session.commit()
	return jsonify({}),200
	
	
@app.route('/api/v1/users',methods=["PUT"])
def add_user():
                #check how to get input from put
                #take username check if it is unique
                #take password check if it is SHA1
                #write to the database
        global count				
        count=count+1
        if(request.method!="PUT"):
            return jsonify({}),405
        username =request.json["username"]

        password =request.json["password"]
        pattern = re.compile(r'\b[0-9a-f]{40}\b')
        match = re.match(pattern,password)
        #print(match)
        #match.group(0)
        if(match==None):
            return jsonify({}),400
        usercheck=requests.post('http://127.0.0.1:80/api/v1/db/write',json={"table":"User","operation":"insert","values":[username,password]})
        #print(usercheck)
        #print("hepol")
        if(usercheck.status_code==201):
            return jsonify({}),201
        else:
            return jsonify({}),400
        
        
        
        
                
                
@app.route('/api/v1/users/<username>',methods=["DELETE"])
def remove_user(username):
                #got the username
                #check if it exists in database
                #then delete
        global count				
        count=count+1
        if(request.method!="DELETE"):
            return jsonify({}),405
        usercheck=requests.post('http://127.0.0.1:80/api/v1/db/read',json={"table":"User"})
        y=json.loads(usercheck.text)
        for i in range(len(y["1"])):
            #print(i)
            y["1"][i]=y["1"][i][1:len(y["1"][i])-1]
            #print(y["1"])
        #print(username)
        if(username not in y["1"]):
            print("hello")
            return jsonify({}),400
        crossride=requests.post('http://rides:80/api/v1/db/read',json={"table":"ride"})
        
        d=json.loads(crossride.text)
        print("the request to ride ",d,"end")
        for i in range(len(d["created_by"])):
            #print(i)
            d["created_by"][i]=d["created_by"][i][0:len(d["created_by"][i])]
            #print(y["1"])
        if(username in d["created_by"]):
            print("hello")
            return jsonify({}),400
        print("here")
        remuser=requests.post('http://127.0.0.1:80/api/v1/db/write',json={"table":"User","operation":"delete","values":[username]})
        print("hello")
        if(remuser.status_code==201):
            #checking to remove the share users if a created user is deleted
            remshare=requests.post('http://lb1-1143063392.us-east-1.elb.amazonaws.com:80/api/v1/db/read',json={"table":"share"})
            print("done")
            x=json.loads(remshare.text)
            print("bla",x)
            for i in range(len(x["username"])):
                #print(i)
                x["username"][i]=x["username"][i][2:len(x["username"][i])-1]

                shadel=requests.post('http://lb1-1143063392.us-east-1.elb.amazonaws.com:80/api/v1/db/write',json={"table":"share1","operation":"delete","values":[username]})
                print("check")
                if(shadel.status_code==200):
                    return jsonify({}),200
                else:
                    return jsonify({}),400
            
        else:
            return jsonify({}),400
        return jsonify({}),200
            
        
    
@app.route('/api/v1/db/read',methods=["POST"])
def readd():
        
        
        table_name=request.json["table"]
        #columns=request.json["columns"]
        #where=request.json["where"]

        if(table_name=='User'):
            #print("hellllllo\n")
            out=db.session.query(User).all()
            nm=list()
            for i in out:
                nm.append(str(i))
            #valdict[nm]=ps
            #for i in out:
                #valdict[str(i)]=str(i.password)
                #print(i)
            #print(valdict)
            return json.dumps({'1':nm}),200
        elif(table_name=='ride'):
            out=db.session.query(ride).all()
            
            rd=dict()
            rd={"rideid":[],"created_by":[],"users":[],"timestamp":[],"source":[],"destination":[]}
            for i in out:
                rd["rideid"].append(i.id)
                rd["created_by"].append(i.created_by)
                #rd["users"].append(i.users)
                rd["timestamp"].append(i.timestamp)
                rd["source"].append(i.source)
                rd["destination"].append(i.destination)
            return json.dumps(rd),200
            
        elif(table_name=='share'):
            out=db.session.query(share).all()
            rd=dict()
            rd={"id":[],"username":[]}
            for i in out:
                rd["id"].append(i.id)
                rd["username"].append(i.username)
            return json.dumps(rd),200
                
                
                
        elif(table_name=='share'):
                        out=db.session.query(share).all()
            
                    
        return ""
    
        #table_name.query.filter_by(username='peter').all()
        #request_books.append((book_name,author))
        #return  str(table_name)+str(columns)+str(where)
    
        
        
@app.route('/api/v1/db/write',methods=["POST"])
def write():
        #operation,table,values
    operation=request.json["operation"]
    values=request.json["values"]
    table=request.json["table"]
    try:
        if(operation=="insert"):
                if(table=="User"):
                    a=User(username=values[0],password=values[1])
                    db.session.add(a)
                    db.session.commit()
                elif(table=="ride"):
                    b=ride(created_by=values[0],timestamp=values[1],source=values[2],destination=values[3])
                    db.session.add(b)
                    db.session.commit()
                elif(table=="share"):
                    c=share(id=values[0],username=values[1])
                    db.session.add(c)
                    db.session.commit()
        elif(operation=="delete"):
                if(table=="User"):
                    #a=User(username=values[0])
                    User.query.filter(User.username==values[0]).delete()
                    #db.session.add(a)
                    db.session.commit()
                    return "done",201
                elif(table=="ride"):
                    ride.query.filter(ride.id==values[0]).delete()
                    db.session.commit()
                    return "done",200
                elif(table=="share"):
                    share.query.filter(share.id==values[0]).delete()
                    db.session.commit()
                    return "done",200
                elif(table=="share1"):
                    share.query.filter(share.username==values[0]).delete()
                    db.session.commit()
                    return "done",200
    
                    
                                        

                    
        
        
        return "done",201
    except:
        return "user already exists",400
                        
                        
                        
        #user=User()
        #db.session.add(user)
        #db.session.commit()
        
        #return 
@app.errorhandler(405)
def not_found(error):
	print("bla")
	print(request.method)
	print(type(request.path))
	if(request.path=='/api/v1/db/clear' or request.path=='/api/v1/_count'):
		print("yos")
	else:
		global count
		count=count+1
	return jsonify({}),405

if __name__ == '__main__': 
	db.create_all()
	app.debug = True
	app.run(host='0.0.0.0',port=80)
        
                

  
                
