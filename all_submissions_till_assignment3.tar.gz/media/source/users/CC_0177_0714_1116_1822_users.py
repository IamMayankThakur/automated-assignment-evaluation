from flask import *
import csv
import re
import string
import requests
#from flask_api import status  
import sqlite3
import datetime  
app = Flask(__name__)
global index_add_counter
index_add_counter = 0
def db(i):
	if i==0:
		con = sqlite3.connect("assign.db")
		con.execute("create table User (uid INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL, password TEXT NOT NULL)")
		print("Table created successfully")
		con.close()

#1st api
@app.route("/api/v1/users",methods=["PUT","GET","POST","DELETE"])
def inex():
	global index_add_counter
	index_add_counter=index_add_counter+1
	if(request.method=="PUT"):
		user=request.get_json()["username"]
		pas=request.get_json()["password"]
		pas=pas.lower()
		params1 = {
			"table":"User",
			"columns":"username",
			"where":""
		}
		if(user==""):
			return make_response("Usename cant be empty",400,{"Content-type":"application/json"})
		try:
			r = requests.post("http://localhost:5000/api/v1/db/read",json=params1)  
		except:
			return make_response("Service not available",500,{"Content-type":"application/json"})		
		user_name_enter=(r.text).split("\n")
		for i in user_name_enter:
			if(i.strip(",")==str(user)):
				return make_response("Usename already exist",400,{"Content-type":"application/json"})
		params = {
			"insert":str(user)+","+str(pas),
			"column":"username,password",
			"table":"User"
		}
		if(len(pas)!=40):
			return make_response("Password not in correct format",400,{"Content-type":"application/json"})
		if(all(c in string.hexdigits for c in pas)==False):
			return make_response("Password not in correct format",400,{"Content-type":"application/json"})
		try:
			r = requests.post("http://localhost:5000/api/v1/db/write",json=params)
		except:
			return make_response("Service not available",500,{"Content-type":"application/json"})
		return make_response("{}",201,{"Content-type":"application/json"})
	elif request.method=="GET":
		params = {
			"table":"User",
			"columns":"username",
			"where":""
		}
		r = requests.post("http://localhost:5000/api/v1/db/read",json=params)  
		return jsonify(r.text),200
	else:
		return {},405
#2nd api
@app.route("/api/v1/users/<usernam>",methods=["DELETE","PUT","GET","POST"])
def delete(usernam): 
	global index_add_counter
	index_add_counter=index_add_counter+1
	if(request.method=="DELETE"):  
		cur = con.cursor()
		params1 = {
		"table":"User",
		"columns":"username",
		"where_part":"1",
		"where":"username=",
		"condition":usernam
	}
		r = requests.post("http://localhost:5000/api/v1/db/read",json=params1)  
		user_name_enter=(r.text).split("\n")
		flag=0
		for i in user_name_enter:
			if(i.strip(",")==str(usernam)):
				flag=1
		if(flag==0):
			return make_response("Usename not exist",405,{"Content-type":"application/json"})
		parm = {
		"table":"Ride",
		"columns":"*",
		"where_part":"1",
		"condition":usernam,
		"where":"user1="
		}
		r = requests.post("http://172.17.0.1:8000/api/v1/db/read",json=parm)
		if(r.text.strip()!=""):
			abort(400,"User exists in a ride cant be deleted")
		parm["where"]="user2="
		r = requests.post("http://172.17.0.1:8000/api/v1/db/read",json=parm)
		if(r.text.strip()!=""):
			abort(400,"User exists in a ride cant be deleted")
		parm["where"]="user3="
		r = requests.post("http://172.17.0.1:8000/api/v1/db/read",json=parm)
		if(r.text.strip()!=""):
			abort(400,"User exists in a ride cant be deleted")
		parm["where"]="user3="
		r = requests.post("http://172.17.0.1:8000/api/v1/db/read",json=parm)
		if(r.text.strip()!=""):
			abort(400,"User exists in a ride cant be deleted") 
		param = {
		"table":"Ride",
		"columns":"*",
		"where":""
		}
		params = {
					"delete":"1",
					"where":usernam,
					"table":"User"
				}
		r = requests.post("http://localhost:5000/api/v1/db/write",json=params)
		return make_response("{}",200,{"Content-type":"application/json"})
	else:
		return {},405
#3rd api

#api number 8 complete ....works only for our database ....
@app.route("/api/v1/db/write",methods=["POST"])
def write_to_db():
	#cur.execute("INSERT into User (username, password) values (?,?)",(user,pas)) 
	delete = "NULL"
	data = "NULL"
	column1 = "NULL"
	table = "NULL"
	WHERE = "NULL"
	update = "NULL"
	SET = "NULL"
	user = "NULL"
	try:#if the instruction is an update 
		update = request.get_json()["update"]
		table = request.get_json()["table"]
		SET = request.get_json()["set"]
		user = request.get_json()["user"]
		WHERE = request.get_json()["where"]
	except:
		pass
	try:#if the instruction is a delete
		delete = request.get_json()["delete"]
		WHERE = request.get_json()["where"]
		table = request.get_json()["table"]
	except:
		pass
	try:#if the instruction is a insert
		data = request.get_json()["insert"]
		column1 = request.get_json()["column"]
		table = request.get_json()["table"]
	except:
		pass
	if(update!="NULL"):
		sql = "UPDATE "+table+" SET "+SET+" ? WHERE "+WHERE
		with sqlite3.connect("assign.db") as con:
				cur = con.cursor()
				cur.execute(sql,(user,))
				con.commit()
				return "update over"
	if(delete!="NULL"):
		if(table=="User"):
			sql = "DELETE from User WHERE username=?"
			with sqlite3.connect("assign.db") as con:
				cur = con.cursor()
				cur.execute(sql,(WHERE,))
				con.commit()
				return "{}"
		if(table=="Ride"):
			sql = "DELETE from Ride WHERE ride_id=?"
			with sqlite3.connect("assign.db") as con:
				cur = con.cursor()
				cur.execute(sql,(WHERE,))
				con.commit()
				return "{}"
	else:
		with sqlite3.connect("assign.db") as con:
			data1 = data.split(",")
			if(table=="Ride"):
				sql = "INSERT into "+str(table)+" ("+str(column1)+") values (?,?,?,?,?,?,?,?,?)"
			if(table=="User"):
				sql = "INSERT into "+str(table)+" ("+str(column1)+") values (?,?)"
			cur = con.cursor()
			cur.execute(sql,([d for d in data1]))
			con.commit()
			return "{}"
#api number 9 complete
@app.route("/api/v1/db/read",methods=["POST"])
def read_db():

	where_part = "NULL"
	condition = "NULL"
	try:
		where_part = request.get_json()["where_part"]
		condition = request.get_json()["condition"]
		table = request.get_json()["table"]
		columns =request.get_json()["columns"]
		where = request.get_json()["where"]
	except:
		pass
	if(where_part!="NULL"):
		sql_query = "SELECT "+columns+" from "+table+" WHERE "+where+" ?"
		with sqlite3.connect("assign.db") as con:
			con.row_factory = sqlite3.Row
			cur = con.cursor()
			cur.execute(sql_query,(condition,))
			rows = cur.fetchall()
			s= ""
			for row in rows:
				for r in row:
					s = s+str(r)+","
				s = s+"\n"
			return s
	else:
		table = request.get_json()["table"]
		columns =request.get_json()["columns"]
		where = request.get_json()["where"]
		sql_query = "SELECT "+columns+" from "+table+" "+where
		with sqlite3.connect("assign.db") as con:
			con.row_factory = sqlite3.Row
			cur = con.cursor()
			cur.execute(sql_query)
			rows = cur.fetchall()
			s= ""
			for row in rows:
				for r in row:
					s = s+str(r)+","
				s = s+"\n"
			return s



#HTTP count and reset api's
@app.route("/api/v1/_count",methods=["GET","PUT","POST","DELETE"])
def count():
        global index_add_counter
        if request.method=="GET":
                l=[]
                l.append(index_add_counter)
                return jsonify(l),200
        elif request.method=="DELETE":
                index_add_counter=0
                return {},200
        else:
                return {},405



@app.route("/api/v1/db/clear",methods=["POST"])
def clear():
	sql_query = "DELETE FROM User"
	with sqlite3.connect("assign.db") as con:
		con.row_factory = sqlite3.Row
		cur = con.cursor()
		cur.execute(sql_query)
		con.commit()
	return {}
i=0
if __name__ == "__main__":
	try:
		db(i)
	except Exception as e:
		pass
	#app.run(debug = True)
	app.run(host="0.0.0.0",debug=True)
