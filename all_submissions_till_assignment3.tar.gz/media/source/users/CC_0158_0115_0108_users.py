from flask import Flask, jsonify, request, abort
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import text
from sqlalchemy.exc import IntegrityError
from models import app, db, Rides, User
import requests
from datetime import datetime
import logging

# CC_0158_0115_0108
# 52.44.239.51

user_ip = "0.0.0.0:5000"
ride_ip = "3.214.178.180"
load_balancer_dns = "microload-1543347202.us-east-1.elb.amazonaws.com"

def get_count():
    with open('count_file', 'r') as f:
        count = int(f.read().strip())
    return count

def increment_count():
    count = get_count()
    with open('count_file', 'w') as f:
        f.write(str(count+1))

def reset_count():
    with open('count_file', 'w') as f:
        f.write('0')

headers = {"Origin": "microload-1543347202.us-east-1.elb.amazonaws.com"}

# API 1
# Add user
@app.route("/api/v1/users", methods=['PUT'])
def add_user():
    increment_count()
    if(request.method!='PUT'):
        abort(405)
    req_params = request.get_json()
    if req_params == None:
        abort(400)
    username=req_params["username"]
    password=req_params["password"]
    try:
        hexp=int(password,16)
        if(len(password)!=40):
            abort(400)
        query={"insert":[username,password],"table":"user","columns":["username","password"]}
        x=requests.post("http://" + user_ip + "/api/v1/db/write",json=query)
        x1=requests.post("http://" + ride_ip + "/api/v1/db/write",json=query)
        if x.status_code != 200:
            abort(400)
        return("",201)
    except ValueError as e:
        abort(400)

# API 2
# Remove user
@app.route("/api/v1/users/<username>", methods=['DELETE'])
def delete_user(username):
    increment_count()
    if(request.method!='DELETE'):
        abort(405)
    check_user = requests.get("http://" + load_balancer_dns + "/api/v1/users")
    if username not in check_user.json():
        abort(400)
    query={"where":["username={}".format(username)],"table":"user"}
    x=requests.delete("http://" + user_ip + "/api/v1/db/write",json=query)
    x_1=requests.delete("http://" + ride_ip + "/api/v1/db/write",json=query)
    return (jsonify(),200)

# API 8
# Write to db
@app.route("/api/v1/db/write", methods = ['POST', 'DELETE'])
def write_db():
    req_params = request.get_json()
    try:
        if request.method == 'POST':
            columns = ",".join(req_params["columns"])
            table = req_params["table"].lower()
            values = req_params["insert"]
            for index in range(len(values)):
                if not values[index].isnumeric():
                    values[index] = "'{}'".format(values[index])
            values = ",".join(values)
            query = "INSERT INTO {} ({}) VALUES ({});".format(table, columns, values)
            print(query)
            query_result = db.engine.execute(text(query))

        elif request.method == 'DELETE':
            table = req_params["table"].lower()
            where = req_params["where"]
            if len(where) == 0:
                query = "DELETE FROM {};".format(table)
            else:
                for index in range(len(where)):
                    split_cond = where[index].split("=")
                    if not split_cond[1].isnumeric():
                        split_cond[1] = "'{}'".format(split_cond[1])
                    where[index] = '='.join(split_cond)
                where = " and ".join(where)
                query = "DELETE FROM {} WHERE {};".format(table, where)
            print(query)
            query_result = db.engine.execute(text(query))
            return ('Success', 200)
        return ('Success', 200)

    except IntegrityError as e:
        print(e)
        return ('Duplicate Error', 400)

    except Exception as e:
        print(e)
        return ('Query Error', 400)

# API 9
# Read from db
@app.route("/api/v1/db/read", methods = ['POST'])
def read_db():
    req_params = request.get_json()
    try:
        columns = ",".join(req_params["columns"])
        table = req_params["table"].lower()
        where = req_params["where"]
        if len(where) == 0:
            query = "SELECT {} FROM {};".format(columns, table)
        else:
            for index in range(len(where)):
                split_cond = where[index].split("=")
                if split_cond[1].isalpha() and split_cond[1] != "NOW()":
                    split_cond[1] = "'{}'".format(split_cond[1])
                where[index] = '='.join(split_cond)
            where = " and ".join(where)
            query = "SELECT {} FROM {} WHERE {};".format(columns, table, where)
        print(query)
        query_result = db.engine.execute(text(query))
        output = [list(i) for i in list(query_result)]

    except Exception as e:
        print("Error:", e)
        return ('Invalid Query', 400)

    return jsonify(output)


# Assignment 2 APIS

# List all users API
@app.route("/api/v1/users", methods = ['GET'])
def list_users():
    increment_count()
    find_query = {"table": "user", "columns": ["username"], "where": []}
    find_resp = requests.post("http://" + user_ip + "/api/v1/db/read", json=find_query)
    user_list = [x[0] for x in find_resp.json()]
    return jsonify(user_list)


# Clear Database API
@app.route("/api/v1/db/clear", methods = ['POST'])
def clear_db():
    check_user = requests.get("http://" + user_ip + "/api/v1/users", headers=headers)
    if len(check_user.json()) == 0:
        abort(400)
    query={"where":[], "table":"user"}
    x=requests.delete("http://" + user_ip + "/api/v1/db/write",json=query)
    x1=requests.delete("http://" + ride_ip + "/api/v1/db/write",json=query)
    return (jsonify(),200)

# Assignment 3 APIs

# Get total HTTP requests made to microservice
@app.route("/api/v1/_count", methods = ['GET'])
def get_http_count():
    return "[ {} ]".format(get_count())

# Reset HTTP requests counter
@app.route("/api/v1/_count", methods = ['DELETE'])
def reset_http_count():
    reset_count()
    return (jsonify(), 200)

@app.route("/api/v1/users", methods=['POST'])
def handle_user():
    increment_count()
    print("Incorrect Method /api/v1/users")
    abort(405)

if __name__ == '__main__':
    app.run(host='0.0.0.0')
